# DuaVakti 1.1.4

## Düzeltme

EAS Android build sırasında görülen şu Gradle yapılandırma hatası giderildi:

`project ':duavakti-widget' does not specify compileSdk in build.gradle`

Widget yerel Android modülünün `build.gradle` dosyasına Expo/EAS kök projesiyle uyumlu `compileSdkVersion` tanımı eklendi. Böylece `:duavakti-widget` Android kütüphane modülü yapılandırılırken gerekli SDK seviyesi açıkça belirleniyor.

## Korunan özellikler

- 3 Android ana ekran widgetı: küçük, orta, büyük
- Türkçe sure adları
- Ayet bazında sesli tilavet
- Diyanet Türkçe meal
- Namaz vakitleri ve geri sayım

## Sürüm

- Uygulama: 1.1.4
- Android versionCode: 6
