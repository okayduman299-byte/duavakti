const API_BASE = 'https://api.alquran.cloud/v1';

export type QuranSurahMeta = {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  revelationType: 'Meccan' | 'Medinan' | string;
  numberOfAyahs: number;
};

export type QuranAyah = {
  number: number;
  numberInSurah: number;
  arabic: string;
  translation: string;
  audio: string;
};

export type QuranSurah = QuranSurahMeta & {
  ayahs: QuranAyah[];
  translationEdition: string;
};

type ApiEnvelope<T> = {
  code: number;
  status: string;
  data: T;
};

type Edition = {
  identifier: string;
  language: string;
  name: string;
  englishName: string;
  format: string;
  type: string;
};

type AudioAyah = {
  number: number;
  numberInSurah: number;
  text: string;
  audio?: string;
  audioSecondary?: string[];
};

type TranslationAyah = {
  number: number;
  numberInSurah: number;
  text: string;
};

type SurahResponse<T> = QuranSurahMeta & {
  ayahs: T[];
  edition: Edition;
};

const FALLBACK_SURAHS: QuranSurahMeta[] = [
  { number: 1, name: 'سُورَةُ ٱلْفَاتِحَةِ', englishName: 'Al-Faatiha', englishNameTranslation: 'The Opening', revelationType: 'Meccan', numberOfAyahs: 7 },
  { number: 2, name: 'سُورَةُ البَقَرَةِ', englishName: 'Al-Baqara', englishNameTranslation: 'The Cow', revelationType: 'Medinan', numberOfAyahs: 286 },
  { number: 18, name: 'سُورَةُ الكَهْفِ', englishName: 'Al-Kahf', englishNameTranslation: 'The Cave', revelationType: 'Meccan', numberOfAyahs: 110 },
  { number: 36, name: 'سُورَةُ يسٓ', englishName: 'Yaseen', englishNameTranslation: 'Yaseen', revelationType: 'Meccan', numberOfAyahs: 83 },
  { number: 55, name: 'سُورَةُ الرَّحْمَٰن', englishName: 'Ar-Rahmaan', englishNameTranslation: 'The Beneficent', revelationType: 'Medinan', numberOfAyahs: 78 },
  { number: 67, name: 'سُورَةُ المُلْكِ', englishName: 'Al-Mulk', englishNameTranslation: 'The Sovereignty', revelationType: 'Meccan', numberOfAyahs: 30 },
  { number: 78, name: 'سُورَةُ النَّبَإِ', englishName: 'An-Naba', englishNameTranslation: 'The Tidings', revelationType: 'Meccan', numberOfAyahs: 40 },
  { number: 93, name: 'سُورَةُ الضُّحَىٰ', englishName: 'Ad-Dhuhaa', englishNameTranslation: 'The Morning Hours', revelationType: 'Meccan', numberOfAyahs: 11 },
  { number: 112, name: 'سُورَةُ الإِخْلَاصِ', englishName: 'Al-Ikhlaas', englishNameTranslation: 'Sincerity', revelationType: 'Meccan', numberOfAyahs: 4 },
  { number: 113, name: 'سُورَةُ الفَلَقِ', englishName: 'Al-Falaq', englishNameTranslation: 'The Dawn', revelationType: 'Meccan', numberOfAyahs: 5 },
  { number: 114, name: 'سُورَةُ النَّاسِ', englishName: 'An-Naas', englishNameTranslation: 'Mankind', revelationType: 'Meccan', numberOfAyahs: 6 },
];

let preferredTurkishEdition: Edition | null = null;

async function request<T>(path: string): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(`${API_BASE}${path}`, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });

    if (!response.ok) {
      throw new Error(`Kur’an servisi ${response.status} hatası verdi.`);
    }

    const payload = (await response.json()) as ApiEnvelope<T>;
    if (payload.code !== 200 || !payload.data) {
      throw new Error('Kur’an servisi geçerli veri döndürmedi.');
    }

    return payload.data;
  } finally {
    clearTimeout(timeout);
  }
}

async function getTurkishEdition(): Promise<Edition> {
  if (preferredTurkishEdition) return preferredTurkishEdition;

  try {
    const editions = await request<Edition[]>('/edition/language/tr');
    preferredTurkishEdition =
      editions.find((item) => item.identifier === 'tr.diyanet') ??
      editions.find((item) => /diyanet/i.test(`${item.name} ${item.englishName}`)) ??
      editions.find((item) => item.type === 'translation') ??
      editions[0] ??
      null;
  } catch {
    preferredTurkishEdition = null;
  }

  return (
    preferredTurkishEdition ?? {
      identifier: 'tr.diyanet',
      language: 'tr',
      name: 'Türkçe meal',
      englishName: 'Turkish Translation',
      format: 'text',
      type: 'translation',
    }
  );
}

export async function fetchSurahList(): Promise<QuranSurahMeta[]> {
  try {
    return await request<QuranSurahMeta[]>('/surah');
  } catch {
    return FALLBACK_SURAHS;
  }
}

export async function fetchSurah(number: number): Promise<QuranSurah> {
  const edition = await getTurkishEdition();

  const [audioSurah, translationSurah] = await Promise.all([
    request<SurahResponse<AudioAyah>>(`/surah/${number}/ar.alafasy`),
    request<SurahResponse<TranslationAyah>>(
      `/surah/${number}/${edition.identifier}`,
    ),
  ]);

  const translations = new Map(
    translationSurah.ayahs.map((ayah) => [ayah.numberInSurah, ayah.text]),
  );

  return {
    number: audioSurah.number,
    name: audioSurah.name,
    englishName: audioSurah.englishName,
    englishNameTranslation: audioSurah.englishNameTranslation,
    revelationType: audioSurah.revelationType,
    numberOfAyahs: audioSurah.numberOfAyahs,
    translationEdition: translationSurah.edition.name,
    ayahs: audioSurah.ayahs.map((ayah) => ({
      number: ayah.number,
      numberInSurah: ayah.numberInSurah,
      arabic: ayah.text.replace(/^\uFEFF/, ''),
      translation: translations.get(ayah.numberInSurah) ?? '',
      audio: ayah.audio ?? ayah.audioSecondary?.[0] ?? '',
    })),
  };
}
