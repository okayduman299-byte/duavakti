#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/app.json" ] || [ ! -f "$ROOT/package.json" ]; then
  echo "❌ DuaVakti projesi bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"

# Çalışan son sürümün üstüne yazdığımızdan emin ol.
for marker in \
  'SafeAreaProvider' \
  'NavigationBar style="dark"' \
  'useSafeAreaInsets' \
  "type Tab = 'home'"; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen son çalışan UI sürümü bulunamadı: $marker"
    echo "Mevcut dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP/src/services"
cp App.tsx app.json package.json package-lock.json "$BACKUP"/ 2>/dev/null || true
cp src/services/quran.ts "$BACKUP/src/services/quran.ts" 2>/dev/null || true

echo "=== 1/7 Kur’an ses motoru ==="
if [ "${DUAVAKTI_QURAN_SKIP_INSTALL:-0}" != "1" ]; then
  npx expo install expo-audio
else
  echo "SKIP_INSTALL=1 — paket kurulumu atlandı"
fi

echo "=== 2/7 Kur’an modülü dosyaları ==="
cp "$SCRIPT_DIR/files/App.tsx" App.tsx
mkdir -p src/services
cp "$SCRIPT_DIR/files/src/services/quran.ts" src/services/quran.ts

# expo-audio pluginini garanti altına al.
python3 - <<'PY'
import json
from pathlib import Path
p = Path('app.json')
data = json.loads(p.read_text(encoding='utf-8'))
plugins = data.setdefault('expo', {}).setdefault('plugins', [])

def plugin_name(value):
    if isinstance(value, list) and value:
        return value[0]
    return value

if not any(plugin_name(item) == 'expo-audio' for item in plugins):
    plugins.append('expo-audio')

p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
PY

echo "=== 3/7 Kaynak kontrolü ==="
grep -Fq "type Tab = 'home' | 'quran'" App.tsx
grep -Fq "Oku · Dinle · Öğren" App.tsx
grep -Fq "fetchSurahList" src/services/quran.ts
grep -Fq "ar.alafasy" src/services/quran.ts
grep -Fq "tr.diyanet" src/services/quran.ts
grep -Fq 'expo-audio' package.json
grep -Fq 'expo-audio' app.json
echo "✅ QURAN_SOURCE_OK"

echo "=== 4/7 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 5/7 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi

echo "=== 6/7 Temiz Android prebuild ==="
if [ "${DUAVAKTI_QURAN_SKIP_PREBUILD:-0}" != "1" ]; then
  npx expo prebuild --platform android --clean
else
  echo "SKIP_PREBUILD=1 — prebuild atlandı"
fi

echo "=== 7/7 Generated widget kontrolü ==="
if [ "${DUAVAKTI_QURAN_SKIP_PREBUILD:-0}" != "1" ] && [ -f scripts/validate-generated-widget.js ]; then
  node scripts/validate-generated-widget.js
fi

echo
echo "✅ QURAN_MODULE_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
