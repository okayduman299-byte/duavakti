DUAVAKTI — KUR’AN MODÜLÜ M1

Eklenenler:
- Alt menüye Kur’an sekmesi
- 114 sure listesi (çevrimiçi API, bağlantı yoksa temel fallback liste)
- Arapça ayet metni
- Türkçe meal
- Ayet ayet sesli okuma
- Oku / Dinle / Öğren modları
- Öğren modunda 1x / 3x / 5x tekrar
- 0.75x / 1x / 1.25x oynatma hızı
- Çalışan widget ve mevcut UI korunur

Uygulama:
cd /workspaces/duavakti && \
git fetch origin && \
git checkout origin/main -- DUAVAKTI-QURAN-M1.zip && \
unzip -o DUAVAKTI-QURAN-M1.zip && \
bash DUAVAKTI-QURAN-M1/apply-quran-module.sh

Başarı çıktısı:
✅ QURAN_MODULE_READY

Sonra build:
cd /workspaces/duavakti/DUAVAKTI-M1 && npx eas-cli@latest build --platform android --profile preview
