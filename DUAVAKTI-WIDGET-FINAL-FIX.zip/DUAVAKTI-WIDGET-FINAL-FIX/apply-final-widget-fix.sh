#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"

if [ -f "$(pwd)/app.json" ] && [ -d "$(pwd)/modules/duavakti-widget" ]; then
  PROJECT="$(pwd)"
elif [ -d "$(pwd)/DUAVAKTI-M1" ] && [ -f "$(pwd)/DUAVAKTI-M1/app.json" ]; then
  PROJECT="$(pwd)/DUAVAKTI-M1"
else
  echo "❌ DUAVAKTI-M1 projesi bulunamadı."
  echo "Bu scripti /workspaces/duavakti veya /workspaces/duavakti/DUAVAKTI-M1 içinde çalıştır."
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/tmp/duavakti-widget-backup-$STAMP"
mkdir -p "$BACKUP"

copy_if_exists() {
  local source="$1"
  if [ -e "$source" ]; then
    mkdir -p "$BACKUP/$(dirname "${source#$PROJECT/}")"
    cp -a "$source" "$BACKUP/${source#$PROJECT/}"
  fi
}

copy_if_exists "$PROJECT/plugins/withDuaVaktiWidgets.js"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/AndroidManifest.xml"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/WidgetUpdater.kt"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/SmallWidgetProvider.kt"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/MediumWidgetProvider.kt"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/LargeWidgetProvider.kt"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/res/layout"
copy_if_exists "$PROJECT/modules/duavakti-widget/android/src/main/res/xml"
copy_if_exists "$PROJECT/.easignore"
copy_if_exists "$PROJECT/app.json"
copy_if_exists "$PROJECT/package.json"

echo "📦 Yedek: $BACKUP"

mkdir -p "$PROJECT/plugins" "$PROJECT/scripts"
mkdir -p "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget"
mkdir -p "$PROJECT/modules/duavakti-widget/android/src/main/res/layout"
mkdir -p "$PROJECT/modules/duavakti-widget/android/src/main/res/xml"

cp "$PAYLOAD/plugins/withDuaVaktiWidgets.js" "$PROJECT/plugins/withDuaVaktiWidgets.js"
cp "$PAYLOAD/modules/duavakti-widget/android/src/main/AndroidManifest.xml" "$PROJECT/modules/duavakti-widget/android/src/main/AndroidManifest.xml"
cp "$PAYLOAD/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/"*.kt "$PROJECT/modules/duavakti-widget/android/src/main/java/expo/modules/duavaktiwidget/"
cp "$PAYLOAD/modules/duavakti-widget/android/src/main/res/layout/"*.xml "$PROJECT/modules/duavakti-widget/android/src/main/res/layout/"
cp "$PAYLOAD/modules/duavakti-widget/android/src/main/res/xml/"*.xml "$PROJECT/modules/duavakti-widget/android/src/main/res/xml/"
cp "$PAYLOAD/scripts/"*.js "$PROJECT/scripts/"

# Android res klasörlerinde derlemeyi bozan .bak/.tmp vb. dosyaları temizle.
WRES="$PROJECT/modules/duavakti-widget/android/src/main/res"
for dir in layout xml drawable values; do
  [ -d "$WRES/$dir" ] || continue
  find "$WRES/$dir" -maxdepth 1 -type f ! -name '*.xml' -print -delete
 done

# EAS arşivinde native widget kaynaklarını zorunlu olarak tut.
touch "$PROJECT/.easignore"
for line in \
  '!modules/duavakti-widget/android/**' \
  '!modules/duavakti-widget/expo-module.config.json' \
  '!modules/duavakti-widget/package.json' \
  '!plugins/withDuaVaktiWidgets.js'; do
  grep -Fqx "$line" "$PROJECT/.easignore" || echo "$line" >> "$PROJECT/.easignore"
done

# Plugin kaydını garanti et, versionCode'u yalnızca artır.
node - "$PROJECT/app.json" <<'NODE'
const fs = require('fs');
const appPath = process.argv[2];
const app = JSON.parse(fs.readFileSync(appPath, 'utf8'));
app.expo = app.expo || {};
app.expo.android = app.expo.android || {};
app.expo.android.versionCode = Number(app.expo.android.versionCode || 1) + 1;
app.expo.plugins = app.expo.plugins || [];
const pluginPath = './plugins/withDuaVaktiWidgets';
if (!app.expo.plugins.some((p) => (Array.isArray(p) ? p[0] : p) === pluginPath)) {
  app.expo.plugins.push(pluginPath);
}
fs.writeFileSync(appPath, JSON.stringify(app, null, 2) + '\n');
console.log(`⬆️ Android versionCode: ${app.expo.android.versionCode}`);
NODE

node - "$PROJECT/package.json" <<'NODE'
const fs = require('fs');
const p = process.argv[2];
const pkg = JSON.parse(fs.readFileSync(p, 'utf8'));
pkg.scripts = pkg.scripts || {};
pkg.scripts['validate:widgets'] = 'node scripts/validate-widget-rescue.js';
pkg.scripts['validate:widgets:generated'] = 'node scripts/validate-generated-widget.js';
fs.writeFileSync(p, JSON.stringify(pkg, null, 2) + '\n');
NODE

cd "$PROJECT"

echo "\n=== 1/5 TYPESCRIPT ==="
npm run typecheck

echo "\n=== 2/5 STATIC WIDGET TESTS ==="
npm run validate:widgets

echo "\n=== 3/5 EXPO CONFIG ==="
npx expo config --type public >/tmp/duavakti-expo-config.json
echo "✅ EXPO_CONFIG_OK"

echo "\n=== 4/5 CLEAN PREBUILD ==="
rm -rf android
npx expo prebuild --platform android --clean --no-install

echo "\n=== 5/5 GENERATED ANDROID TESTS ==="
npm run validate:widgets:generated

echo ""
echo "✅ FINAL_WIDGET_FIX_READY"
echo "✅ Orta ve büyük provider artık çalışan küçük widget ile aynı RemoteViews yolunu kullanıyor."
echo "✅ Build öncesi ve prebuild sonrası kontroller geçti."
echo ""
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
