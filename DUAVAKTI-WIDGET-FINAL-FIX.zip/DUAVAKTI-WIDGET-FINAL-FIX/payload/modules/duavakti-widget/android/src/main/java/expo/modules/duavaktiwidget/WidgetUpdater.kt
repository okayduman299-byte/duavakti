package expo.modules.duavaktiwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

object WidgetUpdater {
  fun updateAll(context: Context) {
    updateProvider(context, SmallWidgetProvider::class.java)
    updateProvider(context, MediumWidgetProvider::class.java)
    updateProvider(context, LargeWidgetProvider::class.java)
  }

  fun updateProvider(
    context: Context,
    providerClass: Class<*>
  ) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, providerClass))
    ids.forEach { id ->
      manager.updateAppWidget(id, createSafeViews(context))
    }
  }

  fun createSafeViews(context: Context): RemoteViews {
    val prefs = context.getSharedPreferences(WidgetState.PREFS, 0)
    val views = RemoteViews(context.packageName, R.layout.widget_safe)

    val translation = prefs.getString(
      WidgetState.TRANSLATION,
      "De ki: Sabahın Rabbine sığınırım."
    ) ?: ""
    val source = prefs.getString(WidgetState.SOURCE, "Felâk 113:1") ?: ""
    val theme = prefs.getString(WidgetState.THEME, "green") ?: "green"

    val background = when (theme) {
      "black" -> R.drawable.widget_bg_black
      "gold" -> R.drawable.widget_bg_gold
      else -> R.drawable.widget_bg_green
    }

    // Every action below targets an ID that exists in widget_safe.xml.
    views.setInt(R.id.widget_root, "setBackgroundResource", background)
    views.setTextViewText(R.id.widget_translation, translation)
    views.setTextViewText(R.id.widget_source, source)

    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
    if (launchIntent != null) {
      launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
      val pendingIntent = PendingIntent.getActivity(
        context,
        0,
        launchIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
      views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
    }

    return views
  }
}
