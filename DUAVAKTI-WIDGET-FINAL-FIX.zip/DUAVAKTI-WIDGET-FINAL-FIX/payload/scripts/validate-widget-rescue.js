const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const widgetRoot = path.join(root, 'modules', 'duavakti-widget', 'android', 'src', 'main');
const resRoot = path.join(widgetRoot, 'res');
const layoutRoot = path.join(resRoot, 'layout');
const xmlRoot = path.join(resRoot, 'xml');
const javaRoot = path.join(widgetRoot, 'java', 'expo', 'modules', 'duavaktiwidget');

function fail(message) {
  console.error(`❌ ${message}`);
  process.exitCode = 1;
}
function ok(message) {
  console.log(`✅ ${message}`);
}
function read(file) {
  return fs.readFileSync(file, 'utf8');
}
function hash(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

const allowedRemoteTags = new Set([
  'LinearLayout', 'RelativeLayout', 'FrameLayout', 'GridLayout',
  'TextView', 'ImageView', 'ImageButton', 'Button', 'ProgressBar',
  'Chronometer', 'TextClock', 'ViewStub',
]);

for (const dir of ['layout', 'xml', 'drawable', 'values']) {
  const p = path.join(resRoot, dir);
  if (!fs.existsSync(p)) continue;
  for (const name of fs.readdirSync(p)) {
    const file = path.join(p, name);
    if (fs.statSync(file).isFile() && !name.endsWith('.xml')) {
      fail(`Android res/${dir} içinde XML olmayan dosya var: ${name}`);
    }
  }
}

const layouts = ['widget_safe.xml', 'widget_small.xml', 'widget_medium.xml', 'widget_large.xml'];
const hashes = layouts.map((name) => [name, hash(path.join(layoutRoot, name))]);
if (new Set(hashes.map(([, h]) => h)).size !== 1) {
  fail('Small/Medium/Large layoutları güvenli layout ile birebir aynı değil.');
} else {
  ok('Dört widget layout dosyası byte-for-byte aynı güvenli RemoteViews layoutunu kullanıyor.');
}

const safeLayout = read(path.join(layoutRoot, 'widget_safe.xml'));
const tags = [...safeLayout.matchAll(/<\/?([A-Za-z][A-Za-z0-9_.]*)\b/g)].map((m) => m[1]);
for (const tag of new Set(tags)) {
  if (!allowedRemoteTags.has(tag)) fail(`RemoteViews için izin verilmeyen tag: ${tag}`);
}
ok(`RemoteViews tag kontrolü geçti: ${[...new Set(tags)].join(', ')}`);

const ids = new Set([...safeLayout.matchAll(/android:id="@\+id\/([A-Za-z0-9_]+)"/g)].map((m) => m[1]));
const updater = read(path.join(javaRoot, 'WidgetUpdater.kt'));
const actionIds = new Set([...updater.matchAll(/R\.id\.([A-Za-z0-9_]+)/g)].map((m) => m[1]));
for (const id of actionIds) {
  if (!ids.has(id)) fail(`WidgetUpdater, layoutta olmayan ID'ye işlem yapıyor: ${id}`);
}
if ([...actionIds].every((id) => ids.has(id))) ok('Tüm RemoteViews işlemleri gerçek layout ID’lerine hedefleniyor.');

for (const size of ['small', 'medium', 'large']) {
  const info = read(path.join(xmlRoot, `widget_${size}_info.xml`));
  if (!info.includes('android:initialLayout="@layout/widget_safe"')) {
    fail(`${size} initialLayout widget_safe değil.`);
  }
}
ok('Üç AppWidgetProviderInfo aynı doğrulanmış initialLayoutu kullanıyor.');

for (const name of ['Small', 'Medium', 'Large']) {
  const provider = read(path.join(javaRoot, `${name}WidgetProvider.kt`));
  if (!provider.includes('WidgetUpdater.createSafeViews(context)')) {
    fail(`${name}WidgetProvider güvenli RemoteViews yolunu kullanmıyor.`);
  }
}
ok('Üç provider aynı güvenli update yolunu kullanıyor.');

const manifest = read(path.join(widgetRoot, 'AndroidManifest.xml'));
for (const name of ['Small', 'Medium', 'Large']) {
  if (!manifest.includes(`${name}WidgetProvider`)) fail(`Manifestte ${name} provider yok.`);
}
const exportedTrue = /WidgetProvider[\s\S]{0,250}android:exported="true"/g.test(manifest);
if (exportedTrue) fail('Widget receiver exported=true kaldı.'); else ok('Widget receiver exported değerleri false.');

const easignore = read(path.join(root, '.easignore'));
if (!easignore.includes('!modules/duavakti-widget/android/**')) fail('.easignore native widget kaynaklarını garanti etmiyor.');
else ok('.easignore native widget kaynaklarını EAS arşivine dahil ediyor.');

if (!process.exitCode) {
  console.log('\n✅ WIDGET_RESCUE_STATIC_VALIDATION_OK');
}
