const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const android = path.join(root, 'android');
function die(msg) { console.error(`❌ ${msg}`); process.exit(1); }
function read(p) { return fs.readFileSync(p, 'utf8'); }
function hash(p) { return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex'); }

if (!fs.existsSync(android)) die('android/ oluşmamış. Önce expo prebuild çalışmalı.');
const manifestPath = path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml');
const manifest = read(manifestPath);
for (const name of ['SmallWidgetProvider', 'MediumWidgetProvider', 'LargeWidgetProvider']) {
  if (!manifest.includes(name)) die(`Generated manifestte ${name} yok.`);
}
if ((manifest.match(/android\.appwidget\.provider/g) || []).length < 3) die('Generated manifestte 3 widget meta-data kaydı yok.');
if (/WidgetProvider[\s\S]{0,300}android:exported="true"/.test(manifest)) die('Generated manifestte exported=true receiver var.');
console.log('✅ Generated manifest: 3 provider kayıtlı, exported=false.');

const layoutDir = path.join(android, 'app', 'src', 'main', 'res', 'layout');
const names = ['widget_safe.xml', 'widget_small.xml', 'widget_medium.xml', 'widget_large.xml'];
const hs = names.map((n) => hash(path.join(layoutDir, n)));
if (new Set(hs).size !== 1) die('Generated app res içindeki widget layoutları aynı değil.');
console.log('✅ Generated app resources: tüm widget layoutları aynı güvenli layout.');

for (const size of ['small', 'medium', 'large']) {
  const info = read(path.join(android, 'app', 'src', 'main', 'res', 'xml', `widget_${size}_info.xml`));
  if (!info.includes('@layout/widget_safe')) die(`Generated ${size} info widget_safe kullanmıyor.`);
}
console.log('✅ Generated widget info XML: üçü de widget_safe kullanıyor.');

for (const dir of ['layout', 'xml', 'drawable', 'values']) {
  const p = path.join(android, 'app', 'src', 'main', 'res', dir);
  if (!fs.existsSync(p)) continue;
  const bad = fs.readdirSync(p).filter((n) => fs.statSync(path.join(p, n)).isFile() && !n.endsWith('.xml'));
  if (bad.length) die(`Generated res/${dir} içinde XML olmayan dosya: ${bad.join(', ')}`);
}
console.log('✅ Generated Android resource tree temiz.');
console.log('\n✅ GENERATED_WIDGET_VALIDATION_OK');
