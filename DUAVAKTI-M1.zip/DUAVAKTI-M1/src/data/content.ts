export type ContentType = 'verse' | 'dua' | 'dhikr';

export type DailyContent = {
  id: string;
  type: ContentType;
  title: string;
  arabic: string;
  translation: string;
  source: string;
  period: 'morning' | 'day' | 'evening' | 'night' | 'any';
};

export const CONTENTS: DailyContent[] = [
  {
    id: 'falaq-1',
    type: 'verse',
    title: 'Korunma',
    arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ',
    translation: 'De ki: Sabahın Rabbine sığınırım.',
    source: 'Felâk 113:1',
    period: 'morning'
  },
  {
    id: 'nas-1',
    type: 'verse',
    title: 'Sığınma',
    arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ',
    translation: 'De ki: İnsanların Rabbine sığınırım.',
    source: 'Nâs 114:1',
    period: 'night'
  },
  {
    id: 'insirah-5',
    type: 'verse',
    title: 'Ümit',
    arabic: 'فَإِنَّ مَعَ الْعُسْرِ يُسْرًا',
    translation: 'Şüphesiz zorlukla beraber bir kolaylık vardır.',
    source: 'İnşirah 94:5',
    period: 'any'
  },
  {
    id: 'bakara-286',
    type: 'verse',
    title: 'Güç',
    arabic: 'لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا',
    translation: 'Allah hiçbir kimseyi gücünün yettiğinden fazlasıyla yükümlü kılmaz.',
    source: 'Bakara 2:286',
    period: 'any'
  },
  {
    id: 'taha-114',
    type: 'dua',
    title: 'İlim',
    arabic: 'رَبِّ زِدْنِي عِلْمًا',
    translation: 'Rabbim, ilmimi artır.',
    source: 'Tâhâ 20:114',
    period: 'day'
  },
  {
    id: 'hasbunallah',
    type: 'dhikr',
    title: 'Tevekkül',
    arabic: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ',
    translation: 'Allah bize yeter. O ne güzel vekildir.',
    source: 'Âl-i İmrân 3:173',
    period: 'any'
  }
];

export function contentForDate(date = new Date()): DailyContent {
  const dayNumber = Math.floor(date.getTime() / 86_400_000);
  return CONTENTS[Math.abs(dayNumber) % CONTENTS.length] ?? CONTENTS[0]!;
}
