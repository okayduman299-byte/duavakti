import {
  CalculationMethod,
  Coordinates,
  Madhab,
  PrayerTimes,
} from 'adhan';

export type PrayerKey = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export type PrayerRow = {
  key: PrayerKey;
  label: string;
  time: Date;
};

export type PrayerSnapshot = {
  rows: PrayerRow[];
  next: PrayerRow;
};

const LABELS: Record<PrayerKey, string> = {
  fajr: 'Sabah',
  dhuhr: 'Öğle',
  asr: 'İkindi',
  maghrib: 'Akşam',
  isha: 'Yatsı',
};

function buildPrayerTimes(
  latitude: number,
  longitude: number,
  date: Date,
): PrayerTimes {
  const coordinates = new Coordinates(latitude, longitude);
  const params = CalculationMethod.Turkey();
  params.madhab = Madhab.Shafi;
  return new PrayerTimes(coordinates, date, params);
}

export function getPrayerRows(
  latitude: number,
  longitude: number,
  date = new Date(),
): PrayerRow[] {
  const times = buildPrayerTimes(latitude, longitude, date);
  return (['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const).map(
    (key) => ({
      key,
      label: LABELS[key],
      time: new Date(times[key]),
    }),
  );
}

export function getPrayerSnapshot(
  latitude: number,
  longitude: number,
  now = new Date(),
): PrayerSnapshot {
  const today = getPrayerRows(latitude, longitude, now);
  const nextToday = today.find((row) => row.time.getTime() > now.getTime());

  if (nextToday) {
    return { rows: today, next: nextToday };
  }

  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowRows = getPrayerRows(latitude, longitude, tomorrow);
  return { rows: today, next: tomorrowRows[0]! };
}

export function formatTime(date: Date): string {
  return new Intl.DateTimeFormat('tr-TR', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);
}

export function formatCountdown(target: Date, now = new Date()): string {
  const total = Math.max(0, target.getTime() - now.getTime());
  const hours = Math.floor(total / 3_600_000);
  const minutes = Math.floor((total % 3_600_000) / 60_000);
  const seconds = Math.floor((total % 60_000) / 1000);
  return [hours, minutes, seconds]
    .map((value) => String(value).padStart(2, '0'))
    .join(':');
}
