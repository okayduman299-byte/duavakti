import { Platform } from 'react-native';

type WidgetPayload = {
  translation: string;
  arabic: string;
  source: string;
  nextPrayer: string;
  nextTime: string;
  nextEpoch: number;
  theme: 'green' | 'black' | 'gold';
};

let nativeModule: any = null;

if (Platform.OS === 'android') {
  try {
    nativeModule = require('duavakti-widget').default;
  } catch {
    nativeModule = null;
  }
}

export function isNativeWidgetAvailable(): boolean {
  return Boolean(nativeModule?.updateWidget);
}

export async function updateAndroidWidget(
  payload: WidgetPayload,
): Promise<boolean> {
  if (!nativeModule?.updateWidget) return false;

  try {
    return await nativeModule.updateWidget(
      payload.translation,
      payload.arabic,
      payload.source,
      payload.nextPrayer,
      payload.nextTime,
      payload.nextEpoch,
      payload.theme,
    );
  } catch {
    return false;
  }
}
