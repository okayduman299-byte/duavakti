import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { getPrayerRows } from './prayerTimes';

const CHANNEL_ID = 'prayer-times';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function ensureNotificationPermission(): Promise<boolean> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      name: 'Ezan Vakitleri',
      description: 'Namaz vakti hatırlatmaları',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 250, 180, 250],
      lightColor: '#1F8A5B',
    });
  }

  const current = await Notifications.getPermissionsAsync();
  if (current.status === 'granted') return true;

  const requested = await Notifications.requestPermissionsAsync();
  return requested.status === 'granted';
}

export async function schedulePrayerNotifications(
  latitude: number,
  longitude: number,
  days = 7,
  remindBeforeMinutes = 10,
): Promise<number> {
  const allowed = await ensureNotificationPermission();
  if (!allowed) return 0;

  await Notifications.cancelAllScheduledNotificationsAsync();

  const now = new Date();
  let count = 0;

  for (let offset = 0; offset < days; offset += 1) {
    const date = new Date(now);
    date.setDate(date.getDate() + offset);

    const rows = getPrayerRows(latitude, longitude, date);

    for (const row of rows) {
      if (row.time.getTime() > now.getTime()) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: `${row.label} vakti girdi`,
            body: 'Vakti huzurla karşıla.',
            sound: 'default',
            data: { prayer: row.key },
          },
          trigger: {
            type: Notifications.SchedulableTriggerInputTypes.DATE,
            date: row.time,
            channelId: CHANNEL_ID,
          },
        });
        count += 1;
      }

      if (remindBeforeMinutes > 0) {
        const reminder = new Date(
          row.time.getTime() - remindBeforeMinutes * 60_000,
        );

        if (reminder.getTime() > now.getTime()) {
          await Notifications.scheduleNotificationAsync({
            content: {
              title: `${row.label} vaktine ${remindBeforeMinutes} dakika`,
              body: 'Kısa bir hazırlık ve hatırlama anı.',
              data: { prayer: row.key, kind: 'before' },
            },
            trigger: {
              type: Notifications.SchedulableTriggerInputTypes.DATE,
              date: reminder,
              channelId: CHANNEL_ID,
            },
          });
          count += 1;
        }
      }
    }
  }

  return count;
}
