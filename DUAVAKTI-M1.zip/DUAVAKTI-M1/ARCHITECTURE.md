# DuaVakti M1 mimarisi

## React Native katmanı

`App.tsx`
- Ana sayfa
- Dua arşivi
- Widget önizleme / tema
- Bildirim ve konum ayarları

`src/services/prayerTimes.ts`
- Koordinattan vakit hesaplama
- Turkey/Diyanet parametreleri
- Sıradaki vakit
- Geri sayım

`src/services/notifications.ts`
- Android bildirim kanalı
- 7 günlük vakit planı
- Vakit öncesi hatırlatma

`src/services/widget.ts`
- JS → native widget köprüsü
- Expo Go’da güvenli fallback

`src/data/content.ts`
- İlk yerel içerik paketi

## Native Android katmanı

`modules/duavakti-widget`
- Expo Modules API ile yerel native modül
- SharedPreferences üzerinden widget state
- 3 AppWidgetProvider:
  - SmallWidgetProvider
  - MediumWidgetProvider
  - LargeWidgetProvider
- RemoteViews layout’ları
- Green / Black / Gold arka planları

## Veri akışı

Konum
→ Adhan hesap motoru
→ Bugünkü vakitler
→ Sıradaki vakit / geri sayım
→ Bildirim planlama
→ Widget state
→ Android RemoteViews

Günün içeriği
→ uygulama kartı
→ favori / tema
→ native widget
