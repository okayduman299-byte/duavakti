# BURADAN BAŞLA

Bilgisayarın yoksa önce `PHONE-ONLY-GUIDE.md` dosyasını aç.

En kısa yol:

```bash
unzip DUAVAKTI-M1.zip
cd DUAVAKTI-M1
npm install
npm install -g eas-cli
eas login
eas init
eas build --platform android --profile preview
```

Build bitince verilen APK bağlantısını Android telefonunda aç ve kur.

Gerçek ana ekran widget'ı yalnızca bu APK kurulduktan sonra görünür.
