package expo.modules.duavaktiwidget

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class DuaVaktiWidgetModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("DuaVaktiWidget")

    AsyncFunction("updateWidget") {
      translation: String,
      arabic: String,
      source: String,
      nextPrayer: String,
      nextTime: String,
      nextEpoch: Double,
      theme: String ->

      val context = appContext.reactContext ?: return@AsyncFunction false
      val prefs = context.getSharedPreferences(WidgetState.PREFS, 0)

      prefs.edit()
        .putString(WidgetState.TRANSLATION, translation)
        .putString(WidgetState.ARABIC, arabic)
        .putString(WidgetState.SOURCE, source)
        .putString(WidgetState.NEXT_PRAYER, nextPrayer)
        .putString(WidgetState.NEXT_TIME, nextTime)
        .putLong(WidgetState.NEXT_EPOCH, nextEpoch.toLong())
        .putString(WidgetState.THEME, theme)
        .apply()

      WidgetUpdater.updateAll(context)
      true
    }
  }
}
