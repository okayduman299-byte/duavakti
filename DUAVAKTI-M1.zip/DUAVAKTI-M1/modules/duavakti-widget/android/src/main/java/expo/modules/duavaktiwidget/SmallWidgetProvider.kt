package expo.modules.duavaktiwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class SmallWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(
    context: Context,
    appWidgetManager: AppWidgetManager,
    appWidgetIds: IntArray
  ) {
    appWidgetIds.forEach { id ->
      appWidgetManager.updateAppWidget(
        id,
        WidgetUpdater.createViews(context, R.layout.widget_small)
      )
    }
  }
}
