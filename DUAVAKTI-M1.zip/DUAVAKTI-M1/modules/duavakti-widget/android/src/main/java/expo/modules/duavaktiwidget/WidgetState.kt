package expo.modules.duavaktiwidget

object WidgetState {
  const val PREFS = "duavakti_widget_state"
  const val TRANSLATION = "translation"
  const val ARABIC = "arabic"
  const val SOURCE = "source"
  const val NEXT_PRAYER = "nextPrayer"
  const val NEXT_TIME = "nextTime"
  const val NEXT_EPOCH = "nextEpoch"
  const val THEME = "theme"
}
