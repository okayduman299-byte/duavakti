package expo.modules.duavaktiwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.math.max

object WidgetUpdater {
  fun updateAll(context: Context) {
    updateProvider(context, SmallWidgetProvider::class.java, R.layout.widget_small)
    updateProvider(context, MediumWidgetProvider::class.java, R.layout.widget_medium)
    updateProvider(context, LargeWidgetProvider::class.java, R.layout.widget_large)
  }

  fun updateProvider(
    context: Context,
    providerClass: Class<*>,
    layoutId: Int
  ) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, providerClass))
    ids.forEach { id ->
      manager.updateAppWidget(id, createViews(context, layoutId))
    }
  }

  fun createViews(context: Context, layoutId: Int): RemoteViews {
    val prefs = context.getSharedPreferences(WidgetState.PREFS, 0)
    val views = RemoteViews(context.packageName, layoutId)

    val translation = prefs.getString(
      WidgetState.TRANSLATION,
      "De ki: Sabahın Rabbine sığınırım."
    ) ?: ""

    val arabic = prefs.getString(
      WidgetState.ARABIC,
      "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ"
    ) ?: ""

    val source = prefs.getString(WidgetState.SOURCE, "Felâk 113:1") ?: ""
    val nextPrayer = prefs.getString(WidgetState.NEXT_PRAYER, "Akşam") ?: ""
    val nextTime = prefs.getString(WidgetState.NEXT_TIME, "--:--") ?: ""
    val nextEpoch = prefs.getLong(WidgetState.NEXT_EPOCH, 0L)
    val theme = prefs.getString(WidgetState.THEME, "green") ?: "green"

    val background = when (theme) {
      "black" -> R.drawable.widget_bg_black
      "gold" -> R.drawable.widget_bg_gold
      else -> R.drawable.widget_bg_green
    }

    views.setInt(R.id.widget_root, "setBackgroundResource", background)
    setTextIfPresent(views, R.id.widget_translation, translation)
    setTextIfPresent(views, R.id.widget_arabic, arabic)
    setTextIfPresent(views, R.id.widget_source, source)
    setTextIfPresent(views, R.id.widget_next_prayer, nextPrayer)
    setTextIfPresent(views, R.id.widget_next_time, nextTime)
    setTextIfPresent(views, R.id.widget_countdown, countdown(nextEpoch))

    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
    if (launchIntent != null) {
      launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
      val pendingIntent = PendingIntent.getActivity(
        context,
        0,
        launchIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
      )
      views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
    }

    return views
  }

  private fun setTextIfPresent(views: RemoteViews, id: Int, value: String) {
    try {
      views.setTextViewText(id, value)
    } catch (_: Exception) {
      // A layout may not contain every field.
    }
  }

  private fun countdown(epoch: Long): String {
    if (epoch <= 0L) return "--:--"
    val diff = max(0L, epoch - System.currentTimeMillis())
    val hours = diff / 3_600_000L
    val minutes = (diff % 3_600_000L) / 60_000L
    return String.format("%02d:%02d kaldı", hours, minutes)
  }
}
