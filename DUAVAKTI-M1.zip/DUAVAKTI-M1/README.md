# DuaVakti M1

KINDRELAY çekirdeği kaldırıldı. Bu proje yeni ürünün ilk gerçek mobil çekirdeğidir.

## M1’de çalışan çekirdek

- Telefon konumunu alır.
- `adhan` ile Türkiye/Diyanet hesap parametrelerini kullanarak vakitleri hesaplar.
- Sıradaki vakti ve saniyelik geri sayımı gösterir.
- 5 vakti günlük kartta gösterir.
- 7 gün ileriye yerel vakit bildirimleri planlar.
- İsteğe göre vakitten 0 / 5 / 10 / 15 dakika önce ek hatırlatma planlar.
- Yerel dua/ayet kart paketi içerir.
- Favoriler ve widget teması cihazda saklanır.
- Android için gerçek native AppWidget altyapısı vardır:
  - Küçük kart
  - Orta Türkçe + Arapça kart
  - Büyük vakit + dua kartı
- Uygulama içinden native widget verisi güncellenir.
- Expo Go’da widget native modülü yoktur; gerçek APK / development build gerekir.

## Neden Expo SDK 56?

Bu paket, açıkça doğrulanabilen Expo SDK 56 bağımlılıklarıyla sabitlendi. Native Android widget içerdiği için Expo Go hedef değildir; EAS preview APK hedefidir.

## İlk kurulum

```bash
npm install
npx expo prebuild --clean
```

Expo hesabına giriş:

```bash
npx eas login
```

Projeyi EAS’e bağla:

```bash
npx eas init
```

Android APK üret:

```bash
npm run build:apk
```

Build bittiğinde EAS bir indirme bağlantısı verir. APK’yı Android telefona indirip kur.

## İlk gerçek test

1. Uygulamayı aç.
2. Konum izni ver.
3. Sıradaki vakit ve geri sayımı kontrol et.
4. Ayarlar → `7 günlük uyarıları yeniden planla`.
5. Widget sekmesinde tema seç.
6. `Widget'ı şimdi güncelle`.
7. Android ana ekranında boş alana basılı tut.
8. Widget’lar → DuaVakti.
9. Küçük, orta ve büyük boyları tek tek dene.

## Kritik doğruluk notu

Namaz vakitleri astronomik hesapla üretilir. Mağaza yayını öncesinde farklı şehirlerde resmi yerel takvimlerle karşılaştırma testi yapılmalı ve kullanıcıya manuel dakika düzeltmesi sunulmalıdır.

M1 içindeki Arapça metinler ve kısa Türkçe anlamlar başlangıç veri paketidir. Kamuya açık yayın öncesinde yetkin bir editoryal / ilmî doğrulama süreci zorunlu kabul edilmelidir.

## Sonraki milestone

M2:
- Her vakti ayrı aç/kapat
- Özel ezan sesi
- Telefon yeniden başlatıldığında bildirimleri tekrar planlama
- Widget’ın vakit geçişinde otomatik anlık yenilenmesi
- Şehir elle seçme
- Manuel dakika düzeltmeleri

M3:
- İçerik arşivi
- Sabah / akşam otomatik içerik kuralları
- Cuma ve Ramazan modları
- Paylaşılabilir duvar kağıdı kartı
