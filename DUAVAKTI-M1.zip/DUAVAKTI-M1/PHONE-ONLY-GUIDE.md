# Bilgisayarsız kullanım: Android telefon + GitHub Codespaces + EAS

Bu rehber özellikle bilgisayarı olmayan kullanıcı içindir.

## A. Dosyayı telefona indir

`DUAVAKTI-M1.zip` dosyasını Android telefonuna indir.

## B. GitHub’da boş depo aç

1. GitHub hesabına giriş yap.
2. Yeni bir repository oluştur: `duavakti`.
3. Repository sayfasından `Code` → `Codespaces` → `Create codespace`.

Codespace tarayıcıda VS Code benzeri bir geliştirme ekranı açar.

## C. ZIP’i Codespaces’e yükle

1. Sol taraftaki dosya bölümünü aç.
2. `DUAVAKTI-M1.zip` dosyasını workspace içine yükle.
3. Terminali aç.
4. Şunları çalıştır:

```bash
unzip DUAVAKTI-M1.zip
cd DUAVAKTI-M1
npm install
npm install -g eas-cli
```

## D. Expo / EAS hesabına giriş

```bash
eas login
```

Tarayıcıda Expo hesabınla giriş yap.

Ardından:

```bash
eas init
```

Bu işlem projeyi Expo hesabına bağlar.

## E. APK üret

```bash
eas build --platform android --profile preview
```

Derleme bulutta yapılır. Telefonun güçlü olmak zorunda değildir.

Build bitince terminalde / Expo sayfasında APK bağlantısı görünür.

## F. APK’yı telefona kur

1. APK bağlantısını aç.
2. Dosyayı indir.
3. Android, bilinmeyen kaynak izni isterse yalnızca kullandığın tarayıcı için izin ver.
4. APK’yı kur.
5. Uygulamayı aç.
6. Konum ve bildirim izinlerini ver.
7. Ana ekrana dön.
8. Boş alana basılı tut → Widget’lar → DuaVakti.

## Önemli

Expo Go ile ana ekran widget’ı görünmez. Widget native Android kodudur; EAS ile üretilen APK kurulmalıdır.
