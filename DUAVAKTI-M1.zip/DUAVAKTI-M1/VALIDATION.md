# Doğrulama raporu

Bu paket oluşturulurken şu kontroller yapıldı:

- `npm install --ignore-scripts` başarılı.
- `npm run typecheck` başarılı; TypeScript hatası yok.
- `npx expo prebuild --clean --no-install` başarılı.
- `npx expo-modules-autolinking resolve --platform android` çıktısında `duavakti-widget` ve `DuaVaktiWidgetModule` bulundu.
- JSON yapılandırma dosyaları geçerli.

## Tamamlanamayan kontrol

Yerel `./gradlew :app:assembleDebug` denemesi kod hatası nedeniyle değil, bu çalışma ortamının `services.gradle.org` alan adına erişememesi nedeniyle Gradle dağıtımını indiremedi. Bu nedenle son APK derlemesi burada tamamlanamadı.

Gerçek son doğrulama EAS Build üzerinde `preview` profiliyle APK üretilerek yapılmalıdır.
