import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';

import { CONTENTS, contentForDate, DailyContent } from './src/data/content';
import {
  formatCountdown,
  formatTime,
  getPrayerSnapshot,
  PrayerRow,
} from './src/services/prayerTimes';
import { schedulePrayerNotifications } from './src/services/notifications';
import {
  isNativeWidgetAvailable,
  updateAndroidWidget,
} from './src/services/widget';

type Tab = 'home' | 'duas' | 'widget' | 'settings';
type ThemeKey = 'green' | 'black' | 'gold';

type CoordinatesState = {
  latitude: number;
  longitude: number;
  city: string;
};

const ISTANBUL: CoordinatesState = {
  latitude: 41.0082,
  longitude: 28.9784,
  city: 'İstanbul',
};

const THEME: Record<ThemeKey, { card: string; border: string; accent: string }> = {
  green: { card: '#08251A', border: '#1B4A37', accent: '#78C69A' },
  black: { card: '#121417', border: '#2B2F34', accent: '#D7D9DC' },
  gold: { card: '#211B11', border: '#5A4825', accent: '#D6B66C' },
};

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [coords, setCoords] = useState<CoordinatesState>(ISTANBUL);
  const [loadingLocation, setLoadingLocation] = useState(true);
  const [now, setNow] = useState(new Date());
  const [content, setContent] = useState<DailyContent>(() => contentForDate());
  const [favorites, setFavorites] = useState<string[]>([]);
  const [theme, setTheme] = useState<ThemeKey>('green');
  const [notificationsOn, setNotificationsOn] = useState(false);
  const [beforeMinutes, setBeforeMinutes] = useState(10);
  const [scheduledCount, setScheduledCount] = useState(0);

  const snapshot = useMemo(
    () => getPrayerSnapshot(coords.latitude, coords.longitude, now),
    [coords.latitude, coords.longitude, now],
  );

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    void loadSavedState();
    void loadLocation();
  }, []);

  const syncWidget = useCallback(async () => {
    return updateAndroidWidget({
      translation: content.translation,
      arabic: content.arabic,
      source: content.source,
      nextPrayer: snapshot.next.label,
      nextTime: formatTime(snapshot.next.time),
      nextEpoch: snapshot.next.time.getTime(),
      theme,
    });
  }, [content, snapshot.next, theme]);

  useEffect(() => {
    void syncWidget();
  }, [syncWidget]);

  async function loadSavedState() {
    try {
      const [savedFavorites, savedTheme, savedNotifications, savedBefore] =
        await Promise.all([
          AsyncStorage.getItem('favorites'),
          AsyncStorage.getItem('widget-theme'),
          AsyncStorage.getItem('notifications-on'),
          AsyncStorage.getItem('before-minutes'),
        ]);

      if (savedFavorites) setFavorites(JSON.parse(savedFavorites));
      if (
        savedTheme === 'green' ||
        savedTheme === 'black' ||
        savedTheme === 'gold'
      ) {
        setTheme(savedTheme);
      }
      if (savedNotifications) {
        setNotificationsOn(savedNotifications === 'true');
      }
      if (savedBefore) setBeforeMinutes(Number(savedBefore) || 10);
    } catch {
      // Keep defaults.
    }
  }

  async function loadLocation() {
    try {
      setLoadingLocation(true);
      const permission = await Location.requestForegroundPermissionsAsync();

      if (permission.status !== 'granted') {
        setCoords(ISTANBUL);
        return;
      }

      const last = await Location.getLastKnownPositionAsync();
      const position =
        last ??
        (await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        }));

      const { latitude, longitude } = position.coords;
      let city = 'Konumum';

      try {
        const geocoded = await Location.reverseGeocodeAsync({
          latitude,
          longitude,
        });
        city =
          geocoded[0]?.city ??
          geocoded[0]?.district ??
          geocoded[0]?.subregion ??
          'Konumum';
      } catch {
        city = 'Konumum';
      }

      setCoords({ latitude, longitude, city });
    } catch {
      setCoords(ISTANBUL);
    } finally {
      setLoadingLocation(false);
    }
  }

  async function toggleFavorite(id: string) {
    const next = favorites.includes(id)
      ? favorites.filter((item) => item !== id)
      : [...favorites, id];

    setFavorites(next);
    await AsyncStorage.setItem('favorites', JSON.stringify(next));
  }

  async function changeTheme(next: ThemeKey) {
    setTheme(next);
    await AsyncStorage.setItem('widget-theme', next);
  }

  async function enableNotifications() {
    try {
      const count = await schedulePrayerNotifications(
        coords.latitude,
        coords.longitude,
        7,
        beforeMinutes,
      );

      if (count === 0) {
        Alert.alert(
          'Bildirim izni gerekli',
          'Vakit uyarıları için telefon ayarlarından bildirim izni ver.',
        );
        return;
      }

      setNotificationsOn(true);
      setScheduledCount(count);
      await AsyncStorage.setItem('notifications-on', 'true');
      Alert.alert('Hazır', `${count} yerel vakit hatırlatması planlandı.`);
    } catch (error) {
      Alert.alert(
        'Planlama yapılamadı',
        error instanceof Error ? error.message : 'Bilinmeyen hata',
      );
    }
  }

  function rotateContent() {
    const currentIndex = CONTENTS.findIndex((item) => item.id === content.id);
    const next = CONTENTS[(currentIndex + 1) % CONTENTS.length] ?? CONTENTS[0]!;
    setContent(next);
  }

  const colors = THEME[theme];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#0B0D10" />
      <ExpoStatusBar style="light" />
      <View style={styles.app}>
        <Header
          city={coords.city}
          loading={loadingLocation}
          onRefreshLocation={loadLocation}
        />

        {tab === 'home' && (
          <HomeScreen
            rows={snapshot.rows}
            nextLabel={snapshot.next.label}
            nextTime={formatTime(snapshot.next.time)}
            countdown={formatCountdown(snapshot.next.time, now)}
            content={content}
            favorite={favorites.includes(content.id)}
            onFavorite={() => toggleFavorite(content.id)}
            onRotate={rotateContent}
            colors={colors}
          />
        )}

        {tab === 'duas' && (
          <DuasScreen
            favorites={favorites}
            onToggleFavorite={toggleFavorite}
            onSelect={(item) => {
              setContent(item);
              setTab('home');
            }}
          />
        )}

        {tab === 'widget' && (
          <WidgetScreen
            content={content}
            nextLabel={snapshot.next.label}
            nextTime={formatTime(snapshot.next.time)}
            countdown={formatCountdown(snapshot.next.time, now)}
            theme={theme}
            onTheme={changeTheme}
            onSync={syncWidget}
            nativeAvailable={isNativeWidgetAvailable()}
          />
        )}

        {tab === 'settings' && (
          <SettingsScreen
            notificationsOn={notificationsOn}
            scheduledCount={scheduledCount}
            beforeMinutes={beforeMinutes}
            onBeforeMinutes={async (value) => {
              setBeforeMinutes(value);
              await AsyncStorage.setItem('before-minutes', String(value));
            }}
            onSchedule={enableNotifications}
            onRefreshLocation={loadLocation}
            coords={coords}
          />
        )}

        <BottomNav tab={tab} onChange={setTab} />
      </View>
    </SafeAreaView>
  );
}

function Header({
  city,
  loading,
  onRefreshLocation,
}: {
  city: string;
  loading: boolean;
  onRefreshLocation: () => void;
}) {
  const today = new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <View style={styles.header}>
      <View>
        <Text style={styles.brand}>DuaVakti</Text>
        <Text style={styles.headerMeta}>
          {today} · {loading ? 'Konum alınıyor…' : city}
        </Text>
      </View>
      <Pressable style={styles.roundButton} onPress={onRefreshLocation}>
        <Text style={styles.roundButtonText}>⌖</Text>
      </Pressable>
    </View>
  );
}

function HomeScreen({
  rows,
  nextLabel,
  nextTime,
  countdown,
  content,
  favorite,
  onFavorite,
  onRotate,
  colors,
}: {
  rows: PrayerRow[];
  nextLabel: string;
  nextTime: string;
  countdown: string;
  content: DailyContent;
  favorite: boolean;
  onFavorite: () => void;
  onRotate: () => void;
  colors: { card: string; border: string; accent: string };
}) {
  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.screenContent}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.nextPrayerCard}>
        <Text style={styles.eyebrow}>SIRADAKİ VAKİT</Text>
        <View style={styles.nextPrayerRow}>
          <View>
            <Text style={styles.nextPrayerName}>{nextLabel}</Text>
            <Text style={styles.nextPrayerTime}>{nextTime}</Text>
          </View>
          <View style={styles.countdownBox}>
            <Text style={styles.countdownLabel}>KALAN</Text>
            <Text style={styles.countdown}>{countdown}</Text>
          </View>
        </View>

        <View style={styles.prayerStrip}>
          {rows.map((row) => (
            <View key={row.key} style={styles.prayerMini}>
              <Text style={styles.prayerMiniLabel}>{row.label}</Text>
              <Text style={styles.prayerMiniTime}>{formatTime(row.time)}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.sectionTitleRow}>
        <View>
          <Text style={styles.sectionKicker}>GÜNÜN KARTI</Text>
          <Text style={styles.sectionTitle}>Bir an dur, hatırla.</Text>
        </View>
        <Pressable style={styles.iconButton} onPress={onRotate}>
          <Text style={styles.iconButtonText}>↻</Text>
        </Pressable>
      </View>

      <DuaCard
        content={content}
        colors={colors}
        favorite={favorite}
        onFavorite={onFavorite}
      />

      <Text style={styles.note}>
        Kart, Android widget’ına da gönderilir. Gerçek widget için APK /
        development build gerekir.
      </Text>
    </ScrollView>
  );
}

function DuaCard({
  content,
  colors,
  favorite,
  onFavorite,
}: {
  content: DailyContent;
  colors: { card: string; border: string; accent: string };
  favorite: boolean;
  onFavorite: () => void;
}) {
  return (
    <View
      style={[
        styles.duaCard,
        { backgroundColor: colors.card, borderColor: colors.border },
      ]}
    >
      <View style={styles.duaColumns}>
        <View style={styles.duaColumn}>
          <Text style={styles.cardLabel}>{content.title.toUpperCase()}</Text>
          <Text style={styles.translation}>{content.translation}</Text>
        </View>
        <View style={[styles.divider, { backgroundColor: colors.accent }]} />
        <View style={styles.duaColumn}>
          <Text style={styles.arabic}>{content.arabic}</Text>
        </View>
      </View>
      <View style={styles.cardFooter}>
        <Text style={[styles.source, { color: colors.accent }]}>
          {content.source}
        </Text>
        <Pressable onPress={onFavorite}>
          <Text style={styles.favorite}>{favorite ? '♥' : '♡'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function DuasScreen({
  favorites,
  onToggleFavorite,
  onSelect,
}: {
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onSelect: (item: DailyContent) => void;
}) {
  return (
    <View style={styles.listScreen}>
      <Text style={styles.pageTitle}>Dua ve ayet kartları</Text>
      <Text style={styles.pageSubtitle}>
        Karta dokun; ana ekrandaki günlük kart olarak kullan.
      </Text>
      <FlatList
        data={CONTENTS}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <Pressable style={styles.contentRow} onPress={() => onSelect(item)}>
            <View style={styles.contentText}>
              <Text style={styles.contentTitle}>{item.title}</Text>
              <Text style={styles.contentTranslation} numberOfLines={2}>
                {item.translation}
              </Text>
              <Text style={styles.contentSource}>{item.source}</Text>
            </View>
            <Pressable
              style={styles.heartButton}
              onPress={() => onToggleFavorite(item.id)}
            >
              <Text style={styles.heartText}>
                {favorites.includes(item.id) ? '♥' : '♡'}
              </Text>
            </Pressable>
          </Pressable>
        )}
      />
    </View>
  );
}

function WidgetScreen({
  content,
  nextLabel,
  nextTime,
  countdown,
  theme,
  onTheme,
  onSync,
  nativeAvailable,
}: {
  content: DailyContent;
  nextLabel: string;
  nextTime: string;
  countdown: string;
  theme: ThemeKey;
  onTheme: (theme: ThemeKey) => void;
  onSync: () => Promise<boolean>;
  nativeAvailable: boolean;
}) {
  const colors = THEME[theme];

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.screenContent}
      showsVerticalScrollIndicator={false}
    >
      <Text style={styles.pageTitle}>Ana ekran widget’ı</Text>
      <Text style={styles.pageSubtitle}>
        Duvar kağıdının üstünde yaşayan dua kartı.
      </Text>

      <Text style={styles.previewLabel}>ORTA BOY ÖNİZLEME</Text>
      <DuaCard
        content={content}
        colors={colors}
        favorite={false}
        onFavorite={() => {}}
      />

      <Text style={styles.previewLabel}>BÜYÜK BOY ÖNİZLEME</Text>
      <View
        style={[
          styles.largeWidgetPreview,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <View style={styles.largeWidgetTop}>
          <View>
            <Text style={styles.cardLabel}>SIRADAKİ VAKİT</Text>
            <Text style={styles.largePrayer}>{nextLabel}</Text>
          </View>
          <View style={styles.largeTimeBlock}>
            <Text style={styles.largeTime}>{nextTime}</Text>
            <Text style={[styles.largeCountdown, { color: colors.accent }]}>
              {countdown}
            </Text>
          </View>
        </View>
        <View
          style={[
            styles.horizontalDivider,
            { backgroundColor: colors.border },
          ]}
        />
        <Text style={styles.translation}>{content.translation}</Text>
        <Text style={styles.arabicWide}>{content.arabic}</Text>
        <Text style={[styles.source, { color: colors.accent }]}>
          {content.source}
        </Text>
      </View>

      <Text style={styles.previewLabel}>TEMA</Text>
      <View style={styles.themeRow}>
        {(['green', 'black', 'gold'] as const).map((item) => (
          <Pressable
            key={item}
            style={[
              styles.themeChip,
              theme === item && styles.themeChipActive,
            ]}
            onPress={() => onTheme(item)}
          >
            <View
              style={[
                styles.themeDot,
                { backgroundColor: THEME[item].card },
              ]}
            />
            <Text style={styles.themeText}>
              {item === 'green'
                ? 'Yeşil'
                : item === 'black'
                  ? 'Siyah'
                  : 'Altın'}
            </Text>
          </Pressable>
        ))}
      </View>

      <Pressable
        style={styles.primaryButton}
        onPress={async () => {
          const ok = await onSync();
          Alert.alert(
            ok ? 'Widget güncellendi' : 'Native widget hazır değil',
            ok
              ? 'Ana ekran widget’ları yeni içerikle eşitlendi.'
              : 'Bu özellik Expo Go’da çalışmaz. EAS ile APK üretip kurduğunda aktif olur.',
          );
        }}
      >
        <Text style={styles.primaryButtonText}>
          {nativeAvailable
            ? 'WIDGET’I ŞİMDİ GÜNCELLE'
            : 'APK WIDGET MODUNU KONTROL ET'}
        </Text>
      </Pressable>

      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>Ana ekrana ekleme</Text>
        <Text style={styles.infoText}>
          1. APK’yı kur.{`\n`}
          2. Ana ekranda boş alana basılı tut.{`\n`}
          3. Widget’lar → DuaVakti.{`\n`}
          4. Küçük, orta veya büyük kartı seç.
        </Text>
      </View>
    </ScrollView>
  );
}

function SettingsScreen({
  notificationsOn,
  scheduledCount,
  beforeMinutes,
  onBeforeMinutes,
  onSchedule,
  onRefreshLocation,
  coords,
}: {
  notificationsOn: boolean;
  scheduledCount: number;
  beforeMinutes: number;
  onBeforeMinutes: (value: number) => void;
  onSchedule: () => void;
  onRefreshLocation: () => void;
  coords: CoordinatesState;
}) {
  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.screenContent}
    >
      <Text style={styles.pageTitle}>Ayarlar</Text>
      <Text style={styles.pageSubtitle}>
        Vakit ve hatırlatma sistemini buradan yönet.
      </Text>

      <View style={styles.settingsCard}>
        <View style={styles.settingRow}>
          <View style={styles.settingCopy}>
            <Text style={styles.settingTitle}>Ezan vakti uyarıları</Text>
            <Text style={styles.settingSub}>
              {notificationsOn
                ? `${scheduledCount || '7 günlük'} hatırlatma hazır`
                : 'Henüz planlanmadı'}
            </Text>
          </View>
          <Switch
            value={notificationsOn}
            onValueChange={(value) => {
              if (value) void onSchedule();
              else
                Alert.alert(
                  'M1 notu',
                  'Kapatma düğmesi sonraki sürümde tek tek vakit seçimiyle tamamlanacak.',
                );
            }}
            trackColor={{ false: '#2A2D31', true: '#2D6D50' }}
            thumbColor={notificationsOn ? '#F3F1EA' : '#8A8E93'}
          />
        </View>

        <View style={styles.settingDivider} />

        <Text style={styles.settingTitle}>Önceden hatırlatma</Text>
        <View style={styles.choiceRow}>
          {[0, 5, 10, 15].map((value) => (
            <Pressable
              key={value}
              style={[
                styles.choice,
                beforeMinutes === value && styles.choiceActive,
              ]}
              onPress={() => onBeforeMinutes(value)}
            >
              <Text
                style={[
                  styles.choiceText,
                  beforeMinutes === value && styles.choiceTextActive,
                ]}
              >
                {value === 0 ? 'Yok' : `${value} dk`}
              </Text>
            </Pressable>
          ))}
        </View>

        <Pressable style={styles.secondaryButton} onPress={onSchedule}>
          <Text style={styles.secondaryButtonText}>
            7 GÜNLÜK UYARILARI YENİDEN PLANLA
          </Text>
        </Pressable>
      </View>

      <View style={styles.settingsCard}>
        <Text style={styles.settingTitle}>Konum</Text>
        <Text style={styles.settingSub}>
          {coords.city}{`\n`}
          {coords.latitude.toFixed(4)}, {coords.longitude.toFixed(4)}
        </Text>
        <Pressable style={styles.secondaryButton} onPress={onRefreshLocation}>
          <Text style={styles.secondaryButtonText}>KONUMU YENİLE</Text>
        </Pressable>
      </View>

      <View style={styles.warningBox}>
        <Text style={styles.warningTitle}>Yayın öncesi önemli</Text>
        <Text style={styles.warningText}>
          M1 içindeki dini metinler örnek başlangıç paketidir. Mağaza yayını
          öncesinde Arapça metin, meal ve kaynaklar yetkin bir editoryal /
          ilmî doğrulama sürecinden geçirilmelidir.
        </Text>
      </View>
    </ScrollView>
  );
}

function BottomNav({
  tab,
  onChange,
}: {
  tab: Tab;
  onChange: (tab: Tab) => void;
}) {
  const items: Array<{ key: Tab; icon: string; label: string }> = [
    { key: 'home', icon: '⌂', label: 'Ana' },
    { key: 'duas', icon: '☾', label: 'Dualar' },
    { key: 'widget', icon: '▣', label: 'Widget' },
    { key: 'settings', icon: '⚙', label: 'Ayarlar' },
  ];

  return (
    <View style={styles.bottomNav}>
      {items.map((item) => (
        <Pressable
          key={item.key}
          style={[
            styles.navItem,
            tab === item.key && styles.navItemActive,
          ]}
          onPress={() => onChange(item.key)}
        >
          <Text style={styles.navIcon}>{item.icon}</Text>
          <Text
            style={[
              styles.navLabel,
              tab === item.key && styles.navLabelActive,
            ]}
          >
            {item.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0B0D10' },
  app: { flex: 1, backgroundColor: '#0B0D10' },
  header: {
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 14,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  brand: { color: '#F3F1EA', fontSize: 26, fontWeight: '800' },
  headerMeta: { color: '#8D948F', fontSize: 12, marginTop: 4 },
  roundButton: {
    width: 44,
    height: 44,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#24282A',
    backgroundColor: '#141719',
    alignItems: 'center',
    justifyContent: 'center',
  },
  roundButtonText: { color: '#D8DDD8', fontSize: 20 },
  screen: { flex: 1 },
  screenContent: { paddingHorizontal: 16, paddingBottom: 120 },
  nextPrayerCard: {
    backgroundColor: '#111A16',
    borderWidth: 1,
    borderColor: '#21372D',
    borderRadius: 28,
    padding: 20,
  },
  eyebrow: {
    color: '#77B08F',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  nextPrayerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: 15,
  },
  nextPrayerName: { color: '#F3F1EA', fontSize: 38, fontWeight: '800' },
  nextPrayerTime: { color: '#AAB3AD', fontSize: 18, marginTop: 3 },
  countdownBox: { alignItems: 'flex-end' },
  countdownLabel: {
    color: '#708078',
    fontSize: 9,
    letterSpacing: 1.2,
    fontWeight: '700',
  },
  countdown: {
    color: '#E8ECE8',
    fontSize: 24,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
    marginTop: 5,
  },
  prayerStrip: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 22,
    paddingTop: 17,
    borderTopWidth: 1,
    borderTopColor: '#22342B',
  },
  prayerMini: { alignItems: 'center', flex: 1 },
  prayerMiniLabel: { color: '#839087', fontSize: 9 },
  prayerMiniTime: {
    color: '#E6E9E5',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 5,
  },
  sectionTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginTop: 28,
    marginBottom: 13,
    paddingHorizontal: 2,
  },
  sectionKicker: {
    color: '#74847B',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  sectionTitle: {
    color: '#F3F1EA',
    fontSize: 24,
    fontWeight: '800',
    marginTop: 4,
  },
  iconButton: {
    width: 42,
    height: 42,
    borderRadius: 15,
    backgroundColor: '#15181A',
    borderWidth: 1,
    borderColor: '#272B2D',
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconButtonText: { color: '#D1D5D2', fontSize: 20 },
  duaCard: {
    minHeight: 245,
    borderRadius: 26,
    borderWidth: 1,
    padding: 18,
  },
  duaColumns: { flexDirection: 'row', flex: 1 },
  duaColumn: { flex: 1, justifyContent: 'center', paddingHorizontal: 5 },
  divider: { width: 1, opacity: 0.65, marginHorizontal: 12, borderRadius: 1 },
  cardLabel: {
    color: '#819087',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.1,
    marginBottom: 10,
  },
  translation: { color: '#F4F2EB', fontSize: 19, lineHeight: 28, fontWeight: '600' },
  arabic: {
    color: '#F7F5EF',
    fontSize: 23,
    lineHeight: 38,
    textAlign: 'right',
    writingDirection: 'rtl',
  },
  arabicWide: {
    color: '#F7F5EF',
    fontSize: 22,
    lineHeight: 36,
    textAlign: 'right',
    writingDirection: 'rtl',
    marginTop: 16,
  },
  cardFooter: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
    paddingTop: 13,
    marginTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  source: { fontSize: 12, fontWeight: '700' },
  favorite: { color: '#F3F1EA', fontSize: 24 },
  note: { color: '#747D78', fontSize: 11, lineHeight: 17, marginTop: 14, paddingHorizontal: 5 },
  listScreen: { flex: 1, paddingHorizontal: 16 },
  pageTitle: { color: '#F3F1EA', fontSize: 29, fontWeight: '800', marginTop: 5 },
  pageSubtitle: { color: '#818B86', fontSize: 12, lineHeight: 18, marginTop: 5, marginBottom: 18 },
  listContent: { paddingBottom: 120, gap: 9 },
  contentRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#131719',
    borderWidth: 1,
    borderColor: '#252A2C',
    borderRadius: 20,
    padding: 15,
  },
  contentText: { flex: 1 },
  contentTitle: { color: '#EBEEE9', fontSize: 15, fontWeight: '700' },
  contentTranslation: { color: '#A3ABA6', fontSize: 12, lineHeight: 17, marginTop: 5 },
  contentSource: { color: '#6D8F7B', fontSize: 10, marginTop: 7 },
  heartButton: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginLeft: 10 },
  heartText: { color: '#E9ECE8', fontSize: 22 },
  previewLabel: { color: '#7D8881', fontSize: 9, fontWeight: '800', letterSpacing: 1.2, marginTop: 20, marginBottom: 10 },
  largeWidgetPreview: { borderRadius: 26, borderWidth: 1, padding: 18 },
  largeWidgetTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  largePrayer: { color: '#F4F2EB', fontSize: 27, fontWeight: '800' },
  largeTimeBlock: { alignItems: 'flex-end' },
  largeTime: { color: '#F3F1EA', fontSize: 24, fontWeight: '800' },
  largeCountdown: { fontSize: 12, fontWeight: '700', marginTop: 3 },
  horizontalDivider: { height: 1, marginVertical: 17 },
  themeRow: { flexDirection: 'row', gap: 8 },
  themeChip: {
    flex: 1,
    padding: 12,
    borderRadius: 17,
    borderWidth: 1,
    borderColor: '#292D2F',
    backgroundColor: '#141719',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  themeChipActive: { borderColor: '#4C755F', backgroundColor: '#172019' },
  themeDot: { width: 19, height: 19, borderRadius: 7 },
  themeText: { color: '#D4D8D4', fontSize: 11, fontWeight: '700' },
  primaryButton: { backgroundColor: '#E5EAD8', borderRadius: 18, paddingVertical: 16, alignItems: 'center', marginTop: 18 },
  primaryButtonText: { color: '#101410', fontSize: 11, fontWeight: '900', letterSpacing: 0.6 },
  infoBox: { marginTop: 12, padding: 16, borderRadius: 20, backgroundColor: '#111518', borderWidth: 1, borderColor: '#252A2C' },
  infoTitle: { color: '#ECEFEA', fontSize: 14, fontWeight: '800' },
  infoText: { color: '#929B96', fontSize: 12, lineHeight: 21, marginTop: 8 },
  settingsCard: { backgroundColor: '#121618', borderWidth: 1, borderColor: '#252A2C', borderRadius: 22, padding: 17, marginBottom: 12 },
  settingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  settingCopy: { flex: 1, paddingRight: 12 },
  settingTitle: { color: '#EBEEE9', fontSize: 14, fontWeight: '700' },
  settingSub: { color: '#858F89', fontSize: 11, lineHeight: 17, marginTop: 5 },
  settingDivider: { height: 1, backgroundColor: '#24292A', marginVertical: 17 },
  choiceRow: { flexDirection: 'row', gap: 7, marginTop: 12 },
  choice: { flex: 1, borderRadius: 14, paddingVertical: 11, alignItems: 'center', borderWidth: 1, borderColor: '#292D2F', backgroundColor: '#171A1C' },
  choiceActive: { borderColor: '#4A745D', backgroundColor: '#17231C' },
  choiceText: { color: '#8D9691', fontSize: 10, fontWeight: '700' },
  choiceTextActive: { color: '#CFE3D5' },
  secondaryButton: { borderRadius: 16, paddingVertical: 14, alignItems: 'center', marginTop: 16, borderWidth: 1, borderColor: '#334039', backgroundColor: '#161C18' },
  secondaryButtonText: { color: '#C8D2CB', fontSize: 10, fontWeight: '800', letterSpacing: 0.4 },
  warningBox: { borderRadius: 20, borderWidth: 1, borderColor: '#554729', backgroundColor: '#201B12', padding: 16 },
  warningTitle: { color: '#E2C77D', fontSize: 13, fontWeight: '800' },
  warningText: { color: '#B5A787', fontSize: 11, lineHeight: 18, marginTop: 7 },
  bottomNav: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 10,
    height: 72,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#282D2F',
    backgroundColor: '#111416',
    flexDirection: 'row',
    padding: 7,
  },
  navItem: { flex: 1, borderRadius: 17, alignItems: 'center', justifyContent: 'center', gap: 3 },
  navItemActive: { backgroundColor: '#1B231E' },
  navIcon: { color: '#AAB2AD', fontSize: 18 },
  navLabel: { color: '#6F7872', fontSize: 8, fontWeight: '700' },
  navLabelActive: { color: '#D9E2DB' },
});
