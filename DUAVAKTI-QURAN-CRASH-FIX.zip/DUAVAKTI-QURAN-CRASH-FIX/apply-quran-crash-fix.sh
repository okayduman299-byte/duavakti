#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"
cd "$ROOT"

if [ ! -f App.tsx ]; then
  echo "❌ App.tsx bulunamadı: $ROOT"
  exit 1
fi

for marker in \
  "function QuranScreen()" \
  "const player = useAudioPlayer(null, { updateInterval: 250 });" \
  "const playerStatus = useAudioPlayerStatus(player);" \
  "player.pause();"; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen Kur’an M1 kodu bulunamadı: $marker"
    echo "Dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-crash-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx "$BACKUP/App.tsx"

echo "=== 1/5 Kur’an ses motoru güvenli başlatma düzeltmesi ==="
python3 - <<'PY'
from pathlib import Path
p = Path('App.tsx')
s = p.read_text(encoding='utf-8')

old = """  useEffect(() => {\n    player.playbackRate = speed;\n    player.shouldCorrectPitch = true;\n  }, [player, speed]);\n"""
new = """  useEffect(() => {\n    if (!playerStatus.isLoaded) return;\n    player.playbackRate = speed;\n    player.shouldCorrectPitch = true;\n  }, [player, playerStatus.isLoaded, speed]);\n"""
if old not in s:
    raise SystemExit('❌ Hız efekti bulunamadı; dosyaya dokunulmadı.')
s = s.replace(old, new, 1)

old = """      player.pause();\n      setActiveAyahIndex(null);\n"""
new = """      if (playerStatus.isLoaded) {\n        player.pause();\n      }\n      setActiveAyahIndex(null);\n"""
if old not in s:
    raise SystemExit('❌ loadSurah pause satırı bulunamadı; dosyaya dokunulmadı.')
s = s.replace(old, new, 1)

old = """    player.replace({\n      uri: ayah.audio,\n      name: `${surah?.englishName ?? 'Kur’an'} ${ayah.numberInSurah}`,\n    });\n    player.playbackRate = speed;\n    player.shouldCorrectPitch = true;\n    player.play();\n"""
new = """    player.replace({\n      uri: ayah.audio,\n      name: `${surah?.englishName ?? 'Kur’an'} ${ayah.numberInSurah}`,\n    });\n    player.play();\n"""
if old not in s:
    raise SystemExit('❌ playAyah güvenli dönüşüm bloğu bulunamadı; dosyaya dokunulmadı.')
s = s.replace(old, new, 1)

old = """    if (next === 'read') {\n      player.pause();\n    }\n"""
new = """    if (next === 'read' && playerStatus.isLoaded) {\n      player.pause();\n    }\n"""
if old not in s:
    raise SystemExit('❌ selectMode pause bloğu bulunamadı; dosyaya dokunulmadı.')
s = s.replace(old, new, 1)

p.write_text(s, encoding='utf-8')
PY

echo "=== 2/5 Kaynak doğrulama ==="
grep -Fq "if (!playerStatus.isLoaded) return;" App.tsx
grep -Fq "if (playerStatus.isLoaded)" App.tsx
grep -Fq "next === 'read' && playerStatus.isLoaded" App.tsx
COUNT=$(grep -Fc "player.playbackRate = speed;" App.tsx || true)
if [ "$COUNT" -ne 1 ]; then
  echo "❌ Beklenmeyen playbackRate sayısı: $COUNT"
  exit 1
fi
echo "✅ QURAN_AUDIO_GUARDS_OK"

echo "=== 3/5 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 4/5 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi

echo "=== 5/5 Temiz Android prebuild ==="
npx expo prebuild --platform android --clean
if [ -f scripts/validate-generated-widget.js ]; then
  node scripts/validate-generated-widget.js
fi

echo
echo "✅ QURAN_CRASH_FIX_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
