#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/package.json" ]; then
  echo "❌ DuaVakti projesi bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"

# Bu düzeltme yalnızca Kur’an M1 sürümünün üstüne uygulanır.
for marker in \
  "type Tab = 'home' | 'quran'" \
  "function QuranScreen()" \
  "useAudioPlayer(null, { updateInterval: 250 })" \
  "useAudioPlayerStatus(player)"; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen Kur’an M1 kodu bulunamadı: $marker"
    echo "Mevcut dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-crash-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx "$BACKUP/App.tsx"

cp "$SCRIPT_DIR/files/App.tsx" App.tsx

echo "=== 1/4 Kur’an ekranı açılış düzeltmesi ==="
grep -Fq "createAudioPlayer" App.tsx
grep -Fq "ensureQuranPlayer" App.tsx
if grep -Fq "useAudioPlayerStatus" App.tsx; then
  echo "❌ Eski açılışta player oluşturan kod hâlâ mevcut"
  exit 1
fi
echo "✅ QURAN_LAZY_AUDIO_OK"

echo "=== 2/4 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 3/4 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi
echo "✅ WIDGET_REGRESSION_OK"

echo "=== 4/4 Kur’an kaynak kontrolü ==="
grep -Fq "fetchSurahList" App.tsx
grep -Fq "Oku · Dinle · Öğren" App.tsx
grep -Fq "playerRef.current?.pause()" App.tsx
echo "✅ QURAN_SOURCE_OK"

echo
echo "✅ QURAN_CRASH_FIX_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
