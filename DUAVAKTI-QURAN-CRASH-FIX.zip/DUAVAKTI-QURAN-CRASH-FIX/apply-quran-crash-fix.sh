#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/package.json" ]; then
  echo "❌ DuaVakti projesi bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"

for marker in \
  "type Tab = 'home' | 'quran'" \
  'function QuranScreen()' \
  'useAudioPlayer(null'; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen Kur’an M1 sürümü bulunamadı: $marker"
    echo "Mevcut dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-crash-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx "$BACKUP/App.tsx"

echo "=== 1/4 Kur’an ekranı güvenli ses başlatma düzeltmesi ==="
cp "$SCRIPT_DIR/files/App.tsx" App.tsx

echo "=== 2/4 Kaynak kontrolü ==="
grep -Fq 'function QuranAudioSession' App.tsx
grep -Fq 'audioSessionId' App.tsx
if grep -Fq 'useAudioPlayer(null' App.tsx; then
  echo "❌ Boş kaynakla ses motoru hâlâ bulunuyor."
  exit 1
fi
echo "✅ QURAN_LAZY_AUDIO_SOURCE_OK"

echo "=== 3/4 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 4/4 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi

echo
echo "✅ QURAN_CRASH_FIX_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
