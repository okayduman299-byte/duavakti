# Kur’an Crash Fix — doğrulama

Yerel kaynak incelemesinde Kur’an ekranı mount edilir edilmez şu native ses akışı çalışıyordu:
- useAudioPlayer(null)
- useAudioPlayerStatus(player)
- source yüklenmeden playback rate/pitch ayarı

Hotfix sonucu:
- player oluşturma kullanıcı oynat düğmesine kadar ertelendi
- source olmayan player’a mount anında işlem yapılmıyor
- TypeScript/TSX sözdizimi parse kontrolü: geçti
- Kur’an veri servisi ve ekran kaynakları: korundu
- Widget kaynaklarına değişiklik: yok

Telefon üzerindeki son doğrulama yeni APK ile yapılır.
