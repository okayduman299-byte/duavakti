DUAVAKTI QURAN CRASH FIX

Amaç:
- Kur'an sekmesine girince oluşan çöküşü engellemek.
- Ses motorunu Kur'an ekranı açılır açılmaz boş kaynakla başlatmamak.
- Ses motorunu yalnızca kullanıcı gerçek bir ayetin oynat düğmesine bastığında, gerçek ses URL'siyle oluşturmak.
- Çalışan widget ve alt menü düzeltmelerine dokunmamak.

Uygulama:
cd /workspaces/duavakti && git fetch origin && git checkout origin/main -- DUAVAKTI-QURAN-CRASH-FIX.zip && unzip -o DUAVAKTI-QURAN-CRASH-FIX.zip && bash DUAVAKTI-QURAN-CRASH-FIX/apply-quran-crash-fix.sh

Başarı çıktısı:
✅ QURAN_CRASH_FIX_READY
