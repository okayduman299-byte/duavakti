DUAVAKTI QURAN CRASH FIX

Amaç:
- Kur’an sekmesine girerken boş ses oynatıcı üzerinde pause / hız ayarı yapılmasını engeller.
- Ses işlemlerini yalnızca player gerçekten yüklendikten sonra çalıştırır.
- Çalışan widget ve UI dosyalarına dokunmaz.

Uygulama:
cd /workspaces/duavakti && unzip -o DUAVAKTI-QURAN-CRASH-FIX.zip && bash DUAVAKTI-QURAN-CRASH-FIX/apply-quran-crash-fix.sh
