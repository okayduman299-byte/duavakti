DUAVAKTI — KUR’AN AÇILIŞ ÇÖKMESİ HOTFIX

Sorun:
Kur’an ekranı açılır açılmaz expo-audio player ve status hook’u oluşturuluyordu.
Bazı Android cihazlarda bu yol ekran mount anında uygulamayı kapatabiliyor.

Düzeltme:
- Kur’an ekranı artık ses motoru oluşturmadan açılır.
- Ses player yalnızca kullanıcı gerçekten ▶ düğmesine bastığında oluşturulur.
- Oku modu ses motorundan tamamen bağımsızdır.
- Sure/ayet/meal yapısı korunur.
- Widget koduna dokunulmaz.

Başarı çıktısı:
✅ QURAN_CRASH_FIX_READY
