#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(pwd)"

if [ -d "$ROOT/DUAVAKTI-M1" ]; then
  PROJECT="$ROOT/DUAVAKTI-M1"
elif [ -f "$ROOT/app.json" ] && [ -d "$ROOT/modules/duavakti-widget" ]; then
  PROJECT="$ROOT"
else
  echo "HATA: DUAVAKTI-M1 klasörü bulunamadı. Bu scripti duavakti repo kökünde çalıştır."
  exit 1
fi

mkdir -p "$PROJECT/plugins"
cp "$HERE/withDuaVaktiWidgets.js" "$PROJECT/plugins/withDuaVaktiWidgets.js"

node - "$PROJECT/app.json" <<'NODE'
const fs = require('fs');
const appPath = process.argv[2];
const app = JSON.parse(fs.readFileSync(appPath, 'utf8'));
app.expo.version = '0.2.0';
app.expo.android = app.expo.android || {};
app.expo.android.versionCode = Math.max(Number(app.expo.android.versionCode || 1) + 1, 2);
app.expo.plugins = app.expo.plugins || [];
const pluginPath = './plugins/withDuaVaktiWidgets';
if (!app.expo.plugins.some((p) => (Array.isArray(p) ? p[0] : p) === pluginPath)) {
  app.expo.plugins.push(pluginPath);
}
fs.writeFileSync(appPath, JSON.stringify(app, null, 2) + '\n');
NODE

# Eski native çıktıyı temizle; EAS yeni manifesti baştan üretsin.
rm -rf "$PROJECT/android"

echo "✅ DuaVakti M2 widget düzeltmesi uygulandı."
echo "📁 Proje: $PROJECT"
echo "🔧 Ana AndroidManifest'e 3 widget receiver eklenecek."
echo "📦 Widget kaynakları app/res içine kopyalanacak."
echo "⬆️ Android versionCode artırıldı."
