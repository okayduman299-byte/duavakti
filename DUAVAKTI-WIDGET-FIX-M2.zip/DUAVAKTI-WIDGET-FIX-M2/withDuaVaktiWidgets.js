const fs = require('fs');
const path = require('path');
const {
  AndroidConfig,
  withAndroidManifest,
  withDangerousMod,
} = require('@expo/config-plugins');

const WIDGETS = [
  {
    className: 'expo.modules.duavaktiwidget.SmallWidgetProvider',
    info: '@xml/widget_small_info',
    label: 'DuaVakti · Küçük',
  },
  {
    className: 'expo.modules.duavaktiwidget.MediumWidgetProvider',
    info: '@xml/widget_medium_info',
    label: 'DuaVakti · Orta',
  },
  {
    className: 'expo.modules.duavaktiwidget.LargeWidgetProvider',
    info: '@xml/widget_large_info',
    label: 'DuaVakti · Büyük',
  },
];

function makeReceiver(widget) {
  return {
    $: {
      'android:name': widget.className,
      'android:enabled': 'true',
      'android:exported': 'false',
      'android:label': widget.label,
      'android:icon': '@mipmap/ic_launcher',
    },
    'intent-filter': [
      {
        action: [
          {
            $: {
              'android:name': 'android.appwidget.action.APPWIDGET_UPDATE',
            },
          },
        ],
      },
    ],
    'meta-data': [
      {
        $: {
          'android:name': 'android.appwidget.provider',
          'android:resource': widget.info,
        },
      },
    ],
  };
}

function withWidgetManifest(config) {
  return withAndroidManifest(config, (config) => {
    const manifest = config.modResults;
    const application = AndroidConfig.Manifest.getMainApplicationOrThrow(manifest);
    application.receiver = application.receiver || [];

    const widgetClasses = new Set(WIDGETS.map((widget) => widget.className));
    application.receiver = application.receiver.filter(
      (receiver) => !widgetClasses.has(receiver?.$?.['android:name']),
    );

    for (const widget of WIDGETS) {
      application.receiver.push(makeReceiver(widget));
    }

    return config;
  });
}

function copyDirContents(sourceDir, targetDir) {
  if (!fs.existsSync(sourceDir)) {
    throw new Error(`DuaVakti widget kaynakları bulunamadı: ${sourceDir}`);
  }

  fs.mkdirSync(targetDir, { recursive: true });
  for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
    const source = path.join(sourceDir, entry.name);
    const target = path.join(targetDir, entry.name);
    if (entry.isDirectory()) {
      fs.cpSync(source, target, { recursive: true, force: true });
    } else {
      fs.copyFileSync(source, target);
    }
  }
}

function withWidgetResources(config) {
  return withDangerousMod(config, [
    'android',
    async (config) => {
      const sourceRes = path.join(
        config.modRequest.projectRoot,
        'modules',
        'duavakti-widget',
        'android',
        'src',
        'main',
        'res',
      );
      const targetRes = path.join(
        config.modRequest.platformProjectRoot,
        'app',
        'src',
        'main',
        'res',
      );

      copyDirContents(sourceRes, targetRes);
      return config;
    },
  ]);
}

module.exports = function withDuaVaktiWidgets(config) {
  config = withWidgetManifest(config);
  config = withWidgetResources(config);
  return config;
};
