DUAVAKTI WIDGET FIX M2

Amaç:
- Küçük / Orta / Büyük DuaVakti widget'larını Android widget listesine kaydetmek.
- Expo prebuild sırasında receiver kayıtlarını ana uygulama manifestine zorunlu eklemek.
- Widget XML/layout/drawable kaynaklarını uygulama kaynaklarına kopyalamak.

Telefon + Codespaces akışı:
1) Bu ZIP'i duavakti GitHub deposuna yükle.
2) Codespaces'te repo kökünde:
   unzip -o DUAVAKTI-WIDGET-FIX-M2.zip
3) Ardından:
   bash DUAVAKTI-WIDGET-FIX-M2/apply-widget-fix.sh
4) Proje klasörüne gir:
   cd DUAVAKTI-M1
5) Kontrol:
   npm run typecheck
6) Manifest doğrulama:
   npx expo prebuild --platform android --clean
7) Android build:
   npx eas-cli@latest build --platform android --profile preview

Not: Yeni APK'yı eski uygulamanın üstüne kur. Widget listesinde DuaVakti görünmelidir.
