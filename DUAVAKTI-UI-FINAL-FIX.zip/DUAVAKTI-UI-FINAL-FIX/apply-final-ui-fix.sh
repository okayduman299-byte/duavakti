#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/app.json" ]; then
  echo "❌ Proje bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"
BACKUP="/tmp/duavakti-ui-final-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx app.json package.json package-lock.json "$BACKUP"/ 2>/dev/null || true

echo "=== 1/5 Gerekli Expo paketleri ==="
if [ "${DUAVAKTI_UI_SKIP_INSTALL:-0}" != "1" ]; then
  npx expo install react-native-safe-area-context expo-navigation-bar
else
  echo "SKIP_INSTALL=1 — paket kurulumu atlandı"
fi

echo "=== 2/5 Ekran ve safe-area düzeltmesi ==="
python3 - <<'PY'
from pathlib import Path

p = Path('App.tsx')
s = p.read_text(encoding='utf-8')

# React Native'in Android alt insetini çözmeyen SafeAreaView importunu kaldır.
s = s.replace('  SafeAreaView,\n', '')

status_import = "import { StatusBar as ExpoStatusBar } from 'expo-status-bar';\n"
extra_imports = """import { NavigationBar } from 'expo-navigation-bar';
import {
  SafeAreaProvider,
  SafeAreaView,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
"""
if extra_imports not in s:
    if status_import not in s:
        raise SystemExit('ExpoStatusBar importu bulunamadı')
    s = s.replace(status_import, status_import + extra_imports)

# App köküne SafeAreaProvider ekle.
old = 'export default function App() {\n'
new = """export default function App() {
  return (
    <SafeAreaProvider>
      <AppContent />
    </SafeAreaProvider>
  );
}

function AppContent() {
"""
if new not in s:
    if old not in s:
        raise SystemExit('App fonksiyonu bulunamadı')
    s = s.replace(old, new, 1)

# Android sistem navigasyon çubuğunu koyu yap.
needle = '      <ExpoStatusBar style="light" />\n'
replacement = needle + '      <NavigationBar style="dark" />\n'
if replacement not in s:
    if needle not in s:
        raise SystemExit('ExpoStatusBar satırı bulunamadı')
    s = s.replace(needle, replacement, 1)

# Eski geliştirme notunu kaldır.
old_note = """      <Text style={styles.note}>
        Kart, Android widget’ına da gönderilir. Gerçek widget için APK /
        development build gerekir.
      </Text>
"""
s = s.replace(old_note, '')

# BottomNav içine gerçek cihaz alt insetini uygula.
old_fn = """function BottomNav({
  tab,
  onChange,
}: {
  tab: Tab;
  onChange: (tab: Tab) => void;
}) {
"""
new_fn = old_fn + '  const insets = useSafeAreaInsets();\n\n'
if '  const insets = useSafeAreaInsets();\n' not in s:
    if old_fn not in s:
        raise SystemExit('BottomNav fonksiyonu bulunamadı')
    s = s.replace(old_fn, new_fn, 1)

s = s.replace(
    '    <View style={styles.bottomNav}>\n',
    "    <View\n      style={[styles.bottomNav, { bottom: Math.max(insets.bottom, 10) + 8 }]}\n    >\n",
    1,
)

# Alttaki yükseltilmiş menü için içerik payını artır.
s = s.replace('  screenContent: { paddingHorizontal: 16, paddingBottom: 120 },',
              '  screenContent: { paddingHorizontal: 16, paddingBottom: 170 },')
s = s.replace('  listContent: { paddingBottom: 120, gap: 9 },',
              '  listContent: { paddingBottom: 170, gap: 9 },')

# Artık kullanılmayan note stilini kaldır.
s = s.replace("  note: { color: '#747D78', fontSize: 11, lineHeight: 17, marginTop: 14, paddingHorizontal: 5 },\n", '')

p.write_text(s, encoding='utf-8')
PY

python3 - <<'PY'
import json
from pathlib import Path

p = Path('app.json')
data = json.loads(p.read_text(encoding='utf-8'))
expo = data.setdefault('expo', {})
plugins = expo.setdefault('plugins', [])

# Aynı plugin zaten varsa güncelle; yoksa ekle.
entry = [
    'expo-navigation-bar',
    {
        'enforceContrast': False,
        'hidden': False,
        'style': 'dark',
    },
]

found = False
for i, plugin in enumerate(plugins):
    name = plugin[0] if isinstance(plugin, list) and plugin else plugin
    if name == 'expo-navigation-bar':
        plugins[i] = entry
        found = True
        break
if not found:
    plugins.append(entry)

p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
PY

echo "=== 3/5 Kaynak kontrolü ==="
if grep -Fq 'Gerçek widget için APK' App.tsx; then
  echo "❌ Eski geliştirme notu hâlâ var"
  exit 1
fi
grep -Fq 'useSafeAreaInsets' App.tsx
grep -Fq 'NavigationBar style="dark"' App.tsx
grep -Fq 'expo-navigation-bar' app.json
echo "✅ UI_SOURCE_OK"

if [ "${DUAVAKTI_UI_SKIP_CHECKS:-0}" = "1" ]; then
  echo "SKIP_CHECKS=1 — typecheck/prebuild atlandı"
  echo "✅ FINAL_UI_FIX_READY"
  exit 0
fi

echo "=== 4/5 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 5/5 Temiz Android prebuild ==="
npx expo prebuild --platform android --clean

# Widget düzeltmesinin bozulmadığını da tekrar doğrula.
if [ -f scripts/validate-generated-widget.js ]; then
  node scripts/validate-generated-widget.js
fi

echo
echo "✅ FINAL_UI_FIX_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
