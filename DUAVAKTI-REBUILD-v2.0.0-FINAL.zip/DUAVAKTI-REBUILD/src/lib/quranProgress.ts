import type { QuranBookmark, QuranProgress } from '../types';
import { readJson, writeJson } from './storage';

export const QURAN_PROGRESS_KEY = 'duavakti:quran:progress:v3';
export const QURAN_BOOKMARKS_KEY = 'duavakti:quran:bookmarks:v1';

export async function loadQuranProgress(): Promise<QuranProgress | null> {
  const value = await readJson<QuranProgress>(QURAN_PROGRESS_KEY);
  if (!value || !Number.isInteger(value.surah) || !Number.isInteger(value.ayah)) return null;
  return value;
}

export async function saveQuranProgress(surah: number, ayah: number): Promise<QuranProgress> {
  const value: QuranProgress = {
    surah,
    ayah,
    updatedAt: new Date().toISOString(),
  };
  await writeJson(QURAN_PROGRESS_KEY, value);
  return value;
}

export async function loadBookmarks(): Promise<QuranBookmark[]> {
  const value = await readJson<QuranBookmark[]>(QURAN_BOOKMARKS_KEY);
  if (!Array.isArray(value)) return [];
  return value.filter((item) => Boolean(item?.id && item?.surah && item?.ayah));
}

export async function toggleBookmark(bookmark: QuranBookmark): Promise<{ active: boolean; items: QuranBookmark[] }> {
  const items = await loadBookmarks();
  const exists = items.some((item) => item.id === bookmark.id);
  const next = exists ? items.filter((item) => item.id !== bookmark.id) : [bookmark, ...items];
  await writeJson(QURAN_BOOKMARKS_KEY, next);
  return { active: !exists, items: next };
}

export function bookmarkId(surah: number, ayah: number): string {
  return `${surah}:${ayah}`;
}
