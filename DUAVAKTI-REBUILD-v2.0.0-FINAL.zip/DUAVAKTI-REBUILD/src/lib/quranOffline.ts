import { Directory, File, Paths } from 'expo-file-system';
import type { AyahPair } from '../types';

function safeReciter(reciter: string): string {
  return reciter.replace(/[^a-z0-9._-]/gi, '_');
}

function surahDirectory(reciter: string, surah: number): Directory {
  return new Directory(Paths.document, 'duavakti-quran-audio', safeReciter(reciter), String(surah));
}

function ayahFile(reciter: string, surah: number, ayah: number): File {
  return new File(surahDirectory(reciter, surah), `${ayah}.mp3`);
}

export function getOfflineAyahUri(reciter: string, surah: number, ayah: number): string | null {
  try {
    const file = ayahFile(reciter, surah, ayah);
    return file.exists ? file.uri : null;
  } catch {
    return null;
  }
}

export function isSurahDownloaded(reciter: string, surah: number, ayahs: AyahPair[]): boolean {
  const playable = ayahs.filter((item) => item.audio);
  if (!playable.length) return false;
  return playable.every((item) => Boolean(getOfflineAyahUri(reciter, surah, item.numberInSurah)));
}

export async function downloadSurahAudio(
  reciter: string,
  surah: number,
  ayahs: AyahPair[],
  onProgress?: (completed: number, total: number) => void,
): Promise<number> {
  const directory = surahDirectory(reciter, surah);
  directory.create({ idempotent: true, intermediates: true });
  const playable = ayahs.filter((item) => item.audio);
  let completed = 0;
  for (const item of playable) {
    const destination = ayahFile(reciter, surah, item.numberInSurah);
    if (!destination.exists && item.audio) {
      await File.downloadFileAsync(item.audio, destination, { idempotent: true });
    }
    completed += 1;
    onProgress?.(completed, playable.length);
  }
  return completed;
}

export function removeSurahAudio(reciter: string, surah: number): void {
  try {
    const directory = surahDirectory(reciter, surah);
    if (directory.exists) directory.delete();
  } catch {
    // Best effort.
  }
}

export function localizeAyahAudio(reciter: string, surah: number, ayahs: AyahPair[]): AyahPair[] {
  return ayahs.map((item) => ({
    ...item,
    audio: getOfflineAyahUri(reciter, surah, item.numberInSurah) ?? item.audio,
  }));
}
