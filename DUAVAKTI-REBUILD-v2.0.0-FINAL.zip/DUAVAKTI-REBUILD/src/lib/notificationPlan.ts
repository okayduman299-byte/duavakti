import type {
  PrayerApiResult,
  PrayerKey,
  PrayerNotificationSettings,
} from '../types';
import { PRAYER_LABELS, PRAYER_ORDER, timeOnDate } from './prayer';

export interface PrayerNotificationDay {
  date: Date;
  result: PrayerApiResult;
}

export type PrayerNotificationKind = 'prayer-time' | 'friday' | 'kerahat' | 'teravih';

export interface PrayerNotificationPlanItem {
  id: string;
  key?: PrayerKey;
  label: string;
  target: Date;
  title: string;
  body: string;
  kind: PrayerNotificationKind;
}

const ALL_ENABLED: PrayerNotificationSettings = {
  enabledByPrayer: { Fajr: true, Dhuhr: true, Asr: true, Maghrib: true, Isha: true },
  leadMinutes: 0,
  mode: 'sound',
  fridayReminder: false,
  kerahatReminder: false,
  teravihReminder: false,
};

function future(target: Date | null, now: Date): target is Date {
  return Boolean(target && target.getTime() > now.getTime());
}

export function buildPrayerNotificationPlan(
  days: PrayerNotificationDay[],
  settingsOrNow: PrayerNotificationSettings | Date = ALL_ENABLED,
  maybeNow = new Date(),
): PrayerNotificationPlanItem[] {
  const settings = settingsOrNow instanceof Date ? ALL_ENABLED : settingsOrNow;
  const now = settingsOrNow instanceof Date ? settingsOrNow : maybeNow;
  const plan: PrayerNotificationPlanItem[] = [];

  for (const { date, result } of days) {
    for (const key of PRAYER_ORDER) {
      if (!settings.enabledByPrayer[key]) continue;
      const actual = timeOnDate(date, result.timings[key]);
      if (!actual) continue;
      const target = new Date(actual.getTime() - settings.leadMinutes * 60_000);
      if (!future(target, now)) continue;

      const label = PRAYER_LABELS[key];
      const before = settings.leadMinutes > 0;
      plan.push({
        id: `${result.dateKey}:${result.locationKey}:${key}:${settings.leadMinutes}`,
        key,
        label,
        target,
        title: before ? `${label} vaktine ${settings.leadMinutes} dk kaldı` : `${label} vakti`,
        body: before
          ? `${result.locationLabel} için ${label} vakti ${result.timings[key]}.`
          : `${result.locationLabel} için ${label} vakti girdi.`,
        kind: 'prayer-time',
      });
    }

    if (settings.fridayReminder && date.getDay() === 5) {
      const dhuhr = timeOnDate(date, result.timings.Dhuhr);
      const target = dhuhr ? new Date(dhuhr.getTime() - 30 * 60_000) : null;
      if (future(target, now)) {
        plan.push({
          id: `${result.dateKey}:${result.locationKey}:friday`,
          label: 'Cuma',
          target,
          title: 'Cuma namazına 30 dakika kaldı',
          body: 'Abdest ve hazırlık için güzel bir vakit.',
          kind: 'friday',
        });
      }
    }

    if (settings.kerahatReminder && result.timings.Sunrise) {
      const sunrise = timeOnDate(date, result.timings.Sunrise);
      const target = sunrise ? new Date(sunrise.getTime() - 15 * 60_000) : null;
      if (future(target, now)) {
        plan.push({
          id: `${result.dateKey}:${result.locationKey}:kerahat`,
          label: 'Kerahat',
          target,
          title: 'Güneş doğuşuna 15 dakika kaldı',
          body: 'Kerahat vaktini hatırla ve ibadet planını buna göre düzenle.',
          kind: 'kerahat',
        });
      }
    }

    if (settings.teravihReminder && result.hijriMonth === 9) {
      const isha = timeOnDate(date, result.timings.Isha);
      const target = isha ? new Date(isha.getTime() + 20 * 60_000) : null;
      if (future(target, now)) {
        plan.push({
          id: `${result.dateKey}:${result.locationKey}:teravih`,
          label: 'Teravih',
          target,
          title: 'Teravih vakti',
          body: 'Ramazan gecesini teravih ve dua ile değerlendirebilirsin.',
          kind: 'teravih',
        });
      }
    }
  }

  return plan.sort((a, b) => a.target.getTime() - b.target.getTime());
}
