import type { ReciterOption } from '../types';

export const RECITERS: ReciterOption[] = [
  { id: 'ar.alafasy', name: 'Mişârî Râşid el-Afâsî', shortName: 'Afâsî' },
  { id: 'ar.abdulbasitmurattal', name: 'Abdülbâsit Abdüssamed', shortName: 'Abdülbâsit' },
  { id: 'ar.husary', name: 'Mahmûd Halîl el-Husarî', shortName: 'Husarî' },
  { id: 'ar.minshawi', name: 'Muhammed Sıddîk el-Minşâvî', shortName: 'Minşâvî' },
];

export function getReciter(id: string): ReciterOption {
  return RECITERS.find((item) => item.id === id) ?? RECITERS[0];
}
