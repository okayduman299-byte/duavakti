import * as Updates from 'expo-updates';
import { readJson, writeJson } from './storage';

const LAST_CHECK_KEY = 'duavakti:update:last-check:v1';
const MIN_INTERVAL_MS = 12 * 60 * 60 * 1000;

export type UpdateResult = 'disabled' | 'none' | 'downloaded';

export async function checkAndFetchUpdate(force = false): Promise<UpdateResult> {
  if (!Updates.isEnabled) return 'disabled';
  if (!force) {
    const last = await readJson<{ at: number }>(LAST_CHECK_KEY);
    if (last?.at && Date.now() - last.at < MIN_INTERVAL_MS) return 'none';
  }
  await writeJson(LAST_CHECK_KEY, { at: Date.now() });
  const check = await Updates.checkForUpdateAsync();
  if (!check.isAvailable) return 'none';
  await Updates.fetchUpdateAsync();
  return 'downloaded';
}

export async function applyDownloadedUpdate(): Promise<void> {
  await Updates.reloadAsync();
}
