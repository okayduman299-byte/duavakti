const KAABA_LAT = 21.4225;
const KAABA_LON = 39.8262;

function toRad(value: number): number {
  return value * Math.PI / 180;
}

export function distanceToKaabaKm(latitude: number, longitude: number): number {
  const earth = 6371;
  const dLat = toRad(KAABA_LAT - latitude);
  const dLon = toRad(KAABA_LON - longitude);
  const lat1 = toRad(latitude);
  const lat2 = toRad(KAABA_LAT);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  return earth * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function isPhoneFlat(zWithGravity: number): boolean {
  return Math.abs(zWithGravity) >= 7.6;
}
