export interface HijriParts {
  day: number;
  month: number;
  year: number;
}

export function parseHijriDate(value?: string | null): HijriParts | null {
  if (!value) return null;
  const match = value.match(/^(\d{1,2})-(\d{1,2})-(\d{3,4})$/);
  if (!match) return null;
  const day = Number(match[1]);
  const month = Number(match[2]);
  const year = Number(match[3]);
  if (!Number.isInteger(day) || day < 1 || day > 30) return null;
  if (!Number.isInteger(month) || month < 1 || month > 12) return null;
  if (!Number.isInteger(year) || year < 1) return null;
  return { day, month, year };
}

export function isRamadanMonth(month?: number | null): boolean {
  return month === 9;
}

export function formatHijriLabel(day?: number, month?: number, year?: number): string {
  if (!day || !month || !year) return 'Hicri tarih hazırlanıyor';
  const names = [
    '',
    'Muharrem',
    'Safer',
    'Rebiülevvel',
    'Rebiülahir',
    'Cemaziyelevvel',
    'Cemaziyelahir',
    'Recep',
    'Şaban',
    'Ramazan',
    'Şevval',
    'Zilkade',
    'Zilhicce',
  ];
  return `${day} ${names[month] ?? `${month}. ay`} ${year}`;
}

export function daysUntilEid(hijriDay?: number, hijriMonth?: number): number | null {
  if (!isRamadanMonth(hijriMonth) || !hijriDay) return null;
  return Math.max(0, 30 - hijriDay);
}
