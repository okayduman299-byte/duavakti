import type { PrayerApiResult } from '../types';
import { formatCountdown } from './time';
import { timeOnDate } from './prayer';

export interface RamadanCountdowns {
  sahur: string;
  iftar: string;
  sahurTarget: Date | null;
  iftarTarget: Date | null;
}

export function getRamadanCountdowns(now: Date, data: PrayerApiResult | null): RamadanCountdowns {
  if (!data) return { sahur: '--:--:--', iftar: '--:--:--', sahurTarget: null, iftarTarget: null };
  const fajr = timeOnDate(now, data.timings.Fajr);
  const maghrib = timeOnDate(now, data.timings.Maghrib);
  return {
    sahur: fajr && fajr.getTime() > now.getTime() ? formatCountdown(fajr.getTime() - now.getTime()) : 'Tamamlandı',
    iftar: maghrib && maghrib.getTime() > now.getTime() ? formatCountdown(maghrib.getTime() - now.getTime()) : 'Tamamlandı',
    sahurTarget: fajr,
    iftarTarget: maghrib,
  };
}

export function ramadanStartDate(today: Date, hijriDay?: number): Date {
  const start = new Date(today);
  const safeDay = Number.isInteger(hijriDay) && (hijriDay ?? 0) > 0 ? hijriDay! : 1;
  start.setDate(start.getDate() - (safeDay - 1));
  start.setHours(0, 0, 0, 0);
  return start;
}
