import type { ZikrPreset, ZikrState } from '../types';
import { toDateKey } from './time';

export const ZIKR_PRESETS: ZikrPreset[] = [
  { id: 'subhanallah', title: 'Sübhanallah', arabic: 'سُبْحَانَ اللَّهِ', target: 33 },
  { id: 'elhamdulillah', title: 'Elhamdülillah', arabic: 'الْحَمْدُ لِلَّهِ', target: 33 },
  { id: 'allahu-ekber', title: 'Allahu Ekber', arabic: 'اللَّهُ أَكْبَرُ', target: 33 },
  { id: 'la-ilahe-illallah', title: 'Lâ ilâhe illallah', arabic: 'لَا إِلٰهَ إِلَّا اللَّهُ', target: 100 },
];

export function defaultZikrState(now = new Date()): ZikrState {
  return {
    selectedId: ZIKR_PRESETS[0].id,
    count: 0,
    target: ZIKR_PRESETS[0].target,
    completedDates: [],
    updatedAt: now.toISOString(),
  };
}

export function markZikrProgress(state: ZikrState, count: number, now = new Date()): ZikrState {
  const dateKey = toDateKey(now);
  const completed = count >= state.target;
  const completedDates = completed && !state.completedDates.includes(dateKey)
    ? [...state.completedDates, dateKey].sort()
    : state.completedDates;
  return { ...state, count, completedDates, updatedAt: now.toISOString() };
}

export function calculateStreak(completedDates: string[], now = new Date()): number {
  const set = new Set(completedDates);
  let streak = 0;
  const cursor = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  for (let i = 0; i < 366; i += 1) {
    const key = toDateKey(cursor);
    if (!set.has(key)) break;
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
