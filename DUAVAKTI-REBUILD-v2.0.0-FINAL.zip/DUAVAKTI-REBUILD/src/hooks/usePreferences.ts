import { useEffect, useState } from 'react';
import type { AppPreferences } from '../types';
import { readJson, writeJson } from '../lib/storage';

const KEY = 'duavakti:preferences:v2';

const defaults: AppPreferences = {
  arabicVisible: true,
  quranFontScale: 1,
  quranReciter: 'ar.alafasy',
  quranPlaybackRate: 1,
  quranRepeatMode: 'off',
  city: 'Muradiye',
  country: 'Turkey',
  useGps: false,
  prayerNotifications: true,
  notificationSettings: {
    enabledByPrayer: {
      Fajr: true,
      Dhuhr: true,
      Asr: true,
      Maghrib: true,
      Isha: true,
    },
    leadMinutes: 0,
    mode: 'sound',
    fridayReminder: true,
    kerahatReminder: false,
    teravihReminder: true,
  },
  widgetSettings: {
    theme: 'dark',
    mode: 'balanced',
    showDua: true,
    showHijri: true,
    showCountdown: true,
  },
  autoUpdates: true,
  qiblaVibration: true,
};

function mergePreferences(stored: Partial<AppPreferences> | null): AppPreferences {
  if (!stored) return defaults;
  return {
    ...defaults,
    ...stored,
    notificationSettings: {
      ...defaults.notificationSettings,
      ...(stored.notificationSettings ?? {}),
      enabledByPrayer: {
        ...defaults.notificationSettings.enabledByPrayer,
        ...(stored.notificationSettings?.enabledByPrayer ?? {}),
      },
    },
    widgetSettings: {
      ...defaults.widgetSettings,
      ...(stored.widgetSettings ?? {}),
    },
  };
}

export function usePreferences() {
  const [preferences, setPreferences] = useState<AppPreferences>(defaults);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    readJson<Partial<AppPreferences>>(KEY).then((stored) => {
      setPreferences(mergePreferences(stored));
      setReady(true);
    });
  }, []);

  const update = (patch: Partial<AppPreferences>) => {
    setPreferences((current) => {
      const next: AppPreferences = {
        ...current,
        ...patch,
        notificationSettings: patch.notificationSettings
          ? {
              ...current.notificationSettings,
              ...patch.notificationSettings,
              enabledByPrayer: {
                ...current.notificationSettings.enabledByPrayer,
                ...(patch.notificationSettings.enabledByPrayer ?? {}),
              },
            }
          : current.notificationSettings,
        widgetSettings: patch.widgetSettings
          ? { ...current.widgetSettings, ...patch.widgetSettings }
          : current.widgetSettings,
      };
      void writeJson(KEY, next);
      return next;
    });
  };

  return { preferences, update, ready };
}

export { defaults as DEFAULT_PREFERENCES };
