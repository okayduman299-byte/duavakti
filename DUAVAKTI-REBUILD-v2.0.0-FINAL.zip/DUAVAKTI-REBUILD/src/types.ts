export type TabKey = 'home' | 'quran' | 'duas' | 'widget' | 'settings';

export type PrayerKey = 'Fajr' | 'Dhuhr' | 'Asr' | 'Maghrib' | 'Isha';
export type NotificationMode = 'sound' | 'vibrate' | 'silent';
export type NotificationLeadMinutes = 0 | 5 | 10 | 15 | 30;
export type WidgetTheme = 'dark' | 'light' | 'transparent';
export type WidgetMode = 'balanced' | 'next' | 'dua' | 'ramadan';
export type QuranRepeatMode = 'off' | 'ayah' | 'surah';

export interface PrayerTimes {
  Fajr: string;
  Sunrise?: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export interface PrayerLocation {
  mode: 'city' | 'gps';
  label: string;
  city?: string;
  country?: string;
  latitude?: number;
  longitude?: number;
}

export interface PrayerApiResult {
  dateKey: string;
  locationKey: string;
  locationLabel: string;
  timings: PrayerTimes;
  hijriDate?: string;
  hijriDay?: number;
  hijriMonth?: number;
  hijriYear?: number;
  source: 'network' | 'cache';
}

export interface NextPrayerResult {
  key: PrayerKey;
  label: string;
  time: string;
  target: Date;
}

export interface SurahSummary {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  turkishName: string;
  numberOfAyahs: number;
  revelationType: string;
}

export interface AyahPair {
  numberInSurah: number;
  arabic: string;
  translation: string;
  audio?: string;
}

export interface SurahContent {
  summary: SurahSummary;
  ayahs: AyahPair[];
}

export interface QuranProgress {
  surah: number;
  ayah: number;
  updatedAt: string;
}

export interface QuranBookmark {
  id: string;
  surah: number;
  surahName: string;
  ayah: number;
  arabic: string;
  translation: string;
  addedAt: string;
}

export interface ReciterOption {
  id: string;
  name: string;
  shortName: string;
}

export interface PrayerNotificationSettings {
  enabledByPrayer: Record<PrayerKey, boolean>;
  leadMinutes: NotificationLeadMinutes;
  mode: NotificationMode;
  fridayReminder: boolean;
  kerahatReminder: boolean;
  teravihReminder: boolean;
}

export interface WidgetSettings {
  theme: WidgetTheme;
  mode: WidgetMode;
  showDua: boolean;
  showHijri: boolean;
  showCountdown: boolean;
}

export interface AppPreferences {
  arabicVisible: boolean;
  quranFontScale: number;
  quranReciter: string;
  quranPlaybackRate: number;
  quranRepeatMode: QuranRepeatMode;
  city: string;
  country: string;
  useGps: boolean;
  prayerNotifications: boolean;
  notificationSettings: PrayerNotificationSettings;
  widgetSettings: WidgetSettings;
  autoUpdates: boolean;
  qiblaVibration: boolean;
}

export interface DailyCard {
  tag: string;
  title: string;
  meaning: string;
  arabic: string;
  reference: string;
}

export interface DuaItem {
  id: string;
  title: string;
  category: string;
  arabic: string;
  latin: string;
  meaning: string;
  source: string;
}

export interface ZikrPreset {
  id: string;
  title: string;
  arabic: string;
  target: number;
}

export interface ZikrState {
  selectedId: string;
  count: number;
  target: number;
  customTitle?: string;
  completedDates: string[];
  updatedAt: string;
}
