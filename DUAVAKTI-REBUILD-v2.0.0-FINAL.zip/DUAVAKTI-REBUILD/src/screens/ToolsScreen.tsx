import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { AppPreferences, NextPrayerResult, PrayerApiResult, PrayerLocation } from '../types';
import { WidgetScreen } from './WidgetScreen';
import { ZikrScreen } from './ZikrScreen';
import { RamadanScreen } from './RamadanScreen';
import { colors } from '../theme';

type ToolKey = 'widget' | 'zikr' | 'ramadan';

export function ToolsScreen({
  data,
  next,
  countdown,
  preferences,
  updatePreferences,
  activeLocation,
}: {
  data: PrayerApiResult | null;
  next: NextPrayerResult | null;
  countdown: string;
  preferences: AppPreferences;
  updatePreferences: (patch: Partial<AppPreferences>) => void;
  activeLocation: PrayerLocation;
}) {
  const [tool, setTool] = useState<ToolKey>('widget');
  return (
    <View style={styles.root}>
      <View style={styles.tabs}>
        {([
          ['widget', 'Widget'],
          ['zikr', 'Zikir'],
          ['ramadan', 'Ramazan'],
        ] as Array<[ToolKey, string]>).map(([key, label]) => (
          <Pressable key={key} style={[styles.tab, tool === key && styles.tabActive]} onPress={() => setTool(key)}>
            <Text style={[styles.tabText, tool === key && styles.tabTextActive]}>{label}</Text>
          </Pressable>
        ))}
      </View>
      <View style={styles.content}>
        {tool === 'zikr' ? <ZikrScreen /> : null}
        {tool === 'ramadan' ? <RamadanScreen data={data} location={activeLocation} /> : null}
        {tool === 'widget' ? (
          <WidgetScreen
            data={data}
            next={next}
            countdown={countdown}
            preferences={preferences}
            updatePreferences={updatePreferences}
          />
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  tabs: { flexDirection: 'row', marginHorizontal: 18, marginTop: 10, marginBottom: 2, backgroundColor: colors.surface, borderRadius: 18, padding: 5 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 14 },
  tabActive: { backgroundColor: colors.accentSoft },
  tabText: { color: colors.textMuted, fontWeight: '800', fontSize: 12 },
  tabTextActive: { color: colors.text },
  content: { flex: 1 },
});
