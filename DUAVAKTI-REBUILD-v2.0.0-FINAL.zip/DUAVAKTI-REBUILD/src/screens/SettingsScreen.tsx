import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import type {
  AppPreferences,
  NotificationLeadMinutes,
  NotificationMode,
  PrayerKey,
  PrayerLocation,
} from '../types';
import { QiblaCompass } from '../components/QiblaCompass';
import { PRAYER_LABELS, PRAYER_ORDER } from '../lib/prayer';
import { applyDownloadedUpdate, checkAndFetchUpdate } from '../lib/updateService';
import { colors, radii } from '../theme';

const LEADS: NotificationLeadMinutes[] = [0, 5, 10, 15, 30];
const MODES: Array<{ key: NotificationMode; label: string }> = [
  { key: 'sound', label: 'Sesli' },
  { key: 'vibrate', label: 'Titreşim' },
  { key: 'silent', label: 'Sessiz' },
];

export function SettingsScreen({
  preferences,
  updatePreferences,
  activeLocation,
  onRefresh,
}: {
  preferences: AppPreferences;
  updatePreferences: (patch: Partial<AppPreferences>) => void;
  activeLocation: PrayerLocation;
  onRefresh: () => void;
}) {
  const [city, setCity] = useState(preferences.city);
  const [updateStatus, setUpdateStatus] = useState<string | null>(null);
  const [updateReady, setUpdateReady] = useState(false);

  const saveCity = () => {
    const clean = city.trim();
    if (!clean) return;
    updatePreferences({ city: clean, useGps: false });
    setTimeout(onRefresh, 0);
  };

  const patchNotifications = (patch: Partial<AppPreferences['notificationSettings']>) => {
    updatePreferences({
      notificationSettings: {
        ...preferences.notificationSettings,
        ...patch,
        enabledByPrayer: {
          ...preferences.notificationSettings.enabledByPrayer,
          ...(patch.enabledByPrayer ?? {}),
        },
      },
    });
  };

  const togglePrayer = (key: PrayerKey, value: boolean) => {
    patchNotifications({ enabledByPrayer: { ...preferences.notificationSettings.enabledByPrayer, [key]: value } });
  };

  const checkUpdate = async () => {
    setUpdateReady(false);
    setUpdateStatus('Güncelleme denetleniyor…');
    try {
      const result = await checkAndFetchUpdate(true);
      if (result === 'disabled') setUpdateStatus('Bu build’de hızlı güncelleme etkin değil. Yeni APK/AAB gerekir.');
      else if (result === 'none') setUpdateStatus('DuaVakti güncel.');
      else {
        setUpdateStatus('Yeni güncelleme indirildi. Uygulamayı yenileyebilirsin.');
        setUpdateReady(true);
      }
    } catch (error) {
      setUpdateStatus(error instanceof Error ? error.message : 'Güncelleme denetlenemedi.');
    }
  };

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <Text style={styles.eyebrow}>AYARLAR</Text>
      <Text style={styles.title}>DuaVakti sana göre çalışsın.</Text>

      <QiblaCompass activeLocation={activeLocation} vibrateOnAlign={preferences.qiblaVibration} />

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Konum ve vakitler</Text>
        <Text style={styles.label}>Şehir</Text>
        <View style={styles.inputRow}>
          <TextInput value={city} onChangeText={setCity} style={styles.input} placeholder="Muradiye" placeholderTextColor={colors.textDim} />
          <Pressable style={styles.saveButton} onPress={saveCity}><Text style={styles.saveText}>Kaydet</Text></Pressable>
        </View>
        <Text style={styles.help}>Türkiye için Diyanet hesaplama yöntemiyle vakit servisi kullanılır. GPS seçildiyse koordinat bazlı sonuç alınır.</Text>
      </View>

      <View style={styles.card}>
        <View style={styles.settingRow}>
          <View style={styles.settingText}><Text style={styles.cardTitle}>Ezan ve vakit uyarıları</Text><Text style={styles.help}>Ana bildirim anahtarı. Ayrıntıları aşağıdan belirleyebilirsin.</Text></View>
          <Switch value={preferences.prayerNotifications} onValueChange={(value) => updatePreferences({ prayerNotifications: value })} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} />
        </View>
        <Text style={styles.sectionLabel}>HANGİ VAKİTLER?</Text>
        {PRAYER_ORDER.map((key) => (
          <View key={key} style={styles.miniRow}>
            <Text style={styles.miniLabel}>{PRAYER_LABELS[key]}</Text>
            <Switch value={preferences.notificationSettings.enabledByPrayer[key]} onValueChange={(value) => togglePrayer(key, value)} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} />
          </View>
        ))}

        <Text style={styles.sectionLabel}>NE ZAMAN?</Text>
        <View style={styles.chipWrap}>
          {LEADS.map((lead) => (
            <Pressable key={lead} style={[styles.chip, preferences.notificationSettings.leadMinutes === lead && styles.chipActive]} onPress={() => patchNotifications({ leadMinutes: lead })}>
              <Text style={styles.chipText}>{lead === 0 ? 'Vaktinde' : `${lead} dk önce`}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.sectionLabel}>UYARI ŞEKLİ</Text>
        <View style={styles.chipWrap}>
          {MODES.map((mode) => (
            <Pressable key={mode.key} style={[styles.chip, preferences.notificationSettings.mode === mode.key && styles.chipActive]} onPress={() => patchNotifications({ mode: mode.key })}>
              <Text style={styles.chipText}>{mode.label}</Text>
            </Pressable>
          ))}
        </View>

        <View style={styles.divider} />
        <ToggleRow title="Cuma namazı hatırlatıcısı" help="Cuma günü öğle vaktinden 30 dakika önce hatırlatır." value={preferences.notificationSettings.fridayReminder} onChange={(value) => patchNotifications({ fridayReminder: value })} />
        <View style={styles.divider} />
        <ToggleRow title="Kerahat uyarısı" help="Güneş doğuşundan 15 dakika önce hatırlatır." value={preferences.notificationSettings.kerahatReminder} onChange={(value) => patchNotifications({ kerahatReminder: value })} />
        <View style={styles.divider} />
        <ToggleRow title="Teravih hatırlatıcısı" help="Ramazan ayında yatsıdan sonra teravih için hatırlatır." value={preferences.notificationSettings.teravihReminder} onChange={(value) => patchNotifications({ teravihReminder: value })} />
      </View>

      <View style={styles.card}>
        <ToggleRow title="Arapça ayetleri göster" help="Kur’an okuyucusunda Arapça metni açıp kapatır." value={preferences.arabicVisible} onChange={(value) => updatePreferences({ arabicVisible: value })} />
        <View style={styles.divider} />
        <ToggleRow title="GPS konumu" help="Şehir yerine son alınan cihaz konumunu namaz vakitleri için kullanır." value={preferences.useGps} onChange={(value) => updatePreferences({ useGps: value })} />
        <View style={styles.divider} />
        <ToggleRow title="Kıble hizasında titreşim" help="Kıble yönüne geldiğinde kısa bir titreşim verir." value={preferences.qiblaVibration} onChange={(value) => updatePreferences({ qiblaVibration: value })} />
      </View>

      <View style={styles.card}>
        <ToggleRow title="Hızlı uygulama güncellemeleri" help="Yeni JavaScript ve içerik düzeltmelerini mağaza/APK beklemeden almayı dener. Native değişikliklerde yine yeni build gerekir." value={preferences.autoUpdates} onChange={(value) => updatePreferences({ autoUpdates: value })} />
        <Pressable style={styles.updateButton} onPress={() => void checkUpdate()}><Text style={styles.updateButtonText}>Güncellemeyi şimdi denetle</Text></Pressable>
        {updateReady ? <Pressable style={styles.applyButton} onPress={() => void applyDownloadedUpdate()}><Text style={styles.applyButtonText}>İndirilen güncellemeyi uygula</Text></Pressable> : null}
        {updateStatus ? <Text style={styles.updateStatus}>{updateStatus}</Text> : null}
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Uygulama hakkında</Text>
        <Text style={styles.help}>DuaVakti 2.0.0 · Gelişmiş ezan uyarıları, Kur’an favorileri ve çevrimdışı ses, zikir, Ramazan modu, kişiselleştirilebilir widgetlar, akıllı kıble ve hızlı güncelleme sistemi.</Text>
      </View>
      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

function ToggleRow({ title, help, value, onChange }: { title: string; help: string; value: boolean; onChange: (value: boolean) => void }) {
  return (
    <View style={styles.settingRow}>
      <View style={styles.settingText}><Text style={styles.cardTitle}>{title}</Text><Text style={styles.help}>{help}</Text></View>
      <Switch value={value} onValueChange={onChange} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24 },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '900', letterSpacing: 2.2, marginBottom: 12 },
  title: { color: colors.text, fontSize: 34, lineHeight: 42, fontWeight: '900', marginBottom: 24 },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 18, marginBottom: 14 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '900' },
  label: { color: colors.textMuted, fontSize: 12, marginTop: 18, marginBottom: 8 },
  inputRow: { flexDirection: 'row' },
  input: { flex: 1, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 14, color: colors.text, paddingHorizontal: 14, paddingVertical: 12, marginRight: 8 },
  saveButton: { backgroundColor: colors.accentSoft, borderRadius: 14, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 15 },
  saveText: { color: colors.text, fontWeight: '800' },
  help: { color: colors.textMuted, fontSize: 12, lineHeight: 19, marginTop: 7 },
  settingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  settingText: { flex: 1, paddingRight: 16 },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 16 },
  sectionLabel: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.5, marginTop: 20, marginBottom: 9 },
  miniRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 6 },
  miniLabel: { color: colors.text, fontSize: 14, fontWeight: '800' },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 99, paddingHorizontal: 12, paddingVertical: 9 },
  chipActive: { backgroundColor: colors.accentSoft, borderColor: colors.accent },
  chipText: { color: colors.text, fontSize: 11, fontWeight: '800' },
  updateButton: { marginTop: 18, backgroundColor: colors.accentSoft, borderRadius: 14, paddingVertical: 13, alignItems: 'center' },
  updateButtonText: { color: colors.text, fontWeight: '900' },
  applyButton: { marginTop: 8, backgroundColor: colors.greenDeep, borderWidth: 1, borderColor: colors.accent, borderRadius: 14, paddingVertical: 13, alignItems: 'center' },
  applyButtonText: { color: colors.text, fontWeight: '900' },
  updateStatus: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 10 },
});
