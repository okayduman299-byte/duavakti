import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { PrayerApiResult, PrayerLocation } from '../types';
import { DUAS } from '../data/duas';
import { dayIndex, formatTurkishDate, toDateKey } from '../lib/time';
import { daysUntilEid, formatHijriLabel, isRamadanMonth } from '../lib/hijri';
import { getRamadanCountdowns, ramadanStartDate } from '../lib/ramadan';
import { loadPrayerTimes } from '../lib/prayerService';
import { readJson, writeJson } from '../lib/storage';
import { colors, radii } from '../theme';

const FASTING_KEY = 'duavakti:ramadan:fasting:v1';

export function RamadanScreen({ data, location }: { data: PrayerApiResult | null; location: PrayerLocation }) {
  const [now, setNow] = useState(new Date());
  const [fastedDates, setFastedDates] = useState<string[]>([]);
  const [calendar, setCalendar] = useState<PrayerApiResult[]>([]);
  const [calendarStatus, setCalendarStatus] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    void readJson<string[]>(FASTING_KEY).then((value) => Array.isArray(value) && setFastedDates(value));
    return () => clearInterval(timer);
  }, []);

  const active = isRamadanMonth(data?.hijriMonth);
  const countdowns = getRamadanCountdowns(now, data);
  const eidDays = daysUntilEid(data?.hijriDay, data?.hijriMonth);
  const todayKey = toDateKey(now);
  const fastedToday = fastedDates.includes(todayKey);
  const dua = DUAS[dayIndex(now, DUAS.length)];

  const toggleFast = () => {
    const next = fastedToday ? fastedDates.filter((item) => item !== todayKey) : [...fastedDates, todayKey];
    setFastedDates(next);
    void writeJson(FASTING_KEY, next);
  };

  const loadCalendar = async () => {
    if (!active) {
      setCalendarStatus('30 günlük takvim Ramazan ayı başladığında aktif olur.');
      return;
    }
    setCalendarStatus('30 günlük Ramazan takvimi hazırlanıyor…');
    const start = ramadanStartDate(now, data?.hijriDay);
    const results: PrayerApiResult[] = [];
    for (let index = 0; index < 30; index += 1) {
      const date = new Date(start);
      date.setDate(date.getDate() + index);
      try {
        const result = await loadPrayerTimes(date, location);
        results.push(result);
        setCalendarStatus(`${results.length}/30 gün hazır`);
      } catch {
        // Eksik günler daha sonra yeniden yüklenebilir.
      }
    }
    setCalendar(results);
    setCalendarStatus(results.length ? `${results.length} günlük takvim hazır.` : 'Takvim alınamadı. Daha sonra tekrar dene.');
  };

  useEffect(() => {
    if (active && !calendar.length) void loadCalendar();
  }, [active, data?.hijriYear]);

  const summary = useMemo(() => ({
    fasted: fastedDates.length,
    remaining: eidDays,
  }), [eidDays, fastedDates.length]);

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <Text style={styles.eyebrow}>RAMAZAN MODU</Text>
      <Text style={styles.title}>{active ? 'Ramazan bereketi tek ekranda.' : 'Ramazan geldiğinde otomatik dönüşür.'}</Text>
      <Text style={styles.hijri}>{formatHijriLabel(data?.hijriDay, data?.hijriMonth, data?.hijriYear)}</Text>

      <View style={styles.hero}>
        <View style={styles.countdownCol}><Text style={styles.heroEyebrow}>SAHURA KALAN</Text><Text style={styles.heroValue}>{active ? countdowns.sahur : '--:--:--'}</Text></View>
        <View style={styles.heroDivider} />
        <View style={styles.countdownCol}><Text style={styles.heroEyebrow}>İFTARA KALAN</Text><Text style={styles.heroValue}>{active ? countdowns.iftar : '--:--:--'}</Text></View>
      </View>

      <View style={styles.statRow}>
        <View style={styles.statCard}><Text style={styles.statValue}>{summary.fasted}</Text><Text style={styles.statLabel}>işaretlenen oruç</Text></View>
        <View style={styles.statCard}><Text style={styles.statValue}>{summary.remaining ?? '—'}</Text><Text style={styles.statLabel}>bayrama kalan gün</Text></View>
      </View>

      <Pressable style={[styles.fastButton, fastedToday && styles.fastButtonActive]} onPress={toggleFast}>
        <Text style={styles.fastButtonText}>{fastedToday ? '✓ Bugün oruç tuttum' : 'Bugün oruç tuttum'}</Text>
      </Pressable>

      <View style={styles.card}>
        <Text style={styles.cardEyebrow}>GÜNÜN RAMAZAN DUASI</Text>
        <Text style={styles.cardTitle}>{dua.title}</Text>
        <Text style={styles.cardMeaning}>{dua.meaning}</Text>
        <Text style={styles.cardSource}>{dua.source}</Text>
      </View>

      <View style={styles.calendarHeader}>
        <View><Text style={styles.cardEyebrow}>30 GÜNLÜK TAKVİM</Text><Text style={styles.calendarTitle}>Sahur ve iftar saatleri</Text></View>
        <Pressable style={styles.reloadButton} onPress={() => void loadCalendar()}><Text style={styles.reloadText}>↻</Text></Pressable>
      </View>
      {calendarStatus ? <Text style={styles.status}>{calendarStatus}</Text> : null}
      {calendar.map((item, index) => (
        <View key={`${item.dateKey}:${index}`} style={styles.calendarRow}>
          <View><Text style={styles.dayLabel}>{index + 1}. gün</Text><Text style={styles.dateLabel}>{formatTurkishDate(new Date(`${item.dateKey}T12:00:00`))}</Text></View>
          <View style={styles.times}><Text style={styles.timeLabel}>Sahur {item.timings.Fajr}</Text><Text style={styles.timeLabel}>İftar {item.timings.Maghrib}</Text></View>
        </View>
      ))}
      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24 },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '900', letterSpacing: 2.2, marginBottom: 12 },
  title: { color: colors.text, fontSize: 32, lineHeight: 40, fontWeight: '900' },
  hijri: { color: colors.textMuted, fontSize: 14, marginTop: 10 },
  hero: { marginTop: 20, backgroundColor: colors.greenDeep, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.xl, padding: 22, flexDirection: 'row' },
  countdownCol: { flex: 1, alignItems: 'center' },
  heroDivider: { width: 1, backgroundColor: colors.borderStrong },
  heroEyebrow: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  heroValue: { color: colors.text, fontSize: 26, fontWeight: '900', marginTop: 10 },
  statRow: { flexDirection: 'row', gap: 10, marginTop: 14 },
  statCard: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 18, alignItems: 'center' },
  statValue: { color: colors.text, fontSize: 28, fontWeight: '900' },
  statLabel: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  fastButton: { backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.md, paddingVertical: 16, alignItems: 'center', marginTop: 14 },
  fastButtonActive: { borderColor: colors.accent },
  fastButtonText: { color: colors.text, fontWeight: '900' },
  card: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 20, marginTop: 14 },
  cardEyebrow: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  cardTitle: { color: colors.text, fontSize: 21, fontWeight: '900', marginTop: 10 },
  cardMeaning: { color: colors.text, fontSize: 15, lineHeight: 24, marginTop: 12 },
  cardSource: { color: colors.textMuted, fontSize: 12, marginTop: 10 },
  calendarHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 28, marginBottom: 8 },
  calendarTitle: { color: colors.text, fontSize: 20, fontWeight: '900', marginTop: 5 },
  reloadButton: { width: 46, height: 46, borderRadius: 16, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  reloadText: { color: colors.text, fontSize: 24 },
  status: { color: colors.textMuted, fontSize: 12, marginBottom: 8 },
  calendarRow: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.md, padding: 15, marginTop: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  dayLabel: { color: colors.text, fontWeight: '900' },
  dateLabel: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  times: { alignItems: 'flex-end', gap: 4 },
  timeLabel: { color: colors.accent, fontSize: 12, fontWeight: '800' },
});
