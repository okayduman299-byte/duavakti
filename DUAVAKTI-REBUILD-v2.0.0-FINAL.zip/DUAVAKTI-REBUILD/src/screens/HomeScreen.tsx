import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import type { PrayerApiResult, NextPrayerResult, QuranProgress } from '../types';
import { DAILY_CARDS } from '../data/cards';
import { DUAS } from '../data/duas';
import { dayIndex, formatTurkishDate } from '../lib/time';
import { PrayerCard } from '../components/PrayerCard';
import { ErrorState, LoadingState } from '../components/States';
import { colors, radii, spacing } from '../theme';
import { formatHijriLabel, isRamadanMonth } from '../lib/hijri';
import { getRamadanCountdowns } from '../lib/ramadan';
import { loadQuranProgress } from '../lib/quranProgress';
import { getTurkishSurahName } from '../data/surahNames';

export function HomeScreen({
  data,
  loading,
  error,
  next,
  countdown,
  onRefresh,
  onLocate,
  onOpenQuran,
  onOpenTools,
}: {
  data: PrayerApiResult | null;
  loading: boolean;
  error: string | null;
  next: NextPrayerResult | null;
  countdown: string;
  onRefresh: () => void;
  onLocate: () => void;
  onOpenQuran: () => void;
  onOpenTools: () => void;
}) {
  const [now, setNow] = useState(new Date());
  const [progress, setProgress] = useState<QuranProgress | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    void loadQuranProgress().then(setProgress);
    return () => clearInterval(timer);
  }, []);

  const card = useMemo(() => DAILY_CARDS[dayIndex(now, DAILY_CARDS.length)], [now.getDate()]);
  const hourlyDua = useMemo(() => DUAS[dayIndex(new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours()), DUAS.length)], [now.getHours(), now.getDate()]);
  const ramadan = isRamadanMonth(data?.hijriMonth);
  const ramadanCountdowns = getRamadanCountdowns(now, data);

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <View>
          <Text style={styles.appName}>DuaVakti</Text>
          <Text style={styles.subtitle}>{formatTurkishDate(now)} · {data?.locationLabel ?? 'Muradiye'}</Text>
          {data ? <Text style={styles.hijri}>{formatHijriLabel(data.hijriDay, data.hijriMonth, data.hijriYear)}</Text> : null}
        </View>
        <Pressable style={styles.locationButton} onPress={onLocate} accessibilityLabel="Konumumu kullan">
          <Text style={styles.locationIcon}>⌖</Text>
        </Pressable>
      </View>

      {loading && !data ? <LoadingState label="Namaz vakitleri yükleniyor…" /> : null}
      {error && !data ? <ErrorState title="Vakitler alınamadı" detail={error} onRetry={onRefresh} /> : null}
      {data && next ? <PrayerCard next={next} countdown={countdown} timings={data.timings} /> : null}
      {data?.source === 'cache' ? <Text style={styles.cacheNote}>Çevrimdışı kayıtlı vakitler gösteriliyor.</Text> : null}

      <Text style={styles.todayEyebrow}>BUGÜN</Text>
      <Text style={styles.todayTitle}>İhtiyacın olan her şey tek bakışta.</Text>
      <View style={styles.todayGrid}>
        <View style={styles.todayCard}>
          <Text style={styles.todayLabel}>SIRADAKİ VAKİT</Text>
          <Text style={styles.todayValue}>{next?.label ?? '—'} · {next?.time ?? '--:--'}</Text>
          <Text style={styles.todayMeta}>{countdown} kaldı</Text>
        </View>
        <View style={styles.todayCard}>
          <Text style={styles.todayLabel}>SAATİN DUASI</Text>
          <Text numberOfLines={2} style={styles.todayValue}>{hourlyDua.title}</Text>
          <Text numberOfLines={2} style={styles.todayMeta}>{hourlyDua.meaning}</Text>
        </View>
      </View>

      <View style={styles.continueRow}>
        <Pressable style={styles.continueCard} onPress={onOpenQuran}>
          <Text style={styles.todayLabel}>OKUMAYA DEVAM ET</Text>
          <Text style={styles.continueTitle}>{progress ? `${getTurkishSurahName(progress.surah)} · ${progress.ayah}. ayet` : 'Kur’an okumaya başla'}</Text>
          <Text style={styles.continueArrow}>→</Text>
        </Pressable>
        <Pressable style={styles.toolsCard} onPress={onOpenTools}>
          <Text style={styles.todayLabel}>ARAÇLAR</Text>
          <Text style={styles.toolsTitle}>Zikir · Ramazan · Widget</Text>
          <Text style={styles.continueArrow}>→</Text>
        </Pressable>
      </View>

      {ramadan ? (
        <Pressable style={styles.ramadanCard} onPress={onOpenTools}>
          <Text style={styles.ramadanEyebrow}>RAMAZAN MODU AKTİF</Text>
          <View style={styles.ramadanRow}>
            <View style={styles.ramadanCol}><Text style={styles.ramadanLabel}>Sahura kalan</Text><Text style={styles.ramadanValue}>{ramadanCountdowns.sahur}</Text></View>
            <View style={styles.ramadanDivider} />
            <View style={styles.ramadanCol}><Text style={styles.ramadanLabel}>İftara kalan</Text><Text style={styles.ramadanValue}>{ramadanCountdowns.iftar}</Text></View>
          </View>
        </Pressable>
      ) : null}

      <View style={styles.sectionHeader}>
        <View>
          <Text style={styles.eyebrow}>GÜNÜN AYETİ</Text>
          <Text style={styles.sectionTitle}>Bir an dur, hatırla.</Text>
        </View>
        <Pressable style={styles.refreshButton} onPress={onRefresh}><Text style={styles.refreshText}>↻</Text></Pressable>
      </View>

      <View style={styles.dailyCard}>
        <View style={styles.meaningCol}>
          <Text style={styles.cardTag}>{card.tag}</Text>
          <Text style={styles.cardMeaning}>{card.meaning}</Text>
          <Text style={styles.reference}>{card.reference}</Text>
        </View>
        <View style={styles.verticalDivider} />
        <View style={styles.arabicCol}>
          <Text style={styles.arabic}>{card.arabic}</Text>
        </View>
      </View>
      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { paddingHorizontal: 24, paddingTop: 24 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  appName: { color: colors.text, fontSize: 38, fontWeight: '900', letterSpacing: -1.2 },
  subtitle: { color: colors.textMuted, fontSize: 15, marginTop: 7 },
  hijri: { color: colors.accent, fontSize: 12, fontWeight: '800', marginTop: 5 },
  locationButton: { width: 60, height: 60, borderRadius: 23, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  locationIcon: { color: colors.text, fontSize: 28 },
  cacheNote: { color: colors.warning, fontSize: 12, marginTop: 9, marginLeft: 4 },
  todayEyebrow: { color: colors.accent, fontWeight: '900', letterSpacing: 2.2, fontSize: 12, marginTop: 30 },
  todayTitle: { color: colors.text, fontSize: 27, fontWeight: '900', marginTop: 8, marginBottom: 14 },
  todayGrid: { flexDirection: 'row', gap: 10 },
  todayCard: { flex: 1, minHeight: 150, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 16 },
  todayLabel: { color: colors.accent, fontSize: 9, fontWeight: '900', letterSpacing: 1.3 },
  todayValue: { color: colors.text, fontSize: 18, lineHeight: 24, fontWeight: '900', marginTop: 10 },
  todayMeta: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 8 },
  continueRow: { flexDirection: 'row', gap: 10, marginTop: 10 },
  continueCard: { flex: 1.2, minHeight: 120, backgroundColor: colors.greenCard, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.lg, padding: 16 },
  toolsCard: { flex: 1, minHeight: 120, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 16 },
  continueTitle: { color: colors.text, fontSize: 16, lineHeight: 22, fontWeight: '900', marginTop: 10 },
  toolsTitle: { color: colors.text, fontSize: 15, lineHeight: 21, fontWeight: '800', marginTop: 10 },
  continueArrow: { color: colors.accent, fontSize: 24, marginTop: 8 },
  ramadanCard: { marginTop: 12, backgroundColor: colors.greenDeep, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.xl, padding: 20 },
  ramadanEyebrow: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.5 },
  ramadanRow: { flexDirection: 'row', marginTop: 15 },
  ramadanCol: { flex: 1, alignItems: 'center' },
  ramadanDivider: { width: 1, backgroundColor: colors.borderStrong },
  ramadanLabel: { color: colors.textMuted, fontSize: 11 },
  ramadanValue: { color: colors.text, fontSize: 22, fontWeight: '900', marginTop: 7 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 38, marginBottom: 20 },
  eyebrow: { color: colors.textMuted, fontWeight: '900', letterSpacing: 2.2, fontSize: 12, marginBottom: 12 },
  sectionTitle: { color: colors.text, fontSize: 29, fontWeight: '900', letterSpacing: -0.8 },
  refreshButton: { width: 54, height: 54, borderRadius: 20, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  refreshText: { color: colors.text, fontSize: 26 },
  dailyCard: { minHeight: 360, backgroundColor: colors.greenDeep, borderRadius: radii.xl, borderWidth: 1, borderColor: '#1D6A4C', flexDirection: 'row', padding: spacing.xl },
  meaningCol: { flex: 1, paddingRight: 20 },
  cardTag: { color: colors.accent, fontWeight: '900', letterSpacing: 2, fontSize: 12, marginBottom: 20 },
  cardMeaning: { color: colors.text, fontSize: 25, lineHeight: 39, fontWeight: '700' },
  reference: { color: colors.textMuted, marginTop: 22, fontSize: 13 },
  verticalDivider: { width: 1, backgroundColor: '#4B7E68', marginVertical: 2 },
  arabicCol: { flex: 1.15, justifyContent: 'center', paddingLeft: 22 },
  arabic: { color: colors.text, fontSize: 28, lineHeight: 53, textAlign: 'right', writingDirection: 'rtl' },
});
