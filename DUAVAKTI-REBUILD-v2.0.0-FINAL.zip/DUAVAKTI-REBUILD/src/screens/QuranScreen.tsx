import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import type {
  AppPreferences,
  AyahPair,
  QuranBookmark,
  QuranProgress,
  QuranRepeatMode,
  SurahContent,
  SurahSummary,
} from '../types';
import { loadSurah, loadSurahList } from '../lib/quranService';
import { matchesSurah, normalizeSurahSummary } from '../lib/quran';
import { getTurkishRevelationType } from '../data/surahNames';
import { ErrorState, LoadingState } from '../components/States';
import { colors, radii } from '../theme';
import { RECITERS, getReciter } from '../lib/reciters';
import {
  bookmarkId,
  loadBookmarks,
  loadQuranProgress,
  saveQuranProgress,
  toggleBookmark,
} from '../lib/quranProgress';
import {
  downloadSurahAudio,
  getOfflineAyahUri,
  isSurahDownloaded,
  removeSurahAudio,
} from '../lib/quranOffline';

const SPEEDS = [0.75, 1, 1.25] as const;
const SLEEP_OPTIONS = [0, 5, 10, 15, 30] as const;

function repeatLabel(mode: QuranRepeatMode): string {
  if (mode === 'ayah') return 'Ayet tekrarı';
  if (mode === 'surah') return 'Sure tekrarı';
  return 'Tekrar kapalı';
}

function safeAyahIndex(content: SurahContent | null, ayah: number): number {
  if (!content?.ayahs.length) return -1;
  return content.ayahs.findIndex((item) => item.numberInSurah === ayah);
}

export function QuranScreen({
  preferences,
  updatePreferences,
}: {
  preferences: AppPreferences;
  updatePreferences: (patch: Partial<AppPreferences>) => void;
}) {
  const [list, setList] = useState<SurahSummary[]>([]);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<SurahSummary | null>(null);
  const [content, setContent] = useState<SurahContent | null>(null);
  const [listLoading, setListLoading] = useState(true);
  const [readerLoading, setReaderLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [source, setSource] = useState<'network' | 'cache' | null>(null);
  const [progress, setProgress] = useState<QuranProgress | null>(null);
  const [bookmarks, setBookmarks] = useState<QuranBookmark[]>([]);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [activeAudioIndex, setActiveAudioIndex] = useState<number | null>(null);
  const [sleepMinutes, setSleepMinutes] = useState<number>(0);
  const [sleepStatus, setSleepStatus] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<string | null>(null);
  const [downloaded, setDownloaded] = useState(false);

  const ayahListRef = useRef<FlatList<AyahPair>>(null);
  const mountedRef = useRef(true);
  const autoContinueRef = useRef(false);
  const lastDidFinishRef = useRef(false);
  const pendingAyahRef = useRef<number | null>(null);
  const sleepTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const player = useAudioPlayer(null, { updateInterval: 350 });
  const playerStatus = useAudioPlayerStatus(player);

  useEffect(() => () => {
    mountedRef.current = false;
    if (sleepTimerRef.current) clearTimeout(sleepTimerRef.current);
  }, []);

  useEffect(() => {
    void setAudioModeAsync({
      playsInSilentMode: true,
      interruptionMode: 'doNotMix',
    }).catch(() => undefined);
  }, []);

  useEffect(() => {
    try {
      player.setPlaybackRate(preferences.quranPlaybackRate);
    } catch {
      // Hız desteği olmayan cihazlarda normal hızda devam edilir.
    }
  }, [player, preferences.quranPlaybackRate]);

  const playableAyahs = useMemo(
    () => (Array.isArray(content?.ayahs) ? content.ayahs.filter((item) => Boolean(item.audio)) : []),
    [content],
  );

  const activeAyah = activeAudioIndex !== null
    ? (playableAyahs[activeAudioIndex]?.numberInSurah ?? null)
    : null;

  const resolveAudio = (item: AyahPair): string | undefined => {
    if (!selected) return item.audio;
    return getOfflineAyahUri(preferences.quranReciter, selected.number, item.numberInSurah) ?? item.audio;
  };

  const scrollToAyah = (ayah: number, animated = true) => {
    const index = safeAyahIndex(content, ayah);
    if (index < 0) return;
    setTimeout(() => {
      ayahListRef.current?.scrollToIndex({ index, animated, viewPosition: 0.16 });
    }, 120);
  };

  const persistProgress = (surah: number, ayah: number) => {
    void saveQuranProgress(surah, ayah).then((value) => {
      if (mountedRef.current) setProgress(value);
    });
  };

  useEffect(() => {
    const wasFinished = lastDidFinishRef.current;
    lastDidFinishRef.current = playerStatus.didJustFinish;
    if (!playerStatus.didJustFinish || wasFinished || activeAudioIndex === null) return;

    const current = playableAyahs[activeAudioIndex];
    if (!current) return;

    if (preferences.quranRepeatMode === 'ayah') {
      const sourceUri = resolveAudio(current);
      if (sourceUri) {
        player.replace(sourceUri);
        player.setPlaybackRate(preferences.quranPlaybackRate);
        player.play();
      }
      return;
    }

    const nextIndex = activeAudioIndex + 1;
    const next = playableAyahs[nextIndex];
    if (autoContinueRef.current && next) {
      const sourceUri = resolveAudio(next);
      if (sourceUri) {
        setActiveAudioIndex(nextIndex);
        persistProgress(selected?.number ?? content?.summary.number ?? 1, next.numberInSurah);
        player.replace(sourceUri);
        player.setPlaybackRate(preferences.quranPlaybackRate);
        player.play();
        setAudioError(null);
        return;
      }
    }

    if (preferences.quranRepeatMode === 'surah' && playableAyahs[0]) {
      const first = playableAyahs[0];
      const sourceUri = resolveAudio(first);
      if (sourceUri) {
        setActiveAudioIndex(0);
        persistProgress(selected?.number ?? content?.summary.number ?? 1, first.numberInSurah);
        player.replace(sourceUri);
        player.setPlaybackRate(preferences.quranPlaybackRate);
        player.play();
        return;
      }
    }

    autoContinueRef.current = false;
  }, [
    activeAudioIndex,
    content?.summary.number,
    playableAyahs,
    player,
    playerStatus.didJustFinish,
    preferences.quranPlaybackRate,
    preferences.quranRepeatMode,
    selected?.number,
  ]);

  useEffect(() => {
    if (activeAyah) scrollToAyah(activeAyah);
  }, [activeAyah]);

  const fetchList = async () => {
    setListLoading(true);
    setError(null);
    try {
      const result = await loadSurahList();
      if (!mountedRef.current) return;
      setList(result.data);
      setSource(result.source);
    } catch (err) {
      if (mountedRef.current) setError(err instanceof Error ? err.message : 'Sure listesi alınamadı.');
    } finally {
      if (mountedRef.current) setListLoading(false);
    }
  };

  useEffect(() => {
    void fetchList();
    void loadQuranProgress().then((value) => mountedRef.current && setProgress(value));
    void loadBookmarks().then((value) => mountedRef.current && setBookmarks(value));
  }, []);

  const stopAudio = () => {
    try {
      player.pause();
    } catch {
      // Ses modülü hatası ekranı kapatmamalı.
    }
    autoContinueRef.current = false;
    lastDidFinishRef.current = false;
    setActiveAudioIndex(null);
  };

  const openSurah = async (summary: SurahSummary, targetAyah?: number) => {
    const safeSummary = normalizeSurahSummary(summary);
    if (!safeSummary) {
      setError('Sure bilgisi geçersiz. Listeyi yeniden yükleyin.');
      return;
    }
    stopAudio();
    pendingAyahRef.current = targetAyah ?? null;
    setSelected(safeSummary);
    setContent(null);
    setReaderLoading(true);
    setError(null);
    setAudioError(null);
    try {
      const result = await loadSurah(safeSummary.number, preferences.quranReciter);
      if (!mountedRef.current) return;
      setContent(result.data);
      setSource(result.source);
      const initialAyah = targetAyah ?? 1;
      persistProgress(safeSummary.number, initialAyah);
      setDownloaded(isSurahDownloaded(preferences.quranReciter, safeSummary.number, result.data.ayahs));
      if (pendingAyahRef.current) {
        const target = pendingAyahRef.current;
        pendingAyahRef.current = null;
        setTimeout(() => scrollToAyah(target, false), 180);
      }
    } catch (err) {
      if (mountedRef.current) setError(err instanceof Error ? err.message : 'Sure açılamadı.');
    } finally {
      if (mountedRef.current) setReaderLoading(false);
    }
  };

  const reloadForReciter = async (reciter: string) => {
    updatePreferences({ quranReciter: reciter });
    if (!selected) return;
    stopAudio();
    setReaderLoading(true);
    setError(null);
    try {
      const result = await loadSurah(selected.number, reciter);
      if (!mountedRef.current) return;
      setContent(result.data);
      setSource(result.source);
      setDownloaded(isSurahDownloaded(reciter, selected.number, result.data.ayahs));
    } catch (err) {
      if (mountedRef.current) setError(err instanceof Error ? err.message : 'Hafız değiştirilemedi.');
    } finally {
      if (mountedRef.current) setReaderLoading(false);
    }
  };

  const startAudioAt = (index: number) => {
    const item = playableAyahs[index];
    if (!item) return;
    const sourceUri = resolveAudio(item);
    if (!sourceUri) return;
    lastDidFinishRef.current = playerStatus.didJustFinish;
    autoContinueRef.current = true;
    setActiveAudioIndex(index);
    if (selected) persistProgress(selected.number, item.numberInSurah);
    player.replace(sourceUri);
    player.setPlaybackRate(preferences.quranPlaybackRate);
    player.play();
    setAudioError(null);
  };

  const toggleAyahAudio = (item: AyahPair) => {
    try {
      if (!item.audio && !resolveAudio(item)) return;
      const audioIndex = playableAyahs.findIndex((ayah) => ayah.numberInSurah === item.numberInSurah);
      if (audioIndex < 0) return;
      if (activeAudioIndex === audioIndex) {
        if (playerStatus.playing) player.pause();
        else {
          autoContinueRef.current = true;
          player.play();
        }
        return;
      }
      startAudioAt(audioIndex);
    } catch (err) {
      setAudioError(err instanceof Error ? err.message : 'Ses başlatılamadı.');
    }
  };

  const toggleWholeSurah = () => {
    try {
      if (!playableAyahs.length) return;
      if (playerStatus.playing) {
        player.pause();
        return;
      }
      const atEnd = activeAudioIndex === playableAyahs.length - 1
        && playerStatus.duration > 0
        && playerStatus.currentTime >= playerStatus.duration - 0.5;
      if (activeAudioIndex === null || playerStatus.didJustFinish || atEnd) startAudioAt(0);
      else {
        autoContinueRef.current = true;
        player.play();
      }
    } catch (err) {
      setAudioError(err instanceof Error ? err.message : 'Ses başlatılamadı.');
    }
  };

  const scheduleSleepTimer = (minutes: number) => {
    if (sleepTimerRef.current) clearTimeout(sleepTimerRef.current);
    setSleepMinutes(minutes);
    if (!minutes) {
      setSleepStatus(null);
      return;
    }
    setSleepStatus(`${minutes} dakika sonra duracak`);
    sleepTimerRef.current = setTimeout(() => {
      try { player.pause(); } catch { /* noop */ }
      autoContinueRef.current = false;
      setSleepMinutes(0);
      setSleepStatus('Uyku zamanlayıcısı sesi durdurdu.');
    }, minutes * 60_000);
  };

  const handleBookmark = async (item: AyahPair) => {
    if (!selected) return;
    const result = await toggleBookmark({
      id: bookmarkId(selected.number, item.numberInSurah),
      surah: selected.number,
      surahName: selected.turkishName,
      ayah: item.numberInSurah,
      arabic: item.arabic,
      translation: item.translation,
      addedAt: new Date().toISOString(),
    });
    if (mountedRef.current) setBookmarks(result.items);
  };

  const handleShare = async (item: AyahPair) => {
    if (!selected) return;
    await Share.share({
      message: `${selected.turkishName} ${item.numberInSurah}. ayet\n\n${item.arabic}\n\n${item.translation}\n\nDuaVakti`,
    });
  };

  const toggleDownload = async () => {
    if (!selected || !content) return;
    if (downloaded) {
      removeSurahAudio(preferences.quranReciter, selected.number);
      setDownloaded(false);
      setDownloadProgress('Çevrimdışı sesler silindi.');
      return;
    }
    try {
      setDownloadProgress('İndirme hazırlanıyor…');
      await downloadSurahAudio(
        preferences.quranReciter,
        selected.number,
        content.ayahs,
        (done, total) => mountedRef.current && setDownloadProgress(`${done}/${total} ayet indirildi`),
      );
      if (mountedRef.current) {
        setDownloaded(true);
        setDownloadProgress('Sure artık internetsiz dinlenebilir.');
      }
    } catch (err) {
      if (mountedRef.current) setDownloadProgress(err instanceof Error ? err.message : 'İndirme tamamlanamadı.');
    }
  };

  const filtered = useMemo(() => list.filter((item) => matchesSurah(item, query)), [list, query]);
  const bookmarkIds = useMemo(() => new Set(bookmarks.map((item) => item.id)), [bookmarks]);

  if (selected) {
    const finished = playerStatus.didJustFinish
      || (playableAyahs.length > 0
        && (activeAudioIndex ?? 0) === playableAyahs.length - 1
        && playerStatus.duration > 0
        && playerStatus.currentTime >= playerStatus.duration - 0.5);
    const wholeButtonLabel = playerStatus.playing
      ? 'Duraklat'
      : finished
        ? 'Baştan dinle'
        : (activeAudioIndex ?? 0) > 0 || playerStatus.currentTime > 0
          ? 'Devam et'
          : 'Tümünü dinle';

    return (
      <View style={styles.root}>
        <View style={styles.readerHeader}>
          <Pressable style={styles.backButton} onPress={() => { stopAudio(); setSelected(null); setContent(null); setError(null); }}>
            <Text style={styles.backText}>‹</Text>
          </Pressable>
          <View style={styles.readerTitleWrap}>
            <Text style={styles.readerTitle}>{selected.number}. {selected.turkishName}</Text>
            <Text style={styles.readerSubtitle}>{getTurkishRevelationType(selected.revelationType)} · {selected.numberOfAyahs} ayet</Text>
          </View>
          <View style={styles.fontControls}>
            <Pressable onPress={() => updatePreferences({ quranFontScale: Math.max(0.8, preferences.quranFontScale - 0.1) })} style={styles.fontButton}><Text style={styles.fontButtonText}>A−</Text></Pressable>
            <Pressable onPress={() => updatePreferences({ quranFontScale: Math.min(1.6, preferences.quranFontScale + 0.1) })} style={styles.fontButton}><Text style={styles.fontButtonText}>A+</Text></Pressable>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.readerTools}>
          {RECITERS.map((item) => (
            <Pressable key={item.id} style={[styles.toolChip, preferences.quranReciter === item.id && styles.toolChipActive]} onPress={() => void reloadForReciter(item.id)}>
              <Text style={styles.toolChipText}>{item.shortName}</Text>
            </Pressable>
          ))}
          {SPEEDS.map((speed) => (
            <Pressable key={speed} style={[styles.toolChip, preferences.quranPlaybackRate === speed && styles.toolChipActive]} onPress={() => updatePreferences({ quranPlaybackRate: speed })}>
              <Text style={styles.toolChipText}>{speed}×</Text>
            </Pressable>
          ))}
          {(['off', 'ayah', 'surah'] as QuranRepeatMode[]).map((mode) => (
            <Pressable key={mode} style={[styles.toolChip, preferences.quranRepeatMode === mode && styles.toolChipActive]} onPress={() => updatePreferences({ quranRepeatMode: mode })}>
              <Text style={styles.toolChipText}>{repeatLabel(mode)}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {content && playableAyahs.length ? (
          <View style={styles.surahAudioBar}>
            <View style={styles.surahAudioTextWrap}>
              <Text style={styles.surahAudioEyebrow}>KESİNTİSİZ DİNLEME · {getReciter(preferences.quranReciter).shortName}</Text>
              <Text style={styles.surahAudioText}>{activeAyah ? `${activeAyah}. ayet · ${(activeAudioIndex ?? 0) + 1}/${playableAyahs.length}` : `${playableAyahs.length} ayet hazır`}</Text>
            </View>
            <Pressable style={[styles.wholeAudioButton, playerStatus.playing && styles.audioButtonActive]} onPress={toggleWholeSurah}>
              <Text style={styles.wholeAudioButtonText}>{wholeButtonLabel}</Text>
              <Text style={styles.audioIcon}>{playerStatus.playing ? '❚❚' : '▶'}</Text>
            </Pressable>
          </View>
        ) : null}

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.secondaryTools}>
          <Pressable style={[styles.secondaryButton, downloaded && styles.secondaryButtonActive]} onPress={() => void toggleDownload()}>
            <Text style={styles.secondaryButtonText}>{downloaded ? 'İndirmeyi sil' : 'Çevrimdışı indir'}</Text>
          </Pressable>
          {SLEEP_OPTIONS.map((minutes) => (
            <Pressable key={minutes} style={[styles.secondaryButton, sleepMinutes === minutes && styles.secondaryButtonActive]} onPress={() => scheduleSleepTimer(minutes)}>
              <Text style={styles.secondaryButtonText}>{minutes ? `${minutes} dk uyku` : 'Uyku kapalı'}</Text>
            </Pressable>
          ))}
        </ScrollView>
        {downloadProgress || sleepStatus ? <Text style={styles.statusNote}>{downloadProgress ?? sleepStatus}</Text> : null}
        {audioError ? <View style={styles.audioErrorBox}><Text style={styles.audioErrorText}>Ses özelliği geçici olarak kullanılamıyor. Metin okumaya devam edebilirsin.</Text></View> : null}
        {readerLoading ? <LoadingState label="Sure yükleniyor…" /> : null}
        {error && !content ? <View style={styles.pad}><ErrorState title="Sure açılamadı" detail={error} onRetry={() => void openSurah(selected, progress?.surah === selected.number ? progress.ayah : 1)} /></View> : null}
        {content ? (
          <FlatList
            ref={ayahListRef}
            data={content.ayahs}
            keyExtractor={(item) => String(item.numberInSurah)}
            contentContainerStyle={styles.ayahList}
            initialNumToRender={8}
            windowSize={7}
            viewabilityConfig={{ itemVisiblePercentThreshold: 55 }}
            onViewableItemsChanged={({ viewableItems }) => {
              const ayah = viewableItems.find((item) => item.isViewable)?.item?.numberInSurah;
              if (ayah && selected) persistProgress(selected.number, ayah);
            }}
            onScrollToIndexFailed={({ index }) => setTimeout(() => ayahListRef.current?.scrollToOffset({ offset: Math.max(index * 280, 0), animated: true }), 120)}
            renderItem={({ item }) => {
              const audioIndex = playableAyahs.findIndex((ayah) => ayah.numberInSurah === item.numberInSurah);
              const isActive = audioIndex >= 0 && activeAudioIndex === audioIndex;
              const isPlaying = isActive && playerStatus.playing;
              const isBookmarked = bookmarkIds.has(bookmarkId(selected.number, item.numberInSurah));
              return (
                <View style={[styles.ayahCard, isActive && styles.ayahCardActive]}>
                  <View style={styles.ayahTopRow}>
                    <View style={styles.ayahNumber}><Text style={styles.ayahNumberText}>{item.numberInSurah}</Text></View>
                    <View style={styles.ayahActions}>
                      <Pressable onPress={() => void handleBookmark(item)} style={[styles.iconButton, isBookmarked && styles.iconButtonActive]}><Text style={styles.iconButtonText}>{isBookmarked ? '★' : '☆'}</Text></Pressable>
                      <Pressable onPress={() => void handleShare(item)} style={styles.iconButton}><Text style={styles.iconButtonText}>↗</Text></Pressable>
                      <Pressable disabled={!resolveAudio(item)} onPress={() => toggleAyahAudio(item)} style={[styles.audioButton, !resolveAudio(item) && styles.audioButtonDisabled, isActive && styles.audioButtonActive]}>
                        <Text style={styles.audioButtonText}>{playerStatus.isBuffering && isActive ? '…' : isPlaying ? 'Duraklat' : isActive ? 'Devam et' : 'Buradan dinle'}</Text>
                        <Text style={styles.audioIcon}>{isPlaying ? '❚❚' : '▶'}</Text>
                      </Pressable>
                    </View>
                  </View>
                  {preferences.arabicVisible ? <Text style={[styles.arabic, { fontSize: 29 * preferences.quranFontScale, lineHeight: 54 * preferences.quranFontScale }]}>{item.arabic}</Text> : null}
                  <View style={styles.ayahDivider} />
                  <Text style={[styles.translation, { fontSize: 16 * preferences.quranFontScale, lineHeight: 27 * preferences.quranFontScale }]}>{item.translation || 'Türkçe anlam yüklenemedi.'}</Text>
                </View>
              );
            }}
            ListHeaderComponent={source === 'cache' ? <Text style={styles.cacheNote}>Bu sure çevrimdışı önbellekten açıldı. İndirilen sesler internet olmadan çalışır.</Text> : null}
            ListFooterComponent={<View style={{ height: 120 }} />}
          />
        ) : null}
      </View>
    );
  }

  const progressSummary = progress ? list.find((item) => item.number === progress.surah) : null;

  return (
    <View style={styles.root}>
      <ScrollView contentContainerStyle={styles.headerContent} keyboardShouldPersistTaps="handled">
        <Text style={styles.eyebrow}>KUR’AN-I KERİM</Text>
        <Text style={styles.title}>Oku, dinle, kaydet ve kaldığın yerden devam et.</Text>
        {progress && progressSummary ? (
          <Pressable style={styles.continueCard} onPress={() => void openSurah(progressSummary, progress.ayah)}>
            <View>
              <Text style={styles.continueEyebrow}>KALDIĞIN YER</Text>
              <Text style={styles.continueTitle}>{progressSummary.turkishName} · {progress.ayah}. ayet</Text>
            </View>
            <Text style={styles.arrow}>→</Text>
          </Pressable>
        ) : null}
        <View style={styles.listModeRow}>
          <Pressable style={[styles.modeButton, !showBookmarks && styles.modeButtonActive]} onPress={() => setShowBookmarks(false)}><Text style={styles.modeButtonText}>114 Sure</Text></Pressable>
          <Pressable style={[styles.modeButton, showBookmarks && styles.modeButtonActive]} onPress={() => setShowBookmarks(true)}><Text style={styles.modeButtonText}>★ Favoriler ({bookmarks.length})</Text></Pressable>
        </View>
        {!showBookmarks ? <TextInput value={query} onChangeText={setQuery} placeholder="Sure ara…" placeholderTextColor={colors.textDim} style={styles.search} autoCorrect={false} /> : null}
      </ScrollView>

      {listLoading ? <LoadingState label="Sure listesi yükleniyor…" /> : null}
      {error && !list.length ? <View style={styles.pad}><ErrorState title="Kur’an bölümü yüklenemedi" detail={error} onRetry={() => void fetchList()} /></View> : null}
      {showBookmarks ? (
        <FlatList
          data={bookmarks}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          ListEmptyComponent={<Text style={styles.empty}>Henüz favori ayet eklemedin.</Text>}
          renderItem={({ item }) => (
            <Pressable style={styles.bookmarkRow} onPress={() => {
              const target = list.find((surah) => surah.number === item.surah);
              if (target) void openSurah(target, item.ayah);
            }}>
              <Text style={styles.bookmarkMeta}>{item.surahName} · {item.ayah}. ayet</Text>
              <Text numberOfLines={2} style={styles.bookmarkTranslation}>{item.translation}</Text>
            </Pressable>
          )}
          ListFooterComponent={<View style={{ height: 120 }} />}
        />
      ) : list.length ? (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.number)}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Pressable style={styles.surahRow} onPress={() => void openSurah(item, progress?.surah === item.number ? progress.ayah : 1)}>
              <View style={styles.numberBadge}><Text style={styles.numberText}>{item.number}</Text></View>
              <View style={styles.surahInfo}>
                <Text style={styles.surahName}>{item.turkishName || `${item.number}. Sure`}</Text>
                <Text style={styles.surahMeta}>{getTurkishRevelationType(item.revelationType)} · {item.numberOfAyahs} ayet</Text>
              </View>
              <Text style={styles.surahArabic}>{item.name}</Text>
            </Pressable>
          )}
          ListHeaderComponent={source === 'cache' ? <Text style={styles.cacheNote}>Sure listesi çevrimdışı önbellekten gösteriliyor.</Text> : null}
          ListEmptyComponent={<Text style={styles.empty}>Aramana uygun sure bulunamadı.</Text>}
          ListFooterComponent={<View style={{ height: 120 }} />}
        />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  headerContent: { paddingHorizontal: 28, paddingTop: 24, paddingBottom: 10 },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '900', letterSpacing: 2.2, marginBottom: 12 },
  title: { color: colors.text, fontSize: 34, lineHeight: 42, fontWeight: '900', letterSpacing: -0.7 },
  continueCard: { marginTop: 22, backgroundColor: colors.greenCard, borderColor: colors.borderStrong, borderWidth: 1, borderRadius: radii.lg, padding: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  continueEyebrow: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.8 },
  continueTitle: { color: colors.text, fontSize: 19, fontWeight: '800', marginTop: 5 },
  arrow: { color: colors.text, fontSize: 28 },
  listModeRow: { flexDirection: 'row', gap: 8, marginTop: 18 },
  modeButton: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 14, paddingVertical: 11, alignItems: 'center' },
  modeButtonActive: { backgroundColor: colors.accentSoft, borderColor: colors.borderStrong },
  modeButtonText: { color: colors.text, fontWeight: '800', fontSize: 12 },
  search: { marginTop: 12, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radii.md, color: colors.text, paddingHorizontal: 16, paddingVertical: 14, fontSize: 16 },
  list: { paddingHorizontal: 20, paddingTop: 8 },
  surahRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radii.md, padding: 14, marginBottom: 10 },
  numberBadge: { width: 42, height: 42, borderRadius: 15, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center' },
  numberText: { color: colors.accent, fontWeight: '900' },
  surahInfo: { flex: 1, marginLeft: 14 },
  surahName: { color: colors.text, fontSize: 17, fontWeight: '800' },
  surahMeta: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  surahArabic: { color: colors.text, fontSize: 21, maxWidth: '35%', textAlign: 'right', writingDirection: 'rtl' },
  bookmarkRow: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: radii.md, padding: 16, marginBottom: 10 },
  bookmarkMeta: { color: colors.accent, fontSize: 11, fontWeight: '900' },
  bookmarkTranslation: { color: colors.text, fontSize: 15, lineHeight: 22, marginTop: 8 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
  pad: { paddingHorizontal: 24 },
  cacheNote: { color: colors.warning, marginBottom: 10, fontSize: 12 },
  readerHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 18, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: colors.border },
  backButton: { width: 44, height: 44, borderRadius: 16, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center' },
  backText: { color: colors.text, fontSize: 38, lineHeight: 40, marginTop: -4 },
  readerTitleWrap: { flex: 1, marginLeft: 12 },
  readerTitle: { color: colors.text, fontSize: 18, fontWeight: '900' },
  readerSubtitle: { color: colors.textMuted, fontSize: 11, marginTop: 3 },
  fontControls: { flexDirection: 'row', gap: 6 },
  fontButton: { backgroundColor: colors.surface, borderRadius: 11, paddingHorizontal: 9, paddingVertical: 8 },
  fontButtonText: { color: colors.text, fontWeight: '800', fontSize: 12 },
  readerTools: { paddingHorizontal: 14, paddingVertical: 10, gap: 7 },
  toolChip: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 99, paddingHorizontal: 12, paddingVertical: 8 },
  toolChipActive: { backgroundColor: colors.accentSoft, borderColor: colors.accent },
  toolChipText: { color: colors.text, fontWeight: '800', fontSize: 11 },
  surahAudioBar: { marginHorizontal: 16, marginBottom: 4, padding: 12, borderRadius: radii.md, backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.borderStrong, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  surahAudioTextWrap: { flex: 1 },
  surahAudioEyebrow: { color: colors.accent, fontSize: 9, fontWeight: '900', letterSpacing: 1.2 },
  surahAudioText: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  wholeAudioButton: { minWidth: 112, height: 42, paddingHorizontal: 12, borderRadius: 13, backgroundColor: colors.greenCard, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  wholeAudioButtonText: { color: colors.text, fontSize: 12, fontWeight: '900' },
  secondaryTools: { paddingHorizontal: 16, paddingVertical: 8, gap: 7 },
  secondaryButton: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 13, paddingHorizontal: 12, paddingVertical: 9 },
  secondaryButtonActive: { backgroundColor: colors.accentSoft, borderColor: colors.accent },
  secondaryButtonText: { color: colors.text, fontWeight: '800', fontSize: 11 },
  statusNote: { color: colors.textMuted, fontSize: 11, marginHorizontal: 18, marginBottom: 6 },
  ayahList: { padding: 16 },
  ayahCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 20, marginBottom: 14 },
  ayahCardActive: { borderColor: colors.accent },
  ayahTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  ayahNumber: { width: 34, height: 34, borderRadius: 12, backgroundColor: colors.accentSoft, alignItems: 'center', justifyContent: 'center' },
  ayahNumberText: { color: colors.accent, fontWeight: '900' },
  ayahActions: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  iconButton: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.surfaceSoft, alignItems: 'center', justifyContent: 'center' },
  iconButtonActive: { backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.accent },
  iconButtonText: { color: colors.text, fontSize: 17, fontWeight: '900' },
  audioButton: { minWidth: 96, height: 38, paddingHorizontal: 10, borderRadius: 12, backgroundColor: colors.accentSoft, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },
  audioButtonActive: { borderWidth: 1, borderColor: colors.accent },
  audioButtonDisabled: { opacity: 0.35 },
  audioButtonText: { color: colors.text, fontSize: 11, fontWeight: '800' },
  audioIcon: { color: colors.accent, fontSize: 12, fontWeight: '900' },
  arabic: { color: colors.text, textAlign: 'right', writingDirection: 'rtl' },
  ayahDivider: { height: 1, backgroundColor: colors.border, marginVertical: 18 },
  translation: { color: colors.text, opacity: 0.92 },
  audioErrorBox: { marginHorizontal: 16, marginTop: 10, padding: 12, borderRadius: radii.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  audioErrorText: { color: colors.warning, fontSize: 12, lineHeight: 18 },
});
