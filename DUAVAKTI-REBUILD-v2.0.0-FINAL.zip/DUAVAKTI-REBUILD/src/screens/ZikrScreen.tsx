import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, Vibration, View } from 'react-native';
import type { ZikrState } from '../types';
import { calculateStreak, defaultZikrState, markZikrProgress, ZIKR_PRESETS } from '../lib/zikr';
import { readJson, writeJson } from '../lib/storage';
import { colors, radii } from '../theme';

const ZIKR_KEY = 'duavakti:zikr:state:v1';

export function ZikrScreen() {
  const [state, setState] = useState<ZikrState>(defaultZikrState());
  const [customTitle, setCustomTitle] = useState('');

  useEffect(() => {
    void readJson<ZikrState>(ZIKR_KEY).then((stored) => {
      if (stored?.selectedId) setState({ ...defaultZikrState(), ...stored });
    });
  }, []);

  const preset = useMemo(
    () => ZIKR_PRESETS.find((item) => item.id === state.selectedId),
    [state.selectedId],
  );
  const title = state.selectedId === 'custom' ? (state.customTitle || 'Özel zikir') : (preset?.title ?? 'Zikir');
  const arabic = state.selectedId === 'custom' ? 'ذِكْر' : (preset?.arabic ?? 'ذِكْر');
  const streak = calculateStreak(state.completedDates);
  const progress = Math.min(100, Math.round((state.count / Math.max(1, state.target)) * 100));

  const persist = (next: ZikrState) => {
    setState(next);
    void writeJson(ZIKR_KEY, next);
  };

  const selectPreset = (id: string, target: number, nextTitle?: string) => {
    persist({
      ...state,
      selectedId: id,
      count: 0,
      target,
      customTitle: nextTitle,
      updatedAt: new Date().toISOString(),
    });
  };

  const increment = () => {
    Vibration.vibrate(18);
    persist(markZikrProgress(state, state.count + 1));
  };

  const createCustom = () => {
    const clean = customTitle.trim();
    if (!clean) return;
    selectPreset('custom', 100, clean);
    setCustomTitle('');
  };

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <Text style={styles.eyebrow}>ZİKİR & TESBİH</Text>
      <Text style={styles.title}>Say, hisset, kaldığın yerden devam et.</Text>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.presets}>
        {ZIKR_PRESETS.map((item) => (
          <Pressable key={item.id} style={[styles.preset, state.selectedId === item.id && styles.presetActive]} onPress={() => selectPreset(item.id, item.target)}>
            <Text style={styles.presetTitle}>{item.title}</Text>
            <Text style={styles.presetTarget}>Hedef {item.target}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <View style={styles.counterCard}>
        <Text style={styles.arabic}>{arabic}</Text>
        <Text style={styles.counterTitle}>{title}</Text>
        <Text style={styles.count}>{state.count}</Text>
        <Text style={styles.target}>Hedef {state.target} · %{progress}</Text>
        <View style={styles.progressTrack}><View style={[styles.progressFill, { width: `${progress}%` }]} /></View>
        <Pressable style={styles.countButton} onPress={increment} accessibilityLabel="Zikir sayacını artır">
          <Text style={styles.countButtonText}>+1</Text>
          <Text style={styles.countButtonHint}>Dokun ve say</Text>
        </Pressable>
        <View style={styles.counterActions}>
          <Pressable style={styles.smallButton} onPress={() => persist({ ...state, count: 0, updatedAt: new Date().toISOString() })}><Text style={styles.smallButtonText}>Sıfırla</Text></Pressable>
          <Pressable style={styles.smallButton} onPress={() => persist({ ...state, target: state.target === 33 ? 100 : state.target === 100 ? 500 : 33 })}><Text style={styles.smallButtonText}>Hedef: {state.target}</Text></Pressable>
        </View>
      </View>

      <View style={styles.statRow}>
        <View style={styles.statCard}><Text style={styles.statValue}>{streak}</Text><Text style={styles.statLabel}>gün seri</Text></View>
        <View style={styles.statCard}><Text style={styles.statValue}>{state.completedDates.length}</Text><Text style={styles.statLabel}>tamamlanan gün</Text></View>
      </View>

      <View style={styles.customCard}>
        <Text style={styles.cardTitle}>Özel zikir oluştur</Text>
        <Text style={styles.help}>Kendi zikrini yaz; sayaç son sayıyı otomatik kaydeder.</Text>
        <View style={styles.inputRow}>
          <TextInput value={customTitle} onChangeText={setCustomTitle} placeholder="Örn. Salavat" placeholderTextColor={colors.textDim} style={styles.input} />
          <Pressable style={styles.addButton} onPress={createCustom}><Text style={styles.addText}>Ekle</Text></Pressable>
        </View>
      </View>
      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24 },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '900', letterSpacing: 2.2, marginBottom: 12 },
  title: { color: colors.text, fontSize: 32, lineHeight: 40, fontWeight: '900' },
  presets: { gap: 8, paddingVertical: 20 },
  preset: { minWidth: 132, padding: 14, borderRadius: radii.md, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  presetActive: { backgroundColor: colors.accentSoft, borderColor: colors.accent },
  presetTitle: { color: colors.text, fontWeight: '800', fontSize: 13 },
  presetTarget: { color: colors.textMuted, fontSize: 11, marginTop: 4 },
  counterCard: { backgroundColor: colors.greenDeep, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.xl, padding: 24, alignItems: 'center' },
  arabic: { color: colors.text, fontSize: 34, writingDirection: 'rtl' },
  counterTitle: { color: colors.accent, fontSize: 15, fontWeight: '900', marginTop: 12 },
  count: { color: colors.text, fontSize: 78, lineHeight: 92, fontWeight: '900', marginTop: 8 },
  target: { color: colors.textMuted, fontSize: 13 },
  progressTrack: { height: 8, width: '100%', backgroundColor: colors.surface, borderRadius: 99, overflow: 'hidden', marginTop: 16 },
  progressFill: { height: 8, backgroundColor: colors.accent, borderRadius: 99 },
  countButton: { width: 190, height: 190, borderRadius: 95, backgroundColor: colors.accentSoft, borderWidth: 2, borderColor: colors.accent, alignItems: 'center', justifyContent: 'center', marginTop: 24 },
  countButtonText: { color: colors.text, fontSize: 48, fontWeight: '900' },
  countButtonHint: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  counterActions: { flexDirection: 'row', gap: 8, marginTop: 18 },
  smallButton: { backgroundColor: colors.surface, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10 },
  smallButtonText: { color: colors.text, fontSize: 12, fontWeight: '800' },
  statRow: { flexDirection: 'row', gap: 10, marginTop: 14 },
  statCard: { flex: 1, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 18, alignItems: 'center' },
  statValue: { color: colors.text, fontSize: 28, fontWeight: '900' },
  statLabel: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  customCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 18, marginTop: 14 },
  cardTitle: { color: colors.text, fontSize: 17, fontWeight: '900' },
  help: { color: colors.textMuted, fontSize: 13, lineHeight: 19, marginTop: 7 },
  inputRow: { flexDirection: 'row', marginTop: 14 },
  input: { flex: 1, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, borderRadius: 14, color: colors.text, paddingHorizontal: 14, paddingVertical: 12 },
  addButton: { marginLeft: 8, backgroundColor: colors.accentSoft, borderRadius: 14, paddingHorizontal: 16, justifyContent: 'center' },
  addText: { color: colors.text, fontWeight: '900' },
});
