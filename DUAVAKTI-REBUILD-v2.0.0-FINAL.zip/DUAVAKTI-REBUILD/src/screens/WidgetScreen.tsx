import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import type { AppPreferences, NextPrayerResult, PrayerApiResult, WidgetMode, WidgetTheme } from '../types';
import { DUAS } from '../data/duas';
import { dayIndex } from '../lib/time';
import { prayerRows, timeOnDate } from '../lib/prayer';
import { updateNativeWidgets } from '../native/widget';
import { formatHijriLabel, isRamadanMonth } from '../lib/hijri';
import { colors, radii } from '../theme';

const THEMES: Array<{ key: WidgetTheme; label: string }> = [
  { key: 'dark', label: 'Koyu' },
  { key: 'light', label: 'Açık' },
  { key: 'transparent', label: 'Şeffaf' },
];

const MODES: Array<{ key: WidgetMode; label: string }> = [
  { key: 'balanced', label: 'Dengeli' },
  { key: 'next', label: 'Sıradaki vakit' },
  { key: 'dua', label: 'Dua' },
  { key: 'ramadan', label: 'Ramazan' },
];

export function WidgetScreen({
  data,
  next,
  countdown,
  preferences,
  updatePreferences,
}: {
  data: PrayerApiResult | null;
  next: NextPrayerResult | null;
  countdown: string;
  preferences: AppPreferences;
  updatePreferences: (patch: Partial<AppPreferences>) => void;
}) {
  const [status, setStatus] = useState<string | null>(null);
  const rows = useMemo(() => data ? prayerRows(data.timings) : [], [data]);
  const hourlyDua = useMemo(() => DUAS[dayIndex(new Date(), DUAS.length)], [new Date().getHours()]);
  const widget = preferences.widgetSettings;

  const patchWidget = (patch: Partial<AppPreferences['widgetSettings']>) => {
    updatePreferences({ widgetSettings: { ...widget, ...patch } });
  };

  const sync = async () => {
    if (!data || !next) {
      setStatus('Önce namaz vakitlerinin yüklenmesi gerekiyor.');
      return;
    }
    const iftarTarget = timeOnDate(new Date(), data.timings.Maghrib);
    try {
      const updated = await updateNativeWidgets({
        location: data.locationLabel,
        hijriDate: formatHijriLabel(data.hijriDay, data.hijriMonth, data.hijriYear),
        nextPrayer: next.label,
        nextTime: next.time,
        remaining: countdown,
        targetEpoch: next.target.getTime(),
        iftarTime: data.timings.Maghrib,
        iftarEpoch: iftarTarget?.getTime() ?? 0,
        isRamadan: isRamadanMonth(data.hijriMonth),
        prayers: rows.map((row) => ({ label: row.label, time: row.time })),
        duas: DUAS.map(({ title, meaning, source }) => ({ title, meaning, source })),
        settings: widget,
      });
      setStatus(updated ? 'Widget ayarları ve içerikler şimdi yenilendi.' : 'Bu ortamda native widget modülü yok. APK kurulduğunda çalışır.');
    } catch {
      setStatus('Widgetlar güncellenemedi. Uygulamayı yeniden açıp tekrar dene.');
    }
  };

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.content}>
      <Text style={styles.eyebrow}>WIDGET STÜDYOSU</Text>
      <Text style={styles.title}>Ana ekranını kendine göre düzenle.</Text>
      <Text style={styles.intro}>Tema, içerik modu, dua, Hicri tarih ve geri sayım seçeneklerini değiştir. Widgeta dokununca ilgili bölüm açılır.</Text>

      <Text style={styles.section}>TEMA</Text>
      <View style={styles.chipRow}>
        {THEMES.map((item) => (
          <Pressable key={item.key} style={[styles.chip, widget.theme === item.key && styles.chipActive]} onPress={() => patchWidget({ theme: item.key })}>
            <Text style={styles.chipText}>{item.label}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.section}>İÇERİK MODU</Text>
      <View style={styles.chipWrap}>
        {MODES.map((item) => (
          <Pressable key={item.key} style={[styles.chip, widget.mode === item.key && styles.chipActive]} onPress={() => patchWidget({ mode: item.key })}>
            <Text style={styles.chipText}>{item.label}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.optionCard}>
        <View style={styles.optionRow}><View style={styles.optionText}><Text style={styles.optionTitle}>Saatin duası</Text><Text style={styles.optionHelp}>Vakit widgetlarında dua metnini gösterir.</Text></View><Switch value={widget.showDua} onValueChange={(value) => patchWidget({ showDua: value })} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} /></View>
        <View style={styles.divider} />
        <View style={styles.optionRow}><View style={styles.optionText}><Text style={styles.optionTitle}>Hicri tarih</Text><Text style={styles.optionHelp}>Konum başlığının yanında Hicri tarihi gösterir.</Text></View><Switch value={widget.showHijri} onValueChange={(value) => patchWidget({ showHijri: value })} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} /></View>
        <View style={styles.divider} />
        <View style={styles.optionRow}><View style={styles.optionText}><Text style={styles.optionTitle}>Geri sayım</Text><Text style={styles.optionHelp}>Orta widgetta sıradaki vakte kalan süreyi gösterir.</Text></View><Switch value={widget.showCountdown} onValueChange={(value) => patchWidget({ showCountdown: value })} trackColor={{ true: colors.accentSoft }} thumbColor={colors.text} /></View>
      </View>

      <Text style={styles.section}>CANLI ÖNİZLEME</Text>
      <View style={[styles.preview, widget.theme === 'light' && styles.previewLight, widget.theme === 'transparent' && styles.previewTransparent]}>
        <Text style={[styles.previewEyebrow, widget.theme === 'light' && styles.lightAccent]}>{data?.locationLabel ?? 'DuaVakti'}{widget.showHijri && data ? ` · ${formatHijriLabel(data.hijriDay, data.hijriMonth, data.hijriYear)}` : ''}</Text>
        <View style={styles.previewTop}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.previewTitle, widget.theme === 'light' && styles.lightText]}>{widget.mode === 'dua' ? hourlyDua.title : widget.mode === 'ramadan' && isRamadanMonth(data?.hijriMonth) ? 'İftara kalan' : next?.label ?? 'Sıradaki vakit'}</Text>
            <Text style={[styles.previewTime, widget.theme === 'light' && styles.lightMuted]}>{widget.mode === 'dua' ? hourlyDua.meaning : widget.mode === 'ramadan' && isRamadanMonth(data?.hijriMonth) ? data?.timings.Maghrib ?? '--:--' : next?.time ?? '--:--'}</Text>
          </View>
          {widget.showCountdown ? <Text style={[styles.countdown, widget.theme === 'light' && styles.lightText]}>{countdown}</Text> : null}
        </View>
        {widget.showDua && widget.mode !== 'next' ? <><Text style={[styles.duaMiniTitle, widget.theme === 'light' && styles.lightAccent]}>SAATİN DUASI · {hourlyDua.title}</Text><Text numberOfLines={2} style={[styles.duaMiniMeaning, widget.theme === 'light' && styles.lightText]}>{hourlyDua.meaning}</Text></> : null}
      </View>

      <Pressable style={styles.syncButton} onPress={() => void sync()}><Text style={styles.syncText}>Ayarları widgetlara uygula</Text></Pressable>
      {status ? <Text style={styles.status}>{status}</Text> : null}
      <View style={{ height: 120 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24 },
  eyebrow: { color: colors.accent, fontSize: 12, fontWeight: '900', letterSpacing: 2.2, marginBottom: 12 },
  title: { color: colors.text, fontSize: 32, lineHeight: 40, fontWeight: '900' },
  intro: { color: colors.textMuted, fontSize: 14, lineHeight: 22, marginTop: 12 },
  section: { color: colors.textMuted, fontSize: 11, fontWeight: '900', letterSpacing: 1.8, marginTop: 24, marginBottom: 10 },
  chipRow: { flexDirection: 'row', gap: 8 },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 99, paddingHorizontal: 14, paddingVertical: 10 },
  chipActive: { backgroundColor: colors.accentSoft, borderColor: colors.accent },
  chipText: { color: colors.text, fontWeight: '800', fontSize: 12 },
  optionCard: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: radii.lg, padding: 18, marginTop: 18 },
  optionRow: { flexDirection: 'row', alignItems: 'center' },
  optionText: { flex: 1, paddingRight: 14 },
  optionTitle: { color: colors.text, fontWeight: '900', fontSize: 15 },
  optionHelp: { color: colors.textMuted, fontSize: 12, lineHeight: 18, marginTop: 4 },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 16 },
  preview: { backgroundColor: colors.greenCard, borderColor: colors.borderStrong, borderWidth: 1, borderRadius: radii.lg, padding: 18, minHeight: 190 },
  previewLight: { backgroundColor: '#F1F3EE', borderColor: '#D4DDD7' },
  previewTransparent: { backgroundColor: '#B3080A0D' },
  previewEyebrow: { color: colors.accent, fontSize: 10, fontWeight: '900', letterSpacing: 1.2 },
  previewTop: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  previewTitle: { color: colors.text, fontSize: 24, fontWeight: '900' },
  previewTime: { color: colors.textMuted, fontSize: 16, marginTop: 3 },
  countdown: { color: colors.text, fontSize: 21, fontWeight: '900' },
  duaMiniTitle: { color: colors.accent, fontSize: 10, fontWeight: '900', marginTop: 16 },
  duaMiniMeaning: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: 5 },
  lightText: { color: '#141E19' },
  lightMuted: { color: '#4B5852' },
  lightAccent: { color: '#35674F' },
  syncButton: { backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.borderStrong, borderRadius: radii.md, paddingVertical: 15, alignItems: 'center', marginTop: 24 },
  syncText: { color: colors.text, fontWeight: '900' },
  status: { color: colors.textMuted, fontSize: 13, lineHeight: 19, marginTop: 12 },
});
