# DuaVakti 2.0.0

DuaVakti 2.0.0, çalışan 1.5.0 sürümü temel alınarak tek paket halinde genişletilmiş Android/Expo uygulamasıdır.

## Yeni özellikler

### Gelişmiş ezan ve vakit uyarıları
- Her namaz için ayrı aç/kapat
- Vaktinde veya 5/10/15/30 dakika önce uyarı
- Sesli, titreşimli veya sessiz bildirim kanalı
- Cuma namazı hatırlatıcısı
- Güneş doğuşundan önce kerahat uyarısı
- Ramazan ayında teravih hatırlatıcısı

### Gelişmiş Kur’an okuyucu
- Kaldığın sure ve ayeti kaydetme
- Ana ekrandan “Okumaya devam et”
- Ayet favorileri / yer imleri
- Birden fazla hafız
- 0.75x, 1x, 1.25x oynatma hızı
- Ayet ve sure tekrarı
- Uyku zamanlayıcısı
- Aktif ayete otomatik kaydırma
- Ayet paylaşma
- Sure seslerini indirip çevrimdışı dinleme

### Ramazan modu
- Sahura ve iftara kalan süre
- 30 günlük sahur/iftar takvimi
- Günlük Ramazan duası
- Oruç takibi
- Bayrama kalan gün

### Zikir / tesbih
- Hazır zikirler
- Özel zikir oluşturma
- Titreşimli sayma
- Günlük hedef
- Gün serisi
- Sayacı otomatik kaydetme

### Widget kişiselleştirme
- Koyu, açık ve şeffaf tema
- Dengeli, sıradaki vakit, dua ve Ramazan modu
- Dua, Hicri tarih ve geri sayım için ayrı aç/kapat
- Widgeta dokununca ilgili uygulama ekranını açma

### Ana ekran “Bugün” alanı
- Sıradaki vakit ve geri sayım
- Saatin duası
- Günün ayeti
- Hicri tarih
- Kur’an’da kaldığın yerden devam
- Ramazan özeti

### Akıllı kıble
- Canlı pusula
- Telefon düz değilse uyarı
- Kıble hizasında titreşim ve yeşil durum
- Kâbe’ye yaklaşık uzaklık
- Pusula kalibrasyon uyarısı
- Son konumla çevrimdışı çalışma

### Hızlı güncelleme
- Uygun JavaScript/içerik güncellemelerini EAS Update üzerinden kontrol etme ve indirme
- Native değişikliklerde yeni APK/AAB gerekir

## GitHub → EAS kurulumu

Mevcut otomatik workflow en yeni `DUAVAKTI-REBUILD-v*.zip` dosyasını seçer.

1. Bu paketi GitHub depo ana sayfasına yükle.
2. Actions → **DuaVakti Final Surumu Hazirla** → Run workflow.
3. Workflow yeşil olunca Expo → Builds → Build from GitHub.
4. Git ref `main`, platform `Android`, profil `preview`.
5. Build bitince APK’yı mevcut DuaVakti’nin üstüne kur.

`main.yml`, `app.json` ve `eas.json` dosyalarını elle değiştirmeye gerek yoktur.

## Yerel komutlar

```bash
npm ci
npm run typecheck
npm run test:logic
npm run verify
npm run prebuild:android
npm run verify:prebuild
npm run export:android
```

## Not

Bu kaynak paketi tam Android release APK’sı değildir. EAS Build son Android derlemesini üretir. Yerel Gradle release denemesi bu çalışma ortamında `services.gradle.org` DNS erişimi olmadığı için wrapper dağıtımını indiremeden durmuştur.
