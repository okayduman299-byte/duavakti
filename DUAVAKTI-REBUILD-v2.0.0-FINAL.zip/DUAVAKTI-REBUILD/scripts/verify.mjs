import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const root = process.cwd();
const failures = [];
const passes = [];
const check = (condition, label, detail = '') => condition ? passes.push(label) : failures.push(detail ? `${label}: ${detail}` : label);
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');
const exists = (rel) => fs.existsSync(path.join(root, rel));

const required = [
  'App.tsx', 'app.json', 'eas.json',
  'src/screens/HomeScreen.tsx', 'src/screens/QuranScreen.tsx', 'src/screens/DuasScreen.tsx',
  'src/screens/ToolsScreen.tsx', 'src/screens/WidgetScreen.tsx', 'src/screens/ZikrScreen.tsx',
  'src/screens/RamadanScreen.tsx', 'src/screens/SettingsScreen.tsx',
  'src/components/QiblaCompass.tsx',
  'src/lib/notificationPlan.ts', 'src/lib/notificationService.ts', 'src/lib/quranOffline.ts',
  'src/lib/quranProgress.ts', 'src/lib/reciters.ts', 'src/lib/ramadan.ts', 'src/lib/hijri.ts',
  'src/lib/zikr.ts', 'src/lib/qiblaExtra.ts', 'src/lib/updateService.ts',
  'modules/duavakti-widget/android/src/main/AndroidManifest.xml',
  'modules/duavakti-widget/android/src/main/java/com/shaesdoes/duavakti/widget/WidgetSupport.kt',
  'modules/duavakti-widget/android/src/main/res/drawable/widget_background_light.xml',
  'modules/duavakti-widget/android/src/main/res/drawable/widget_background_transparent.xml',
];
for (const rel of required) check(exists(rel), `${rel} mevcut`);

const pkg = JSON.parse(read('package.json'));
check(pkg.version === '2.0.0', 'Paket sürümü 2.0.0');
for (const [name, version] of Object.entries({
  'expo-file-system': '~57.0.0',
  'expo-sensors': '~57.0.1',
  'expo-updates': '~57.0.5',
  'expo-audio': '~57.0.0',
  'expo-notifications': '~57.0.3',
})) check(pkg.dependencies?.[name] === version, `${name} uyumlu SDK 57 sürümünde`);
check(!('expo-dev-client' in (pkg.dependencies ?? {})), 'Preview build gereksiz dev-client taşımıyor');

const appConfig = JSON.parse(read('app.json')).expo;
check(appConfig.version === '2.0.0', 'Expo uygulama sürümü 2.0.0');
check(appConfig.android?.versionCode === 13, 'Android versionCode 13');
check(appConfig.scheme === 'duavakti', 'Widget derin bağlantıları için URL scheme tanımlı');
check(appConfig.runtimeVersion?.policy === 'appVersion', 'OTA runtimeVersion appVersion politikasında');
check(String(appConfig.updates?.url ?? '').includes('b6ba130a-5c98-4a7b-b815-1a87526bf083'), 'EAS Update proje URL’si bağlı');
check((appConfig.plugins ?? []).some((x) => Array.isArray(x) && x[0] === 'expo-sensors'), 'Cihaz hareket sensörü config plugin bağlı');
check((appConfig.plugins ?? []).some((x) => Array.isArray(x) && x[0] === 'expo-notifications'), 'Bildirim config plugin bağlı');

const eas = JSON.parse(read('eas.json'));
check(eas.build?.preview?.android?.buildType === 'apk', 'Preview doğrudan kurulabilir APK üretir');
check(eas.build?.preview?.channel === 'preview', 'Preview OTA kanalı tanımlı');
check(eas.build?.production?.channel === 'production', 'Production OTA kanalı tanımlı');

const app = read('App.tsx');
for (const token of ['ToolsScreen', 'syncPrayerNotifications', 'notificationSettings', 'checkAndFetchUpdate', 'Linking.addEventListener', 'updateNativeWidgets', 'widgetSettings']) check(app.includes(token), `App bağlantısı: ${token}`);
check(app.includes("onOpenQuran={() => setTab('quran')}") && app.includes("onOpenTools={() => setTab('widget')}"), 'Bugün kartı Kur’an ve Araçlar ekranlarına bağlı');

const notificationPlan = read('src/lib/notificationPlan.ts');
for (const token of ['leadMinutes', 'enabledByPrayer', 'fridayReminder', 'kerahatReminder', 'teravihReminder']) check(notificationPlan.includes(token), `Gelişmiş bildirim planı: ${token}`);
const notificationService = read('src/lib/notificationService.ts');
for (const token of ["channelIdFor('sound')", "channelIdFor('vibrate')", "channelIdFor('silent')", 'DAYS_TO_SCHEDULE = 7', 'scheduleNotificationAsync']) check(notificationService.includes(token), `Bildirim servisi: ${token}`);

const quran = read('src/screens/QuranScreen.tsx');
for (const token of ['loadQuranProgress', 'loadBookmarks', 'RECITERS', 'setPlaybackRate', 'quranRepeatMode', 'SLEEP_OPTIONS', 'Share.share', 'downloadSurahAudio', 'getOfflineAyahUri', 'scrollToIndex', 'Tümünü dinle', 'Buradan dinle']) check(quran.includes(token), `Kur’an özelliği: ${token}`);
check(!quran.includes('useAudioPlaylist'), 'Kararlı tek AudioPlayer mimarisi korunuyor');
check(quran.includes('mountedRef') && quran.includes('didJustFinish'), 'Kur’an geçiş güvenliği ve otomatik ayet devamı var');

const offline = read('src/lib/quranOffline.ts');
for (const token of ['Directory', 'File', 'Paths.document', 'downloadFileAsync', 'removeSurahAudio']) check(offline.includes(token), `Çevrimdışı Kur’an sesi: ${token}`);
const progress = read('src/lib/quranProgress.ts');
for (const token of ['saveQuranProgress', 'loadQuranProgress', 'toggleBookmark']) check(progress.includes(token), `Kur’an ilerleme/favori: ${token}`);
const reciters = read('src/lib/reciters.ts');
check((reciters.match(/id:/g) ?? []).length >= 4, 'En az 4 hafız seçeneği var');

const home = read('src/screens/HomeScreen.tsx');
for (const token of ['BUGÜN', 'SAATİN DUASI', 'OKUMAYA DEVAM ET', 'Ramazan', 'onOpenQuran', 'onOpenTools']) check(home.includes(token), `Ana ekran Bugün kartı: ${token}`);

const tools = read('src/screens/ToolsScreen.tsx');
for (const token of ['WidgetScreen', 'ZikrScreen', 'RamadanScreen']) check(tools.includes(token), `Araçlar merkezi: ${token}`);
const zikr = read('src/screens/ZikrScreen.tsx');
for (const token of ['ZIKR_PRESETS', 'Vibration', 'calculateStreak', 'TextInput']) check(zikr.includes(token), `Zikir özelliği: ${token}`);
const ramadan = read('src/screens/RamadanScreen.tsx');
for (const token of ['SAHURA KALAN', 'İFTARA KALAN', '30 GÜNLÜK TAKVİM', 'Bugün oruç tuttum', 'GÜNÜN RAMAZAN DUASI']) check(ramadan.includes(token), `Ramazan özelliği: ${token}`);

const qibla = read('src/components/QiblaCompass.tsx');
for (const token of ['DeviceMotion.addListener', 'isPhoneFlat', 'distanceToKaabaKm', 'Vibration.vibrate', 'LAST_COORDS_KEY', 'watchHeadingAsync']) check(qibla.includes(token), `Akıllı kıble: ${token}`);

const widget = read('src/screens/WidgetScreen.tsx');
for (const token of ["'dark'", "'light'", "'transparent'", "'balanced'", "'next'", "'dua'", "'ramadan'", 'showDua', 'showHijri', 'showCountdown']) check(widget.includes(token), `Widget kişiselleştirme: ${token}`);
const widgetSupport = read('modules/duavakti-widget/android/src/main/java/com/shaesdoes/duavakti/widget/WidgetSupport.kt');
for (const token of ['WidgetSettings', 'duavakti://', 'widget_background_light', 'widget_background_transparent', 'isRamadan']) check(widgetSupport.includes(token), `Native widget özelliği: ${token}`);

const settings = read('src/screens/SettingsScreen.tsx');
for (const token of ['HANGİ VAKİTLER?', 'NE ZAMAN?', 'UYARI ŞEKLİ', 'Cuma namazı hatırlatıcısı', 'Kerahat uyarısı', 'Teravih hatırlatıcısı', 'Hızlı uygulama güncellemeleri']) check(settings.includes(token), `Ayar özelliği: ${token}`);
const updates = read('src/lib/updateService.ts');
for (const token of ['checkForUpdateAsync', 'fetchUpdateAsync', 'reloadAsync']) check(updates.includes(token), `OTA güncelleme: ${token}`);

const lock = read('package-lock.json');
check(!/internal\.api\.openai\.org|applied-caas|artifactory\/api\/npm/i.test(lock), 'package-lock özel geliştirme registry adresi taşımıyor');

const sourceFiles = [];
function collect(dir) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.test-build', 'android', 'ios', '.expo'].includes(item.name)) continue;
    const full = path.join(dir, item.name);
    if (item.isDirectory()) collect(full);
    else if (/\.(ts|tsx|js|mjs|kt|xml|gradle)$/.test(item.name)) sourceFiles.push(full);
  }
}
collect(root);
const markerHits = sourceFiles.filter((file) => path.basename(file) !== 'verify.mjs' && /\b(TODO|FIXME)\b/.test(fs.readFileSync(file, 'utf8')));
check(markerHits.length === 0, 'Kaynakta TODO/FIXME kalmadı', markerHits.map((x) => path.relative(root, x)).join(', '));

console.log(`PASS ${passes.length}`);
for (const label of passes) console.log(`  ✓ ${label}`);
if (failures.length) {
  console.error(`FAIL ${failures.length}`);
  for (const failure of failures) console.error(`  ✗ ${failure}`);
  process.exit(1);
}
console.log('STATIC VERIFICATION: PASS');
