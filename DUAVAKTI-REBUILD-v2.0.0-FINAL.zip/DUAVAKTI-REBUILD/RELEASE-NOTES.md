# DuaVakti 2.0.0 — Sürüm Notları

## Öne çıkanlar

- Gelişmiş namaz uyarıları: namaz bazında aç/kapat, erken hatırlatma, ses/titreşim/sessiz, Cuma, kerahat ve teravih.
- Kur’an: tam ayet konumu kaydı, favoriler, çoklu hafız, hız, tekrar, uyku zamanlayıcısı, otomatik kaydırma, paylaşım ve çevrimdışı ses indirme.
- Ana ekranda yeni “Bugün” alanı ve Kur’an’a kaldığın yerden devam kartı.
- Yeni Araçlar merkezi: Widget, Zikir ve Ramazan.
- Ramazan modu: sahur/iftar geri sayımı, 30 günlük takvim, dua, oruç takibi ve bayram sayacı.
- Zikir/tesbih: hazır ve özel zikir, hedef, titreşim, otomatik kayıt ve seri.
- Widgetlar: tema, içerik modu, görünür alanlar ve derin bağlantı.
- Kıble: cihaz eğimi, hizalama titreşimi, Kâbe mesafesi, kalibrasyon ve son konum.
- EAS Update tabanlı hızlı güncelleme kontrolü.

## Teknik değişiklikler

- Uygulama sürümü: 2.0.0
- Android versionCode: 13
- Expo SDK: 57
- `expo-file-system`, `expo-sensors`, `expo-updates` eklendi.
- `duavakti://` URL şeması eklendi.
- Preview ve production EAS Update kanalları tanımlandı.
- Mevcut tek AudioPlayer mimarisi korunarak eski Kur’an → Dualar geçiş kararlılığı bozulmadı.
