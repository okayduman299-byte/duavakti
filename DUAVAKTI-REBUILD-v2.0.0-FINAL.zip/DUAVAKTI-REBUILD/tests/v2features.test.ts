import test from 'node:test';
import assert from 'node:assert/strict';
import { parseHijriDate, isRamadanMonth, daysUntilEid } from '../src/lib/hijri';
import { markZikrProgress, calculateStreak, defaultZikrState } from '../src/lib/zikr';
import { distanceToKaabaKm, isPhoneFlat } from '../src/lib/qiblaExtra';
import { buildPrayerNotificationPlan } from '../src/lib/notificationPlan';
import type { PrayerApiResult, PrayerNotificationSettings } from '../src/types';

const baseResult: PrayerApiResult = {
  dateKey: '2026-07-10',
  locationKey: 'city:test',
  locationLabel: 'Test',
  timings: { Fajr: '05:00', Sunrise: '06:30', Dhuhr: '13:00', Asr: '17:00', Maghrib: '20:30', Isha: '22:00' },
  hijriMonth: 9,
  source: 'network',
};

const advanced: PrayerNotificationSettings = {
  enabledByPrayer: { Fajr: true, Dhuhr: false, Asr: true, Maghrib: true, Isha: true },
  leadMinutes: 15,
  mode: 'vibrate',
  fridayReminder: true,
  kerahatReminder: true,
  teravihReminder: true,
};

test('hicri tarih güvenli ayrıştırılır', () => {
  assert.deepEqual(parseHijriDate('09-09-1448'), { day: 9, month: 9, year: 1448 });
  assert.equal(parseHijriDate('99-99-x'), null);
});

test('Ramazan ve bayrama kalan gün hesabı çalışır', () => {
  assert.equal(isRamadanMonth(9), true);
  assert.equal(daysUntilEid(18, 9), 12);
  assert.equal(daysUntilEid(18, 8), null);
});

test('zikir hedefi tamamlanınca gün kaydedilir', () => {
  const now = new Date(2026, 6, 10, 12, 0, 0);
  const state = { ...defaultZikrState(now), target: 33 };
  const completed = markZikrProgress(state, 33, now);
  assert.deepEqual(completed.completedDates, ['2026-07-10']);
});

test('zikir serisi ardışık tamamlanan günleri sayar', () => {
  const now = new Date(2026, 6, 10, 12, 0, 0);
  assert.equal(calculateStreak(['2026-07-08', '2026-07-09', '2026-07-10'], now), 3);
  assert.equal(calculateStreak(['2026-07-08', '2026-07-10'], now), 1);
});

test('Kâbe mesafesi Mekke yakınında küçüktür', () => {
  assert.ok(distanceToKaabaKm(21.4225, 39.8262) < 0.01);
});

test('telefon yataylık eşiği doğru değerlendirilir', () => {
  assert.equal(isPhoneFlat(9.4), true);
  assert.equal(isPhoneFlat(4), false);
});

test('gelişmiş bildirim planı kapalı vakti atlar ve erken uyarır', () => {
  const friday = new Date(2026, 6, 10, 0, 0, 0); // Cuma
  const now = new Date(2026, 6, 10, 4, 0, 0);
  const plan = buildPrayerNotificationPlan([{ date: friday, result: baseResult }], advanced, now);
  assert.equal(plan.some((item) => item.key === 'Dhuhr' && item.kind === 'prayer-time'), false);
  const fajr = plan.find((item) => item.key === 'Fajr');
  assert.equal(fajr?.target.getHours(), 4);
  assert.equal(fajr?.target.getMinutes(), 45);
  assert.equal(plan.some((item) => item.kind === 'friday'), true);
  assert.equal(plan.some((item) => item.kind === 'kerahat'), true);
  assert.equal(plan.some((item) => item.kind === 'teravih'), true);
});
