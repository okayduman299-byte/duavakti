# DuaVakti 2.0.0 — Test Sonuçları

## Sonuç özeti

| Kontrol | Sonuç |
|---|---|
| TypeScript | PASS — 0 hata |
| Mantık testleri | PASS — 36/36 |
| Statik özellik ve bütünlük doğrulaması | PASS — 135/135 |
| Expo Android prebuild | PASS |
| Expo native autolinking/prebuild doğrulaması | PASS — 14/14 |
| Android Metro/Hermes export | PASS — 743 modül |
| Paket kilidi özel geliştirme registry kontrolü | PASS |
| Tam yerel Gradle release | ORTAM SINIRI — Gradle dağıtımı DNS nedeniyle indirilemedi |

## Doğrulanan başlıklar

- Gelişmiş namaz uyarı planı
- Namaz bazında bildirim seçimi ve erken uyarı
- Cuma, kerahat ve teravih planı
- Kur’an ilerleme kaydı ve favoriler
- Çoklu hafız, oynatma hızı, tekrar, uyku zamanlayıcısı
- Otomatik ayet devamı ve otomatik kaydırma
- Çevrimdışı sure sesi indirme altyapısı
- Zikir hedefi ve gün serisi mantığı
- Ramazan/Hicri tarih yardımcıları
- Akıllı kıble mesafe ve cihaz düzlüğü hesabı
- Widget kişiselleştirme kaynakları ve derin bağlantı
- OTA güncelleme kontrol, indirme ve yeniden yükleme akışı
- Expo SDK 57 yerel widget autolinking

## Çalıştırılan komutlar

```text
npm run typecheck
npm run test:logic
npm run verify
npm run prebuild:android
npm run verify:prebuild
npm run export:android
./gradlew :app:assembleRelease --no-daemon
```

Son komut uygulama kodu derlenmeden önce Gradle wrapper indirme aşamasında `UnknownHostException: services.gradle.org` ile durdu. Bu nedenle burada APK üretildiği iddia edilmez; son release doğrulaması EAS Build üzerindedir.
