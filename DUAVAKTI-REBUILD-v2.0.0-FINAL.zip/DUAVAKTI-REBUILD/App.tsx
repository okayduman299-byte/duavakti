import React, { useEffect, useState } from 'react';
import { Linking, Platform, StatusBar, StyleSheet, View } from 'react-native';
import { BottomNav } from './src/components/BottomNav';
import { ErrorBoundary } from './src/components/ErrorBoundary';
import { LoadingState } from './src/components/States';
import { usePreferences } from './src/hooks/usePreferences';
import { usePrayerData } from './src/hooks/usePrayerData';
import { HomeScreen } from './src/screens/HomeScreen';
import { QuranScreen } from './src/screens/QuranScreen';
import { DuasScreen } from './src/screens/DuasScreen';
import { ToolsScreen } from './src/screens/ToolsScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { colors } from './src/theme';
import { prayerRows, timeOnDate } from './src/lib/prayer';
import { DUAS } from './src/data/duas';
import { updateNativeWidgets } from './src/native/widget';
import { syncPrayerNotifications } from './src/lib/notificationService';
import { formatHijriLabel, isRamadanMonth } from './src/lib/hijri';
import { checkAndFetchUpdate } from './src/lib/updateService';
import type { TabKey } from './src/types';

function tabFromUrl(url: string | null): TabKey | null {
  if (!url) return null;
  const normalized = url.toLowerCase();
  if (normalized.includes('://quran')) return 'quran';
  if (normalized.includes('://duas')) return 'duas';
  if (normalized.includes('://tools') || normalized.includes('://widget') || normalized.includes('://zikr') || normalized.includes('://ramadan')) return 'widget';
  if (normalized.includes('://settings')) return 'settings';
  if (normalized.includes('://home')) return 'home';
  return null;
}

export default function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const { preferences, update, ready } = usePreferences();
  const prayer = usePrayerData(preferences, (enabled) => update({ useGps: enabled }));

  useEffect(() => {
    void Linking.getInitialURL().then((url) => {
      const nextTab = tabFromUrl(url);
      if (nextTab) setTab(nextTab);
    });
    const subscription = Linking.addEventListener('url', ({ url }) => {
      const nextTab = tabFromUrl(url);
      if (nextTab) setTab(nextTab);
    });
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    if (!ready || !preferences.autoUpdates) return;
    const timer = setTimeout(() => {
      void checkAndFetchUpdate(false).catch(() => undefined);
    }, 2500);
    return () => clearTimeout(timer);
  }, [ready, preferences.autoUpdates]);

  useEffect(() => {
    if (!prayer.data || !prayer.next) return;
    const now = new Date();
    const iftar = timeOnDate(now, prayer.data.timings.Maghrib);
    void updateNativeWidgets({
      location: prayer.data.locationLabel,
      hijriDate: formatHijriLabel(prayer.data.hijriDay, prayer.data.hijriMonth, prayer.data.hijriYear),
      nextPrayer: prayer.next.label,
      nextTime: prayer.next.time,
      remaining: prayer.countdown,
      targetEpoch: prayer.next.target.getTime(),
      iftarTime: prayer.data.timings.Maghrib,
      iftarEpoch: iftar?.getTime(),
      isRamadan: isRamadanMonth(prayer.data.hijriMonth),
      prayers: prayerRows(prayer.data.timings).map((row) => ({ label: row.label, time: row.time })),
      duas: DUAS.map(({ title, meaning, source }) => ({ title, meaning, source })),
      settings: preferences.widgetSettings,
    });
  }, [
    prayer.data,
    prayer.next?.key,
    prayer.next?.target.getTime(),
    preferences.widgetSettings.theme,
    preferences.widgetSettings.mode,
    preferences.widgetSettings.showDua,
    preferences.widgetSettings.showHijri,
    preferences.widgetSettings.showCountdown,
  ]);

  useEffect(() => {
    if (!ready) return;
    if (!preferences.prayerNotifications) {
      void syncPrayerNotifications({
        enabled: false,
        location: prayer.activeLocation,
        todayData: prayer.data,
        settings: preferences.notificationSettings,
      }).catch(() => undefined);
      return;
    }
    if (!prayer.data) return;

    const timer = setTimeout(() => {
      void syncPrayerNotifications({
        enabled: true,
        location: prayer.activeLocation,
        todayData: prayer.data,
        settings: preferences.notificationSettings,
      }).catch(() => undefined);
    }, 800);

    return () => clearTimeout(timer);
  }, [
    ready,
    preferences.prayerNotifications,
    preferences.notificationSettings,
    prayer.data?.dateKey,
    prayer.data?.locationKey,
    prayer.activeLocation.mode,
    prayer.activeLocation.city,
    prayer.activeLocation.country,
    prayer.activeLocation.latitude,
    prayer.activeLocation.longitude,
  ]);

  const screen = (() => {
    switch (tab) {
      case 'quran':
        return <QuranScreen preferences={preferences} updatePreferences={update} />;
      case 'duas':
        return <DuasScreen />;
      case 'widget':
        return (
          <ToolsScreen
            data={prayer.data}
            next={prayer.next}
            countdown={prayer.countdown}
            preferences={preferences}
            updatePreferences={update}
            activeLocation={prayer.activeLocation}
          />
        );
      case 'settings':
        return (
          <SettingsScreen
            preferences={preferences}
            updatePreferences={update}
            activeLocation={prayer.activeLocation}
            onRefresh={prayer.refresh}
          />
        );
      default:
        return (
          <HomeScreen
            data={prayer.data}
            loading={prayer.loading}
            error={prayer.error}
            next={prayer.next}
            countdown={prayer.countdown}
            onRefresh={prayer.refresh}
            onLocate={() => void prayer.useCurrentLocation()}
            onOpenQuran={() => setTab('quran')}
            onOpenTools={() => setTab('widget')}
          />
        );
    }
  })();

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor={colors.background} />
      <View style={styles.safeTop} />
      <View style={styles.screen}>
        {ready ? <ErrorBoundary key={tab} resetKey={tab}>{screen}</ErrorBoundary> : <LoadingState label="DuaVakti hazırlanıyor…" />}
      </View>
      <BottomNav active={tab} onChange={setTab} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  safeTop: { height: Platform.OS === 'android' ? StatusBar.currentHeight ?? 0 : 0 },
  screen: { flex: 1 },
});
