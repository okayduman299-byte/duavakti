package com.shaesdoes.duavakti.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class DuaVaktiSmallWidget : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
    updateWidgets(context, manager, ids, "home") { data ->
      val primary = displayPrimary(data)
      RemoteViews(context.packageName, R.layout.duavakti_widget_small).apply {
        setTextViewText(R.id.next_prayer, primary.first)
        setTextViewText(R.id.next_time, primary.second)
        setTextViewText(R.id.location, displayLocation(data))
        setTextViewText(R.id.dua_title, "SAATİN DUASI · ${data.hourlyDua.title}")
        applyDuaVisibility(this, data, intArrayOf(R.id.dua_title))
        applyWidgetTheme(this, data, intArrayOf(R.id.next_prayer), intArrayOf(R.id.next_time))
      }
    }
  }
}
