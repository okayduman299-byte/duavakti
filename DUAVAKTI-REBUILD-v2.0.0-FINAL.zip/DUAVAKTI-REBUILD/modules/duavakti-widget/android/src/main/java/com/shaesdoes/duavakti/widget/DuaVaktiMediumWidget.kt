package com.shaesdoes.duavakti.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.view.View
import android.widget.RemoteViews

class DuaVaktiMediumWidget : AppWidgetProvider() {
  override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
    updateWidgets(context, manager, ids, "home") { data ->
      val primary = displayPrimary(data)
      RemoteViews(context.packageName, R.layout.duavakti_widget_medium).apply {
        setTextViewText(R.id.next_prayer, primary.first)
        setTextViewText(R.id.next_time, primary.second)
        setTextViewText(R.id.remaining, primary.third)
        setTextViewText(R.id.location, displayLocation(data))
        setTextViewText(R.id.dua_title, "SAATİN DUASI · ${data.hourlyDua.title}")
        setTextViewText(R.id.dua_meaning, data.hourlyDua.meaning)
        setViewVisibility(R.id.remaining, if (data.settings.showCountdown) View.VISIBLE else View.GONE)
        setViewVisibility(R.id.remaining_label, if (data.settings.showCountdown) View.VISIBLE else View.GONE)
        applyDuaVisibility(this, data, intArrayOf(R.id.dua_title, R.id.dua_meaning))
        applyWidgetTheme(this, data, intArrayOf(R.id.next_prayer, R.id.remaining), intArrayOf(R.id.next_time, R.id.remaining_label))
      }
    }
  }
}
