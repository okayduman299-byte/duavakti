package com.shaesdoes.duavakti.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

internal data class WidgetDua(
  val title: String,
  val meaning: String,
  val source: String,
)

internal data class WidgetSettings(
  val theme: String,
  val mode: String,
  val showDua: Boolean,
  val showHijri: Boolean,
  val showCountdown: Boolean,
)

internal data class WidgetData(
  val location: String,
  val hijriDate: String,
  val nextPrayer: String,
  val nextTime: String,
  val remaining: String,
  val targetEpoch: Long,
  val iftarTime: String,
  val iftarEpoch: Long,
  val isRamadan: Boolean,
  val prayers: List<Pair<String, String>>,
  val hourlyDua: WidgetDua,
  val settings: WidgetSettings,
)

private val fallbackDua = WidgetDua(
  title = "İlim duası",
  meaning = "Rabbim! İlmimi artır.",
  source = "Tâhâ 20:114",
)

private fun formatRemaining(targetEpoch: Long, fallback: String): String {
  if (targetEpoch <= 0L) return fallback
  val seconds = ((targetEpoch - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
  val hours = seconds / 3600L
  val minutes = (seconds % 3600L) / 60L
  val remainingSeconds = seconds % 60L
  return String.format("%02d:%02d:%02d", hours, minutes, remainingSeconds)
}

private fun readHourlyDua(raw: String): WidgetDua {
  return try {
    val array = JSONArray(raw)
    if (array.length() == 0) return fallbackDua
    val calendar = Calendar.getInstance()
    val hourlySlot = calendar.get(Calendar.DAY_OF_YEAR) * 24 + calendar.get(Calendar.HOUR_OF_DAY)
    val item = array.optJSONObject(hourlySlot % array.length()) ?: return fallbackDua
    WidgetDua(
      title = item.optString("title", fallbackDua.title),
      meaning = item.optString("meaning", fallbackDua.meaning),
      source = item.optString("source", fallbackDua.source),
    )
  } catch (_: Exception) {
    fallbackDua
  }
}

private fun readSettings(raw: String): WidgetSettings {
  return try {
    val item = JSONObject(raw)
    WidgetSettings(
      theme = item.optString("theme", "dark"),
      mode = item.optString("mode", "balanced"),
      showDua = item.optBoolean("showDua", true),
      showHijri = item.optBoolean("showHijri", true),
      showCountdown = item.optBoolean("showCountdown", true),
    )
  } catch (_: Exception) {
    WidgetSettings("dark", "balanced", true, true, true)
  }
}

internal fun readWidgetData(context: Context): WidgetData {
  val prefs = context.getSharedPreferences(DuaVaktiWidgetModule.PREFS, Context.MODE_PRIVATE)
  val rawPrayers = prefs.getString("prayers", "[]") ?: "[]"
  val rows = mutableListOf<Pair<String, String>>()
  try {
    val array = JSONArray(rawPrayers)
    for (i in 0 until array.length()) {
      val item = array.optJSONObject(i) ?: continue
      rows += item.optString("label", "") to item.optString("time", "--:--")
    }
  } catch (_: Exception) {
    // Keep widget alive even when preferences are corrupted.
  }
  val targetEpoch = prefs.getLong("targetEpoch", 0L)
  val fallbackRemaining = prefs.getString("remaining", "--:--:--") ?: "--:--:--"
  val iftarEpoch = prefs.getLong("iftarEpoch", 0L)
  val rawDuas = prefs.getString("duas", "[]") ?: "[]"
  return WidgetData(
    location = prefs.getString("location", "DuaVakti") ?: "DuaVakti",
    hijriDate = prefs.getString("hijriDate", "") ?: "",
    nextPrayer = prefs.getString("nextPrayer", "Sıradaki vakit") ?: "Sıradaki vakit",
    nextTime = prefs.getString("nextTime", "--:--") ?: "--:--",
    remaining = formatRemaining(targetEpoch, fallbackRemaining),
    targetEpoch = targetEpoch,
    iftarTime = prefs.getString("iftarTime", "--:--") ?: "--:--",
    iftarEpoch = iftarEpoch,
    isRamadan = prefs.getBoolean("isRamadan", false),
    prayers = rows,
    hourlyDua = readHourlyDua(rawDuas),
    settings = readSettings(prefs.getString("settings", "{}") ?: "{}"),
  )
}

internal fun displayLocation(data: WidgetData): String {
  return if (data.settings.showHijri && data.hijriDate.isNotBlank()) {
    "${data.location} · ${data.hijriDate}"
  } else data.location
}

internal fun displayPrimary(data: WidgetData): Triple<String, String, String> {
  return when {
    data.settings.mode == "dua" -> Triple(data.hourlyDua.title, data.hourlyDua.meaning, "")
    data.settings.mode == "ramadan" && data.isRamadan -> Triple(
      "İftara kalan",
      data.iftarTime,
      formatRemaining(data.iftarEpoch, "--:--:--"),
    )
    else -> Triple(data.nextPrayer, data.nextTime, data.remaining)
  }
}

internal fun applyWidgetTheme(views: RemoteViews, data: WidgetData, textIds: IntArray, mutedIds: IntArray = intArrayOf()) {
  val background = when (data.settings.theme) {
    "light" -> R.drawable.widget_background_light
    "transparent" -> R.drawable.widget_background_transparent
    else -> R.drawable.widget_background
  }
  views.setInt(R.id.widget_root, "setBackgroundResource", background)
  val mainColor = if (data.settings.theme == "light") Color.rgb(20, 30, 25) else Color.rgb(242, 240, 234)
  val mutedColor = if (data.settings.theme == "light") Color.rgb(75, 88, 82) else Color.rgb(133, 140, 137)
  textIds.forEach { views.setTextColor(it, mainColor) }
  mutedIds.forEach { views.setTextColor(it, mutedColor) }
}

internal fun applyDuaVisibility(views: RemoteViews, data: WidgetData, ids: IntArray) {
  val visible = data.settings.showDua && data.settings.mode != "next"
  ids.forEach { views.setViewVisibility(it, if (visible) View.VISIBLE else View.GONE) }
}

internal fun attachOpenAppIntent(context: Context, views: RemoteViews, target: String = "home") {
  val intent = Intent(Intent.ACTION_VIEW, Uri.parse("duavakti://$target")).apply {
    setPackage(context.packageName)
    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
  }
  val pending = PendingIntent.getActivity(
    context,
    target.hashCode(),
    intent,
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
  )
  views.setOnClickPendingIntent(R.id.widget_root, pending)
}

internal fun updateWidgets(
  context: Context,
  manager: AppWidgetManager,
  ids: IntArray,
  target: String = "home",
  factory: (WidgetData) -> RemoteViews,
) {
  val data = readWidgetData(context)
  ids.forEach { id ->
    val views = factory(data)
    attachOpenAppIntent(context, views, target)
    manager.updateAppWidget(id, views)
  }
}
