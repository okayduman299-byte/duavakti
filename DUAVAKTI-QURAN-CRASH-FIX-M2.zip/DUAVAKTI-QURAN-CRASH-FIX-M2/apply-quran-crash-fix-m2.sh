#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/package.json" ] || [ ! -f "$ROOT/app.json" ]; then
  echo "❌ DuaVakti projesi bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"

for marker in \
  "type Tab = 'home' | 'quran'" \
  'Oku · Dinle · Öğren' \
  'SafeAreaProvider' \
  'useSafeAreaInsets'; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen Kur’an M1 / son UI tabanı bulunamadı: $marker"
    echo "Mevcut dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-m2-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx package.json package-lock.json app.json "$BACKUP"/ 2>/dev/null || true

echo "=== 1/6 Expo Audio sürüm eşleme ==="
npx expo install expo-audio

echo "=== 2/6 Çökme düzeltmesi ==="
cp "$SCRIPT_DIR/files/App.tsx" App.tsx

echo "=== 3/6 Statik güvenlik kontrolü ==="
grep -Fq "createAudioPlayer" App.tsx
grep -Fq "playerRef = useRef" App.tsx
grep -Fq "async function playAyah" App.tsx
if grep -Fq "useAudioPlayer(null" App.tsx; then
  echo "❌ Eski açılışta player oluşturan kod hâlâ var."
  exit 1
fi
if grep -Fq "useAudioPlayerStatus" App.tsx; then
  echo "❌ Eski player status hook'u hâlâ var."
  exit 1
fi
echo "✅ QURAN_LAZY_AUDIO_STATIC_OK"

echo "=== 4/6 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 5/6 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi

echo "=== 6/6 Temiz Android prebuild ==="
npx expo prebuild --platform android --clean
if [ -f scripts/validate-generated-widget.js ]; then
  node scripts/validate-generated-widget.js
fi

echo
echo "✅ QURAN_CRASH_FIX_M2_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
