DUAVAKTI QURAN CRASH FIX M2

Amaç:
- Kur’an sekmesine dokununca uygulamanın kapanmasını önlemek.
- Ses motorunu Kur’an ekranı açılır açılmaz başlatmamak.
- Audio player'ı yalnızca kullanıcı bir ayetin oynat düğmesine dokunduğunda oluşturmak.
- Çalışan widget ve safe-area düzeltmelerini korumak.

Uygulama:
cd /workspaces/duavakti && \
  git fetch origin && \
  git checkout origin/main -- DUAVAKTI-QURAN-CRASH-FIX-M2.zip && \
  unzip -o DUAVAKTI-QURAN-CRASH-FIX-M2.zip && \
  bash DUAVAKTI-QURAN-CRASH-FIX-M2/apply-quran-crash-fix-m2.sh

Hedef çıktı:
✅ QURAN_CRASH_FIX_M2_READY
