DUAVAKTI QURAN CRASH FIX M2

Amaç:
Kur’an sekmesine dokunulduğu anda uygulamanın kapanmasına yol açabilecek erken native ses oynatıcı çağrılarını kaldırır.

Düzeltme:
- Boş audio player üzerinde açılışta pause() çağrısı yapılmaz.
- Ses kaynağı yüklenmeden playbackRate / pitch ayarı yapılmaz.
- Hız ayarı yalnızca player gerçekten yüklendikten sonra uygulanır.
- Oku moduna geçerken yalnızca yüklü bir ses varsa pause() çağrılır.
- Widget ve mevcut UI yapısına dokunulmaz.

Uygulama:
cd /workspaces/duavakti && git fetch origin && git checkout origin/main -- DUAVAKTI-QURAN-CRASH-FIX-M2.zip && unzip -o DUAVAKTI-QURAN-CRASH-FIX-M2.zip && bash DUAVAKTI-QURAN-CRASH-FIX-M2/apply-quran-crash-fix.sh
