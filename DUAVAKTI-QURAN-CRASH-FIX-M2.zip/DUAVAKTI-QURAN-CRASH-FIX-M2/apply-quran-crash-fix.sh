#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-/workspaces/duavakti/DUAVAKTI-M1}"

if [ ! -f "$ROOT/App.tsx" ] || [ ! -f "$ROOT/package.json" ]; then
  echo "❌ DuaVakti projesi bulunamadı: $ROOT"
  exit 1
fi

cd "$ROOT"

for marker in \
  "type Tab = 'home' | 'quran'" \
  "function QuranScreen()" \
  "useAudioPlayer(null" \
  "Oku · Dinle · Öğren"; do
  if ! grep -Fq "$marker" App.tsx; then
    echo "❌ Beklenen Kur’an M1 sürümü bulunamadı: $marker"
    echo "Mevcut dosyaya dokunulmadı."
    exit 1
  fi
done

BACKUP="/tmp/duavakti-quran-crash-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp App.tsx package.json package-lock.json app.json "$BACKUP"/ 2>/dev/null || true

echo "=== 1/4 Kur’an açılış çökmesi düzeltmesi ==="
python3 - <<'PY'
from pathlib import Path

p = Path('App.tsx')
s = p.read_text(encoding='utf-8')

old_effect = """  useEffect(() => {
    player.playbackRate = speed;
    player.shouldCorrectPitch = true;
  }, [player, speed]);
"""
new_effect = """  useEffect(() => {
    if (activeAyahIndex === null || !playerStatus.isLoaded) return;

    try {
      player.playbackRate = speed;
    } catch {
      // Ses kaynağı tam hazır değilse varsayılan hızla devam et.
    }
  }, [activeAyahIndex, player, playerStatus.isLoaded, speed]);
"""

if old_effect not in s:
    raise SystemExit('❌ Eski erken audio effect bloğu bulunamadı')
s = s.replace(old_effect, new_effect, 1)

old_load = """      player.pause();
      setActiveAyahIndex(null);
"""
new_load = """      if (activeAyahIndex !== null && playerStatus.isLoaded) {
        player.pause();
      }
      setActiveAyahIndex(null);
"""
if old_load not in s:
    raise SystemExit('❌ loadSurah içindeki erken pause bulunamadı')
s = s.replace(old_load, new_load, 1)

old_play = """    player.replace({
      uri: ayah.audio,
      name: `${surah?.englishName ?? 'Kur’an'} ${ayah.numberInSurah}`,
    });
    player.playbackRate = speed;
    player.shouldCorrectPitch = true;
    player.play();
"""
new_play = """    player.replace({
      uri: ayah.audio,
      name: `${surah?.englishName ?? 'Kur’an'} ${ayah.numberInSurah}`,
    });
    player.play();
"""
if old_play not in s:
    raise SystemExit('❌ playAyah içindeki erken native ayarlar bulunamadı')
s = s.replace(old_play, new_play, 1)

old_mode = """    if (next === 'read') {
      player.pause();
    }
"""
new_mode = """    if (
      next === 'read' &&
      activeAyahIndex !== null &&
      playerStatus.isLoaded
    ) {
      player.pause();
    }
"""
if old_mode not in s:
    raise SystemExit('❌ selectMode içindeki erken pause bulunamadı')
s = s.replace(old_mode, new_mode, 1)

p.write_text(s, encoding='utf-8')
PY

echo "=== 2/4 Kaynak doğrulaması ==="
if grep -Fq 'player.shouldCorrectPitch = true;' App.tsx; then
  echo "❌ Erken shouldCorrectPitch çağrısı hâlâ var"
  exit 1
fi
python3 - <<'PY_CHECK'
from pathlib import Path
s = Path('App.tsx').read_text(encoding='utf-8')
unsafe = """  useEffect(() => {
    player.playbackRate = speed;
    player.shouldCorrectPitch = true;
  }, [player, speed]);
"""
if unsafe in s:
    raise SystemExit('❌ Kaynak yüklenmeden native audio ayarı hâlâ var')
PY_CHECK
grep -Fq 'activeAyahIndex === null || !playerStatus.isLoaded' App.tsx
grep -Fq 'activeAyahIndex !== null && playerStatus.isLoaded' App.tsx
grep -Fq 'player.replace({' App.tsx
echo "✅ QURAN_CRASH_SOURCE_OK"

echo "=== 3/4 TypeScript ==="
npx tsc --noEmit
echo "✅ TYPECHECK_OK"

echo "=== 4/4 Widget regresyon kontrolü ==="
if [ -f scripts/validate-widget-rescue.js ]; then
  node scripts/validate-widget-rescue.js
fi

echo
echo "✅ QURAN_CRASH_FIX_READY"
echo "Yedek: $BACKUP"
echo
echo "Sıradaki tek komut:"
echo "npx eas-cli@latest build --platform android --profile preview"
